﻿#pragma once

#include <string>
#include <vector>

struct ProjectFlexRankPlayer
{
    int rank = 0;
    std::wstring username;
    int hype = 0;
    int wins = 0;
    int kills = 0;
    int matches = 0;
};

struct ProjectFlexRanksResult
{
    bool success = false;
    std::vector<ProjectFlexRankPlayer> players;
    std::wstring message;
};

struct ProjectFlexStatusResult
{
    bool success = false;

    bool backend = false;
    bool authentication = false;
    bool database = false;

    int rankedPlayers = 0;
    int uptime = 0;

    std::wstring message;
};

ProjectFlexRanksResult FetchProjectFlexRanks();
ProjectFlexStatusResult FetchProjectFlexStatus();
