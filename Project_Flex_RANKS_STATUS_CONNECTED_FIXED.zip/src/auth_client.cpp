﻿#include "auth_client.h"

#include <windows.h>
#include <winhttp.h>
#include <shellapi.h>
#include <wincred.h>
#include <filesystem>
#include <string>
#include <vector>
#include <iterator>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")

namespace
{

std::filesystem::path GetExeDirectory()
{
    wchar_t buffer[MAX_PATH]{};
    const DWORD length = GetModuleFileNameW(nullptr, buffer, MAX_PATH);

    if (length == 0)
        return std::filesystem::current_path();

    return std::filesystem::path(buffer).parent_path();
}

std::filesystem::path GetPrivateConfigPath()
{
    return GetExeDirectory() / L"server_config.ini";
}

std::wstring ReadPrivateConfig(
    const wchar_t* key,
    const wchar_t* fallback = L""
)
{
    wchar_t value[2048]{};

    GetPrivateProfileStringW(
        L"Services",
        key,
        fallback,
        value,
        static_cast<DWORD>(std::size(value)),
        GetPrivateConfigPath().c_str()
    );

    return value;
}

std::wstring GetAuthUrl()
{
    // server_config.ini tem prioridade. Se não existir junto do EXE,
    // usa o endpoint HTTPS que já foi configurado.
    return ReadPrivateConfig(
        L"AuthUrl",
        L"https://54-36-99-5.sslip.io/projectflex/api/auth/login"
    );
}

std::wstring GetAccountUrl()
{
    // server_config.ini tem prioridade. Fallback direto para o Discord.
    return ReadPrivateConfig(
        L"AccountUrl",
        L"https://discord.gg/vWpFQ4dhj6"
    );
}

std::string WideToUtf8(const std::wstring& value)
{
    if (value.empty())
        return {};

    const int size = WideCharToMultiByte(
        CP_UTF8, 0,
        value.c_str(), static_cast<int>(value.size()),
        nullptr, 0, nullptr, nullptr
    );

    if (size <= 0)
        return {};

    std::string out(static_cast<size_t>(size), '\0');

    WideCharToMultiByte(
        CP_UTF8, 0,
        value.c_str(), static_cast<int>(value.size()),
        out.data(), size, nullptr, nullptr
    );

    return out;
}

std::wstring Utf8ToWide(const std::string& value)
{
    if (value.empty())
        return {};

    const int size = MultiByteToWideChar(
        CP_UTF8, 0,
        value.c_str(), static_cast<int>(value.size()),
        nullptr, 0
    );

    if (size <= 0)
        return {};

    std::wstring out(static_cast<size_t>(size), L'\0');

    MultiByteToWideChar(
        CP_UTF8, 0,
        value.c_str(), static_cast<int>(value.size()),
        out.data(), size
    );

    return out;
}

std::string JsonEscape(const std::string& value)
{
    std::string out;
    out.reserve(value.size() + 16);

    for (char ch : value)
    {
        switch (ch)
        {
        case '\\': out += "\\\\"; break;
        case '"':  out += "\\\""; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default:   out += ch; break;
        }
    }

    return out;
}

std::string FindJsonString(
    const std::string& json,
    const std::string& key
)
{
    const std::string needle = "\"" + key + "\"";
    size_t p = json.find(needle);

    if (p == std::string::npos)
        return {};

    p = json.find(':', p + needle.size());

    if (p == std::string::npos)
        return {};

    p = json.find('"', p + 1);

    if (p == std::string::npos)
        return {};

    ++p;

    std::string result;
    bool escaped = false;

    for (; p < json.size(); ++p)
    {
        const char ch = json[p];

        if (escaped)
        {
            switch (ch)
            {
            case 'n': result += '\n'; break;
            case 'r': result += '\r'; break;
            case 't': result += '\t'; break;
            case '"': result += '"'; break;
            case '\\': result += '\\'; break;
            default: result += ch; break;
            }

            escaped = false;
            continue;
        }

        if (ch == '\\')
        {
            escaped = true;
            continue;
        }

        if (ch == '"')
            break;

        result += ch;
    }

    return result;
}

bool FindJsonBool(
    const std::string& json,
    const std::string& key,
    bool fallback
)
{
    const std::string needle = "\"" + key + "\"";
    size_t p = json.find(needle);

    if (p == std::string::npos)
        return fallback;

    p = json.find(':', p + needle.size());

    if (p == std::string::npos)
        return fallback;

    ++p;

    while (
        p < json.size() &&
        (json[p] == ' ' ||
         json[p] == '\t' ||
         json[p] == '\r' ||
         json[p] == '\n')
    )
    {
        ++p;
    }

    if (json.compare(p, 4, "true") == 0)
        return true;

    if (json.compare(p, 5, "false") == 0)
        return false;

    return fallback;
}

AuthResult DoLoginRequest(
    const std::wstring& endpoint,
    const std::wstring& email,
    const std::wstring& password
)
{
    AuthResult result;

    if (email.empty() || password.empty())
    {
        result.message = L"Introduz o email e a palavra-passe.";
        return result;
    }

    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof(parts);

    wchar_t host[512]{};
    wchar_t path[2048]{};

    parts.lpszHostName = host;
    parts.dwHostNameLength = static_cast<DWORD>(std::size(host));
    parts.lpszUrlPath = path;
    parts.dwUrlPathLength = static_cast<DWORD>(std::size(path));

    if (!WinHttpCrackUrl(endpoint.c_str(), 0, 0, &parts))
    {
        result.message = L"Configuração do serviço inválida.";
        return result;
    }

    const std::wstring hostName(host, parts.dwHostNameLength);
    std::wstring requestPath(path, parts.dwUrlPathLength);

    if (requestPath.empty())
        requestPath = L"/projectflex/api/auth/login";

    HINTERNET session = WinHttpOpen(
        L"ProjectFlex/1.0",
        WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0
    );

    if (!session)
    {
        result.message = L"Não foi possível iniciar a ligação.";
        return result;
    }

    WinHttpSetTimeouts(session, 5000, 5000, 8000, 8000);

    HINTERNET connection = WinHttpConnect(
        session,
        hostName.c_str(),
        parts.nPort,
        0
    );

    if (!connection)
    {
        WinHttpCloseHandle(session);
        result.message = L"Não foi possível contactar o serviço.";
        return result;
    }

    const DWORD flags =
        (parts.nScheme == INTERNET_SCHEME_HTTPS)
        ? WINHTTP_FLAG_SECURE
        : 0;

    HINTERNET request = WinHttpOpenRequest(
        connection,
        L"POST",
        requestPath.c_str(),
        nullptr,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        flags
    );

    if (!request)
    {
        WinHttpCloseHandle(connection);
        WinHttpCloseHandle(session);
        result.message = L"Não foi possível preparar o pedido.";
        return result;
    }

    const std::string emailUtf8 = JsonEscape(WideToUtf8(email));
    const std::string passUtf8 = JsonEscape(WideToUtf8(password));

    const std::string body =
        "{\"email\":\"" + emailUtf8 +
        "\",\"password\":\"" + passUtf8 +
        "\",\"client\":\"ProjectFlex-1.0\"}";

    const wchar_t* headers =
        L"Content-Type: application/json\r\n"
        L"Accept: application/json\r\n";

    BOOL ok = WinHttpSendRequest(
        request,
        headers,
        static_cast<DWORD>(-1L),
        const_cast<char*>(body.data()),
        static_cast<DWORD>(body.size()),
        static_cast<DWORD>(body.size()),
        0
    );

    if (ok)
        ok = WinHttpReceiveResponse(request, nullptr);

    if (!ok)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);
        WinHttpCloseHandle(session);
        result.message = L"Não foi possível validar a conta.";
        return result;
    }

    DWORD statusCode = 0;
    DWORD statusSize = sizeof(statusCode);

    WinHttpQueryHeaders(
        request,
        WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
        WINHTTP_HEADER_NAME_BY_INDEX,
        &statusCode,
        &statusSize,
        WINHTTP_NO_HEADER_INDEX
    );

    std::string response;

    for (;;)
    {
        DWORD available = 0;

        if (!WinHttpQueryDataAvailable(request, &available) || available == 0)
            break;

        std::vector<char> buffer(static_cast<size_t>(available));
        DWORD read = 0;

        if (!WinHttpReadData(
                request,
                buffer.data(),
                available,
                &read) ||
            read == 0)
        {
            break;
        }

        response.append(buffer.data(), read);
    }

    WinHttpCloseHandle(request);
    WinHttpCloseHandle(connection);
    WinHttpCloseHandle(session);

    result.success =
        statusCode >= 200 &&
        statusCode < 300 &&
        FindJsonBool(response, "success", false);

    result.displayName =
        Utf8ToWide(FindJsonString(response, "displayName"));

    result.message =
        Utf8ToWide(FindJsonString(response, "message"));

    result.token =
        Utf8ToWide(FindJsonString(response, "token"));

    if (!result.success && result.message.empty())
    {
        switch (statusCode)
        {
        case 400:
            result.message = L"Email e palavra-passe são obrigatórios.";
            break;

        case 401:
            result.message = L"Email ou palavra-passe incorretos.";
            break;

        case 429:
            result.message = L"Demasiadas tentativas. Tenta novamente mais tarde.";
            break;

        default:
            result.message = L"Não foi possível iniciar sessão.";
            break;
        }
    }

    return result;
}

// 1.º método: associação HTTPS do Windows.
bool OpenUrlWithShellExecuteEx(const std::wstring& url)
{
    SHELLEXECUTEINFOW info{};
    info.cbSize = sizeof(info);
    info.fMask = SEE_MASK_FLAG_NO_UI;
    info.hwnd = nullptr;
    info.lpVerb = L"open";
    info.lpFile = url.c_str();
    info.nShow = SW_SHOWNORMAL;

    return ShellExecuteExW(&info) != FALSE;
}

// 2.º método: ShellExecuteW clássico.
bool OpenUrlWithShellExecute(const std::wstring& url)
{
    const HINSTANCE result = ShellExecuteW(
        nullptr,
        L"open",
        url.c_str(),
        nullptr,
        nullptr,
        SW_SHOWNORMAL
    );

    return reinterpret_cast<INT_PTR>(result) > 32;
}

// 3.º método: pedir ao Explorer do Windows para abrir o URL.
bool OpenUrlWithExplorer(const std::wstring& url)
{
    std::wstring command =
        L"explorer.exe \"" + url + L"\"";

    STARTUPINFOW si{};
    si.cb = sizeof(si);

    PROCESS_INFORMATION pi{};

    BOOL ok = CreateProcessW(
        nullptr,
        command.data(),
        nullptr,
        nullptr,
        FALSE,
        CREATE_NO_WINDOW,
        nullptr,
        nullptr,
        &si,
        &pi
    );

    if (!ok)
        return false;

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;
}

} // namespace

AuthResult AuthenticateLauncherAccount(
    const std::wstring& email,
    const std::wstring& password
)
{
    const std::wstring endpoint = GetAuthUrl();

    if (endpoint.empty())
    {
        AuthResult result;
        result.message =
            L"O serviço de autenticação ainda não está configurado.";
        return result;
    }

    return DoLoginRequest(
        endpoint,
        email,
        password
    );
}

bool OpenAccountCreationPage(HWND owner)
{
    (void)owner;

    const std::wstring url = GetAccountUrl();

    if (url.empty())
        return false;

    if (OpenUrlWithShellExecuteEx(url))
        return true;

    if (OpenUrlWithShellExecute(url))
        return true;

    if (OpenUrlWithExplorer(url))
        return true;

    return false;
}


namespace
{
constexpr wchar_t CREDENTIAL_TARGET[] =
    L"ProjectFlexLauncher.Login";
}

bool SaveLauncherCredentials(
    const std::wstring& email,
    const std::wstring& password
)
{
    if (email.empty() || password.empty())
        return false;

    CREDENTIALW credential{};
    credential.Type = CRED_TYPE_GENERIC;
    credential.TargetName =
        const_cast<LPWSTR>(CREDENTIAL_TARGET);
    credential.UserName =
        const_cast<LPWSTR>(email.c_str());
    credential.CredentialBlobSize =
        static_cast<DWORD>(
            password.size() * sizeof(wchar_t)
        );
    credential.CredentialBlob =
        reinterpret_cast<LPBYTE>(
            const_cast<wchar_t*>(password.data())
        );
    credential.Persist =
        CRED_PERSIST_LOCAL_MACHINE;

    return CredWriteW(
        &credential,
        0
    ) != FALSE;
}

bool LoadLauncherCredentials(
    std::wstring& email,
    std::wstring& password
)
{
    email.clear();
    password.clear();

    PCREDENTIALW credential = nullptr;

    if (!CredReadW(
            CREDENTIAL_TARGET,
            CRED_TYPE_GENERIC,
            0,
            &credential))
    {
        return false;
    }

    if (credential->UserName)
        email = credential->UserName;

    if (credential->CredentialBlob &&
        credential->CredentialBlobSize >= sizeof(wchar_t))
    {
        const auto* begin =
            reinterpret_cast<const wchar_t*>(
                credential->CredentialBlob
            );

        const size_t count =
            credential->CredentialBlobSize /
            sizeof(wchar_t);

        password.assign(
            begin,
            begin + count
        );
    }

    CredFree(credential);

    return !email.empty() &&
           !password.empty();
}

void ClearLauncherCredentials()
{
    CredDeleteW(
        CREDENTIAL_TARGET,
        CRED_TYPE_GENERIC,
        0
    );
}
