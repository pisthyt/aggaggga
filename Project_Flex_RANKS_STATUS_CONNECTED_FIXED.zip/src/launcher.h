﻿#pragma once

#include <windows.h>
#include <filesystem>
#include <string>
#include <vector>

struct LaunchResult {
    bool success = false;
    DWORD processId = 0;
    std::wstring message;
};

LaunchResult LaunchFortnite(
    const std::filesystem::path& fortnitePath,
    const std::vector<std::wstring>& extraArgs = {}
);
