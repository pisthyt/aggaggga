﻿#pragma once

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <string>

struct ServerBuildInfo
{
    std::wstring baseUrl;
    std::wstring manifestUrl;
    std::wstring name;
    std::wstring subtitle;
    std::wstring installFolder;
};

struct BuildDownloadProgress
{
    std::uint64_t downloadedBytes = 0;
    std::uint64_t totalBytes = 0;

    std::size_t fileIndex = 0;
    std::size_t fileCount = 0;

    std::wstring currentFile;

    double bytesPerSecond = 0.0;
};

using BuildDownloadProgressCallback =
    std::function<void(const BuildDownloadProgress&)>;

bool ReadServerBuildInfo(
    ServerBuildInfo& info,
    std::wstring& error
);

bool DownloadServerBuildFolder(
    const ServerBuildInfo& info,
    const std::filesystem::path& userDataDirectory,
    std::atomic_bool& cancelRequested,
    const BuildDownloadProgressCallback& progressCallback,
    std::filesystem::path& buildDirectory,
    std::wstring& error
);
