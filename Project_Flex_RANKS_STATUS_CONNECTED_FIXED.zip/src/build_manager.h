﻿#pragma once

#include <filesystem>
#include <string>
#include <vector>

struct BuildEntry {
    std::wstring name;
    std::wstring subtitle;
    std::wstring path;
};

std::vector<BuildEntry> LoadBuildLibrary(
    const std::filesystem::path& appDirectory
);

bool SaveBuildLibrary(
    const std::filesystem::path& appDirectory,
    const std::vector<BuildEntry>& builds
);

bool CreateBuildEntryFromFolder(
    const std::wstring& selectedFolder,
    BuildEntry& outBuild,
    std::wstring& error
);
