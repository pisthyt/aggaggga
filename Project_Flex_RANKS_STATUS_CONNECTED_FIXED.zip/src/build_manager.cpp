﻿#include "build_manager.h"

#include <windows.h>
#include <algorithm>
#include <cwctype>

namespace {

std::filesystem::path GetLibraryIni(
    const std::filesystem::path& appDirectory
) {
    return appDirectory / L"library.ini";
}

bool FindShippingExe(
    const std::filesystem::path& root,
    std::filesystem::path& exePath
) {
    std::error_code ec;

    const std::vector<std::filesystem::path> candidates = {
        root / L"FortniteGame" / L"Binaries" / L"Win64" / L"FortniteClient-Win64-Shipping.exe",
        root / L"Binaries" / L"Win64" / L"FortniteClient-Win64-Shipping.exe",
        root / L"FortniteClient-Win64-Shipping.exe"
    };

    for (const auto& candidate : candidates) {
        ec.clear();
        if (std::filesystem::exists(candidate, ec) &&
            std::filesystem::is_regular_file(candidate, ec)) {
            exePath = candidate;
            return true;
        }
    }

    ec.clear();

    std::filesystem::recursive_directory_iterator it(
        root,
        std::filesystem::directory_options::skip_permission_denied,
        ec
    );

    const std::filesystem::recursive_directory_iterator end;

    for (; !ec && it != end; it.increment(ec)) {
        if (it.depth() > 5) {
            it.disable_recursion_pending();
            continue;
        }

        if (!it->is_regular_file(ec))
            continue;

        if (_wcsicmp(
                it->path().filename().c_str(),
                L"FortniteClient-Win64-Shipping.exe"
            ) == 0) {
            exePath = it->path();
            return true;
        }
    }

    return false;
}

std::wstring GuessVersion(const std::filesystem::path& path) {
    std::wstring text = path.filename().wstring();

    // Procura algo com formato aproximado NN.NN no nome da pasta.
    for (size_t i = 0; i + 3 < text.size(); ++i) {
        if (!iswdigit(text[i])) continue;

        size_t j = i;
        while (j < text.size() && iswdigit(text[j])) ++j;

        if (j < text.size() && text[j] == L'.') {
            size_t k = j + 1;
            while (k < text.size() && iswdigit(text[k])) ++k;

            if (k > j + 1) {
                return text.substr(i, k - i);
            }
        }
    }

    return L"Build";
}

} // namespace

std::vector<BuildEntry> LoadBuildLibrary(
    const std::filesystem::path& appDirectory
) {
    std::vector<BuildEntry> builds;
    const auto ini = GetLibraryIni(appDirectory);

    const int count = GetPrivateProfileIntW(
        L"Library",
        L"Count",
        0,
        ini.c_str()
    );

    for (int i = 0; i < count; ++i) {
        const std::wstring section = L"Build" + std::to_wstring(i);

        wchar_t name[256]{};
        wchar_t subtitle[256]{};
        wchar_t path[2048]{};

        GetPrivateProfileStringW(section.c_str(), L"Name", L"Fortnite Build", name, 256, ini.c_str());
        GetPrivateProfileStringW(section.c_str(), L"Subtitle", L"Importada", subtitle, 256, ini.c_str());
        GetPrivateProfileStringW(section.c_str(), L"Path", L"", path, 2048, ini.c_str());

        if (path[0] != L'\0') {
            builds.push_back({
                name,
                subtitle,
                path
            });
        }
    }

    return builds;
}

bool SaveBuildLibrary(
    const std::filesystem::path& appDirectory,
    const std::vector<BuildEntry>& builds
) {
    const auto ini = GetLibraryIni(appDirectory);

    // Limpa as secções anteriores até um limite razoável.
    for (int i = 0; i < 32; ++i) {
        const std::wstring section = L"Build" + std::to_wstring(i);
        WritePrivateProfileStringW(section.c_str(), nullptr, nullptr, ini.c_str());
    }

    WritePrivateProfileStringW(
        L"Library",
        L"Count",
        std::to_wstring(builds.size()).c_str(),
        ini.c_str()
    );

    for (size_t i = 0; i < builds.size(); ++i) {
        const std::wstring section = L"Build" + std::to_wstring(i);

        WritePrivateProfileStringW(section.c_str(), L"Name", builds[i].name.c_str(), ini.c_str());
        WritePrivateProfileStringW(section.c_str(), L"Subtitle", builds[i].subtitle.c_str(), ini.c_str());
        WritePrivateProfileStringW(section.c_str(), L"Path", builds[i].path.c_str(), ini.c_str());
    }

    return true;
}

bool CreateBuildEntryFromFolder(
    const std::wstring& selectedFolder,
    BuildEntry& outBuild,
    std::wstring& error
) {
    if (selectedFolder.empty()) {
        error = L"Nenhuma pasta foi selecionada.";
        return false;
    }

    const std::filesystem::path root(selectedFolder);
    std::filesystem::path exe;

    if (!FindShippingExe(root, exe)) {
        error =
            L"Essa pasta não parece ser uma build válida: "
            L"FortniteClient-Win64-Shipping.exe não foi encontrado.";
        return false;
    }

    const std::wstring version = GuessVersion(root);

    outBuild.path = root.wstring();

    if (version == L"14.40") {
        outBuild.name = L"Fortnite 14.40";
        outBuild.subtitle = L"Capítulo 2, Temporada 4";
    } else if (version != L"Build") {
        outBuild.name = L"Fortnite " + version;
        outBuild.subtitle = L"Build importada";
    } else {
        outBuild.name = L"Fortnite Build";
        outBuild.subtitle = L"Build importada";
    }

    error.clear();
    return true;
}
