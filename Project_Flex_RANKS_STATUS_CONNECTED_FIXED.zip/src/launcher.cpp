﻿#include "launcher.h"

#include <system_error>
#include <vector>

namespace {

bool ResolveFortniteExecutable(
    const std::filesystem::path& input,
    std::filesystem::path& output
) {
    std::error_code ec;

    if (std::filesystem::is_regular_file(input, ec)) {
        if (_wcsicmp(
                input.filename().c_str(),
                L"FortniteClient-Win64-Shipping.exe"
            ) == 0) {
            output = input;
            return true;
        }
    }

    const std::vector<std::filesystem::path> candidates = {
        input / L"FortniteGame" / L"Binaries" / L"Win64" / L"FortniteClient-Win64-Shipping.exe",
        input / L"Binaries" / L"Win64" / L"FortniteClient-Win64-Shipping.exe",
        input / L"FortniteClient-Win64-Shipping.exe"
    };

    for (const auto& candidate : candidates) {
        ec.clear();
        if (std::filesystem::exists(candidate, ec) &&
            std::filesystem::is_regular_file(candidate, ec)) {
            output = candidate;
            return true;
        }
    }

    ec.clear();

    std::filesystem::recursive_directory_iterator it(
        input,
        std::filesystem::directory_options::skip_permission_denied,
        ec
    );

    const std::filesystem::recursive_directory_iterator end;

    for (; !ec && it != end; it.increment(ec)) {
        if (it.depth() > 5) {
            it.disable_recursion_pending();
            continue;
        }

        if (!it->is_regular_file(ec))
            continue;

        if (_wcsicmp(
                it->path().filename().c_str(),
                L"FortniteClient-Win64-Shipping.exe"
            ) == 0) {
            output = it->path();
            return true;
        }
    }

    return false;
}

std::wstring QuoteArg(const std::wstring& arg) {
    if (arg.find_first_of(L" \t\"") == std::wstring::npos) {
        return arg;
    }

    std::wstring out = L"\"";
    for (wchar_t ch : arg) {
        if (ch == L'"') out += L'\\';
        out += ch;
    }
    out += L"\"";
    return out;
}

} // namespace

LaunchResult LaunchFortnite(
    const std::filesystem::path& fortnitePath,
    const std::vector<std::wstring>& extraArgs
) {
    LaunchResult result;

    std::filesystem::path exePath;
    if (!ResolveFortniteExecutable(fortnitePath, exePath)) {
        result.message =
            L"Não foi encontrado FortniteClient-Win64-Shipping.exe "
            L"no caminho configurado.";
        return result;
    }

    // Argumentos base normais do cliente.
    // Argumentos base do cliente.
    std::vector<std::wstring> args = {
        L"-AUTH_LOGIN=unused",
        L"-AUTH_PASSWORD=unused",
        L"-AUTH_TYPE=epic",
        L"-epicapp=Fortnite",
        L"-epicenv=Prod",
        L"-epiclocale=pt",
        L"-epicportal",
        L"-skippatchcheck",
        L"-nosplash"
    };

    for (const auto& arg : extraArgs) {
        args.push_back(arg);
    }

    std::wstring commandLine = QuoteArg(exePath.wstring());
    for (const auto& arg : args) {
        commandLine += L" ";
        commandLine += QuoteArg(arg);
    }

    std::vector<wchar_t> mutableCommand(
        commandLine.begin(),
        commandLine.end()
    );
    mutableCommand.push_back(L'\0');

    STARTUPINFOW startupInfo{};
    startupInfo.cb = sizeof(startupInfo);

    PROCESS_INFORMATION processInfo{};

    const std::filesystem::path workingDirectory = exePath.parent_path();

    BOOL ok = CreateProcessW(
        exePath.c_str(),
        mutableCommand.data(),
        nullptr,
        nullptr,
        FALSE,
        CREATE_UNICODE_ENVIRONMENT,
        nullptr,
        workingDirectory.c_str(),
        &startupInfo,
        &processInfo
    );

    if (!ok) {
        result.message =
            L"CreateProcessW falhou. Código Win32: " +
            std::to_wstring(GetLastError());
        return result;
    }

    result.success = true;
    result.processId = processInfo.dwProcessId;
    result.message = L"Build iniciada.";

    CloseHandle(processInfo.hThread);
    CloseHandle(processInfo.hProcess);

    return result;
}
