﻿// ============================================
// Project Flex Launcher
// create by pisth_YT
// ============================================

#define UNICODE
#define _UNICODE

#include <windows.h>
#include <windowsx.h>
#include <gdiplus.h>
#include <shobjidl.h>
#include <filesystem>
#include <string>
#include <memory>
#include <thread>
#include <vector>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <iterator>
#include <cwchar>
#include <cmath>
#include "launcher.h"
#include "auth_client.h"
#include "build_manager.h"
#include "download_manager.h"
#include "projectflex_api.h"
#include "resource.h"

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")

using namespace Gdiplus;
using std::wstring;

constexpr int WINDOW_WIDTH  = 1360;
constexpr int WINDOW_HEIGHT = 800;

const Color BG_COLOR(255, 10, 10, 10);
const Color CARD_COLOR(255, 17, 17, 17);
const Color CARD_HOVER(255, 26, 26, 26);
const Color TEXT_WHITE(255, 255, 255, 255);
const Color TEXT_GRAY(255, 136, 136, 136);
const Color ACCENT_BLUE(255, 0, 212, 255);
const Color ACCENT_PURPLE(255, 168, 85, 247);
const Color GREEN_ONLINE(255, 34, 197, 94);
const Color BORDER_COLOR(30, 255, 255, 255);

struct AppState {
    int activeTab = 0;             // 0=Home 1=Library 2=Status 3=Ranks 4=Cups 5=Settings
    int activeFilter = 0;          // 0=Todos 1=Europa
    int activeCupView = 0;         // 0=Torneios 1=Leaderboard
    bool settingsOpen = false;
    int activeSettingSection = 0;  // 0=Info 1=Appearance 2=Game
    int hoverTab = -1;
    bool toggle1 = false, toggle2 = false, toggle3 = false;
    bool toggle4 = false, toggle5 = false, toggle6 = false;
};

AppState g_state;

HINSTANCE g_hInstance = nullptr;
HWND g_hwnd = nullptr;
ULONG_PTR g_gdiplusToken = 0;

std::unique_ptr<Image> g_flexLogo;
std::unique_ptr<Image> g_nexusWar;
std::unique_ptr<Image> g_introBackground;

wstring g_fortnitePath;
wstring g_launchStatus = L"Pronto";
bool g_launching = false;
bool g_launchOk = false;

// Login. A criação de contas só é feita através do bot do serviço.
bool g_authenticated = false;
bool g_authenticating = false;
wstring g_loginEmail;
wstring g_loginPassword;
wstring g_loggedUser;
wstring g_loginStatus;
bool g_loginError = false;
bool g_rememberLogin = true;
bool g_autoLoginPending = false;
bool g_downloadingBuild = false;

std::atomic_bool g_cancelBuildDownload{ false };
std::mutex g_downloadProgressMutex;
BuildDownloadProgress g_downloadProgress;

// Dados reais da API Project Flex.
std::mutex g_apiDataMutex;

std::vector<ProjectFlexRankPlayer> g_rankPlayers;
bool g_ranksLoading = false;
bool g_ranksLoaded = false;
std::wstring g_ranksError;

ProjectFlexStatusResult g_serverStatus;
bool g_statusLoading = false;
bool g_statusLoaded = false;
std::wstring g_statusError;

// Biblioteca de builds.
std::vector<BuildEntry> g_builds;
int g_selectedBuild = 0;

// Animação.
double g_animSeconds = 0.0;
float g_pageFade = 1.0f;
bool g_showSplash = true;
ULONGLONG g_startTick = 0;

// 0=nenhum; 1=caminho Fortnite; 10=email; 11=palavra-passe
int g_activeTextInput = 10;
int g_settingsUnderlayTab = 0;

constexpr UINT_PTR TIMER_ANIMATION = 1;
constexpr UINT WM_APP_LAUNCH_DONE = WM_APP + 1;
constexpr UINT WM_APP_LAUNCH_FAIL = WM_APP + 2;
constexpr UINT WM_APP_LOGIN_DONE  = WM_APP + 3;
constexpr UINT WM_APP_LOGIN_FAIL  = WM_APP + 4;
constexpr UINT WM_APP_BUILD_DOWNLOAD_DONE = WM_APP + 5;
constexpr UINT WM_APP_BUILD_DOWNLOAD_FAIL = WM_APP + 6;
constexpr UINT WM_APP_RANKS_DONE = WM_APP + 7;
constexpr UINT WM_APP_STATUS_DONE = WM_APP + 8;

// ------------------------------------------------------------
// Utilitários gerais
// ------------------------------------------------------------

static std::filesystem::path GetExeDirectory() {
    wchar_t buffer[MAX_PATH]{};
    GetModuleFileNameW(nullptr, buffer, MAX_PATH);
    return std::filesystem::path(buffer).parent_path();
}

static std::filesystem::path GetUserDataDirectory() {
    wchar_t buffer[32768]{};

    const DWORD length = GetEnvironmentVariableW(
        L"LOCALAPPDATA",
        buffer,
        static_cast<DWORD>(std::size(buffer))
    );

    std::filesystem::path base;

    if (length > 0 &&
        length < std::size(buffer)) {
        base = buffer;
    }
    else {
        std::error_code ec;
        base =
            std::filesystem::temp_directory_path(ec);
    }

    const auto dir =
        base / L"ProjectFlex";

    std::error_code ec;

    std::filesystem::create_directories(
        dir,
        ec
    );

    return dir;
}

static std::filesystem::path GetIniPath() {
    return GetUserDataDirectory() /
           L"ProjectFlex.ini";
}

static wstring ReadIniString(const wchar_t* section, const wchar_t* key, const wchar_t* fallback) {
    wchar_t buffer[2048]{};
    GetPrivateProfileStringW(section, key, fallback, buffer, 2048, GetIniPath().c_str());
    return buffer;
}

static bool ReadIniBool(const wchar_t* section, const wchar_t* key, bool fallback) {
    return GetPrivateProfileIntW(section, key, fallback ? 1 : 0, GetIniPath().c_str()) != 0;
}

static void SaveSettings() {
    const auto ini = GetIniPath();
    WritePrivateProfileStringW(L"Game", L"FortnitePath", g_fortnitePath.c_str(), ini.c_str());

    WritePrivateProfileStringW(L"Appearance", L"MinimizeOnLaunch", g_state.toggle1 ? L"1" : L"0", ini.c_str());
    WritePrivateProfileStringW(L"Appearance", L"AlwaysOnTop", g_state.toggle2 ? L"1" : L"0", ini.c_str());
    WritePrivateProfileStringW(L"Appearance", L"ReduceMotion", g_state.toggle3 ? L"1" : L"0", ini.c_str());

    WritePrivateProfileStringW(L"Game", L"ResetOnRelease", g_state.toggle4 ? L"1" : L"0", ini.c_str());
    WritePrivateProfileStringW(L"Game", L"DisablePreEdit", g_state.toggle5 ? L"1" : L"0", ini.c_str());
    WritePrivateProfileStringW(L"Game", L"EditOnRelease", g_state.toggle6 ? L"1" : L"0", ini.c_str());
}

static void LoadSettings() {
    g_fortnitePath = ReadIniString(L"Game", L"FortnitePath", L"");
    g_state.toggle1 = ReadIniBool(L"Appearance", L"MinimizeOnLaunch", false);
    g_state.toggle2 = ReadIniBool(L"Appearance", L"AlwaysOnTop", false);
    g_state.toggle3 = ReadIniBool(L"Appearance", L"ReduceMotion", false);

    g_state.toggle4 = ReadIniBool(L"Game", L"ResetOnRelease", false);
    g_state.toggle5 = ReadIniBool(L"Game", L"DisablePreEdit", false);
    g_state.toggle6 = ReadIniBool(L"Game", L"EditOnRelease", false);
}

static void BuildRoundedPath(GraphicsPath& path, const Rect& rect, int radius) {
    path.Reset();

    if (radius <= 0) {
        path.AddRectangle(rect);
        return;
    }

    const int maxRadius = (std::min)(rect.Width, rect.Height) / 2;
    radius = (std::min)(radius, maxRadius);
    const int d = radius * 2;

    path.AddArc(rect.X, rect.Y, d, d, 180, 90);
    path.AddArc(rect.GetRight() - d, rect.Y, d, d, 270, 90);
    path.AddArc(rect.GetRight() - d, rect.GetBottom() - d, d, d, 0, 90);
    path.AddArc(rect.X, rect.GetBottom() - d, d, d, 90, 90);
    path.CloseFigure();
}

void FillRoundedRect(Graphics& g, Brush* brush, Rect rect, int radius) {
    GraphicsPath path;
    BuildRoundedPath(path, rect, radius);
    g.FillPath(brush, &path);
}

void DrawRoundedRect(Graphics& g, Pen* pen, Rect rect, int radius) {
    GraphicsPath path;
    BuildRoundedPath(path, rect, radius);
    g.DrawPath(pen, &path);
}

void DrawTextStr(
    Graphics& g,
    const wstring& text,
    Font* font,
    Brush* brush,
    RectF rect,
    StringAlignment align = StringAlignmentNear
) {
    StringFormat fmt;
    fmt.SetAlignment(align);
    fmt.SetLineAlignment(StringAlignmentNear);
    fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    fmt.SetFormatFlags(StringFormatFlagsNoWrap);
    g.DrawString(text.c_str(), -1, font, rect, &fmt, brush);
}

static void DrawCenteredText(
    Graphics& g,
    const wstring& text,
    Font* font,
    Brush* brush,
    const RectF& rect
) {
    StringFormat fmt;
    fmt.SetAlignment(StringAlignmentCenter);
    fmt.SetLineAlignment(StringAlignmentCenter);
    fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    g.DrawString(text.c_str(), -1, font, rect, &fmt, brush);
}

static void DrawCoverImage(Graphics& g, Image* image, Rect dest, int radius) {
    if (!image || image->GetLastStatus() != Ok || image->GetWidth() == 0 || image->GetHeight() == 0) {
        LinearGradientBrush fallback(
            Point(dest.X, dest.Y),
            Point(dest.GetRight(), dest.GetBottom()),
            Color(255, 0, 80, 120),
            Color(255, 96, 36, 145)
        );
        FillRoundedRect(g, &fallback, dest, radius);
        return;
    }

    const REAL srcW = static_cast<REAL>(image->GetWidth());
    const REAL srcH = static_cast<REAL>(image->GetHeight());
    const REAL dstRatio = static_cast<REAL>(dest.Width) / static_cast<REAL>(dest.Height);
    const REAL srcRatio = srcW / srcH;

    REAL sx = 0.0f, sy = 0.0f, sw = srcW, sh = srcH;

    if (srcRatio > dstRatio) {
        sw = srcH * dstRatio;
        sx = (srcW - sw) * 0.5f;
    } else {
        sh = srcW / dstRatio;
        sy = (srcH - sh) * 0.5f;
    }

    GraphicsState saved = g.Save();
    GraphicsPath clip;
    BuildRoundedPath(clip, dest, radius);
    g.SetClip(&clip, CombineModeReplace);
    g.DrawImage(
        image,
        dest,
        static_cast<INT>(sx),
        static_cast<INT>(sy),
        static_cast<INT>(sw),
        static_cast<INT>(sh),
        UnitPixel
    );
    g.Restore(saved);
}

static wstring Ellipsize(const wstring& s, size_t maxChars);

static void DrawContainImage(
    Graphics& g,
    Image* image,
    const Rect& box
) {
    if (!image ||
        image->GetLastStatus() != Ok ||
        image->GetWidth() == 0 ||
        image->GetHeight() == 0) {
        return;
    }

    const REAL srcW = static_cast<REAL>(image->GetWidth());
    const REAL srcH = static_cast<REAL>(image->GetHeight());
    const REAL scale = (std::min)(
        static_cast<REAL>(box.Width) / srcW,
        static_cast<REAL>(box.Height) / srcH
    );

    const INT drawW = static_cast<INT>(srcW * scale);
    const INT drawH = static_cast<INT>(srcH * scale);

    const Rect dest(
        box.X + (box.Width - drawW) / 2,
        box.Y + (box.Height - drawH) / 2,
        drawW,
        drawH
    );

    g.DrawImage(image, dest);
}

static bool PtInRectI(const Rect& r, int x, int y) {
    return x >= r.X && x < r.GetRight() && y >= r.Y && y < r.GetBottom();
}

static Rect GetTabRect(int index, int clientWidth) {
    (void)clientWidth;
    return Rect(24, 164 + index * 56, 188, 44);
}

static Rect GetHomeLaunchRect(int w, int h) {
    (void)w;
    (void)h;

    return Rect(
        282,
        430,
        178,
        46
    );
}

static Rect GetHomeDownloadRect(int w, int h) {
    (void)w;
    (void)h;

    return Rect(
        472,
        430,
        205,
        46
    );
}

static Rect GetStatusFilterRect(int index) {
    return index == 0
        ? Rect(270, 216, 76, 34)
        : Rect(356, 216, 92, 34);
}

static Rect GetCupToggleRect(int index, int w) {
    const int right = w - 48;
    return index == 0
        ? Rect(right - 238, 142, 112, 34)
        : Rect(right - 120, 142, 112, 34);
}

static Rect GetSettingsCardRect(int clientWidth, int clientHeight) {
    return Rect(
        (clientWidth - 760) / 2,
        (clientHeight - 520) / 2,
        760,
        520
    );
}

static BuildDownloadProgress GetDownloadProgressSnapshot() {
    std::lock_guard<std::mutex> lock(
        g_downloadProgressMutex
    );

    return g_downloadProgress;
}

static std::wstring FormatBytes(
    std::uint64_t bytes
) {
    const double value =
        static_cast<double>(bytes);

    std::wostringstream stream;
    stream << std::fixed;

    if (bytes >=
        1024ull * 1024ull * 1024ull)
    {
        stream
            << std::setprecision(2)
            << (
                value /
                (1024.0 * 1024.0 * 1024.0)
            )
            << L" GB";
    }
    else if (bytes >=
             1024ull * 1024ull)
    {
        stream
            << std::setprecision(1)
            << (
                value /
                (1024.0 * 1024.0)
            )
            << L" MB";
    }
    else
    {
        stream
            << std::setprecision(0)
            << (
                value /
                1024.0
            )
            << L" KB";
    }

    return stream.str();
}

static std::wstring FormatSpeed(
    double bytesPerSecond
) {
    if (bytesPerSecond <= 0.0)
        return L"-- MB/s";

    std::wostringstream stream;
    stream
        << std::fixed
        << std::setprecision(1)
        << (
            bytesPerSecond /
            (1024.0 * 1024.0)
        )
        << L" MB/s";

    return stream.str();
}

static void DrawDownloadProgress(
    Graphics& g,
    const Rect& area
) {
    const BuildDownloadProgress progress =
        GetDownloadProgressSnapshot();

    const double ratio =
        progress.totalBytes > 0
        ? (
            static_cast<double>(
                progress.downloadedBytes
            ) /
            static_cast<double>(
                progress.totalBytes
            )
        )
        : 0.0;

    const int percentage =
        static_cast<int>(
            (std::min)(
                1.0,
                (std::max)(0.0, ratio)
            ) *
            100.0
        );

    Font infoFont(
        L"Segoe UI",
        9,
        FontStyleBold,
        UnitPixel
    );

    Font fileFont(
        L"Segoe UI",
        8,
        FontStyleRegular,
        UnitPixel
    );

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(
        Color(255, 135, 143, 160)
    );

    std::wstring line =
        std::to_wstring(percentage) +
        L"%  •  " +
        FormatBytes(
            progress.downloadedBytes
        ) +
        L" / " +
        FormatBytes(
            progress.totalBytes
        ) +
        L"  •  " +
        FormatSpeed(
            progress.bytesPerSecond
        );

    DrawTextStr(
        g,
        line,
        &infoFont,
        &white,
        RectF(
            static_cast<REAL>(area.X),
            static_cast<REAL>(area.Y),
            static_cast<REAL>(area.Width),
            18
        )
    );

    std::wstring fileLine;

    if (progress.fileCount > 0)
    {
        fileLine =
            L"Ficheiro " +
            std::to_wstring(
                progress.fileIndex
            ) +
            L"/" +
            std::to_wstring(
                progress.fileCount
            );

        if (!progress.currentFile.empty())
        {
            fileLine +=
                L"  •  " +
                Ellipsize(
                    progress.currentFile,
                    58
                );
        }
    }
    else
    {
        fileLine =
            L"A carregar manifesto...";
    }

    DrawTextStr(
        g,
        fileLine,
        &fileFont,
        &muted,
        RectF(
            static_cast<REAL>(area.X),
            static_cast<REAL>(area.Y + 20),
            static_cast<REAL>(area.Width),
            16
        )
    );

    Rect track(
        area.X,
        area.Y + 39,
        area.Width,
        5
    );

    SolidBrush trackBg(
        Color(255, 31, 34, 43)
    );

    FillRoundedRect(
        g,
        &trackBg,
        track,
        3
    );

    const int filled =
        static_cast<int>(
            ratio *
            static_cast<double>(
                track.Width
            )
        );

    if (filled > 0)
    {
        LinearGradientBrush bar(
            Point(track.X, track.Y),
            Point(track.GetRight(), track.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(
            g,
            &bar,
            Rect(
                track.X,
                track.Y,
                (std::max)(3, filled),
                track.Height
            ),
            3
        );
    }
}

static void ApplyAlwaysOnTop() {
    SetWindowPos(
        g_hwnd,
        g_state.toggle2 ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE
    );
}

static std::unique_ptr<Image> LoadImageWithFallback(const wchar_t* absolutePath, const wchar_t* relativePath) {
    std::unique_ptr<Image> image;

    if (absolutePath && absolutePath[0] != L'\0') {
        image.reset(
            Image::FromFile(
                absolutePath,
                FALSE
            )
        );

        if (image &&
            image->GetLastStatus() == Ok) {
            return image;
        }
    }

    const auto fallback =
        GetExeDirectory() / relativePath;

    image.reset(
        Image::FromFile(
            fallback.c_str(),
            FALSE
        )
    );
    if (image && image->GetLastStatus() == Ok) {
        return image;
    }

    return nullptr;
}

// ------------------------------------------------------------
// Fundo / estrelas
// ------------------------------------------------------------

void DrawStarField(Graphics& g, int w, int h) {
    SolidBrush bg(Color(255, 7, 8, 12));
    g.FillRectangle(&bg, 0, 0, w, h);

    // Aurora azul no topo.
    LinearGradientBrush topGlow(
        Point(w / 2, 0),
        Point(w / 2, (std::max)(300, h / 2)),
        Color(52, 0, 118, 170),
        Color(0, 7, 8, 12)
    );
    g.FillRectangle(&topGlow, 0, 0, w, (std::max)(300, h / 2));

    // Glow roxo lateral.
    SolidBrush purpleHalo(Color(18, 154, 72, 255));
    g.FillEllipse(&purpleHalo, w - 420, 70, 480, 480);

    SolidBrush cyanHalo(Color(14, 0, 210, 255));
    g.FillEllipse(&cyanHalo, 70, h - 320, 360, 360);

    // Ruído/estrelas discretas.
    unsigned int seed = 0xF1E8A11u;
    auto rnd = [&seed]() -> unsigned int {
        seed = seed * 1664525u + 1013904223u;
        return seed;
    };

    const int drift =
        g_state.toggle3
        ? 0
        : static_cast<int>(g_animSeconds * 2.2);

    for (int i = 0; i < 120; ++i) {
        const int x =
            static_cast<int>(
                rnd() % static_cast<unsigned int>((std::max)(1, w))
            );

        const int baseY =
            42 + static_cast<int>(
                rnd() % static_cast<unsigned int>((std::max)(1, h - 42))
            );

        const int y =
            42 + (
                (baseY - 42 + drift * (1 + (i % 2))) %
                (std::max)(1, h - 42)
            );

        const int alpha =
            18 + static_cast<int>(rnd() % 64u);

        const int size =
            (rnd() % 20u == 0u) ? 2 : 1;

        SolidBrush star(
            Color(
                static_cast<BYTE>(alpha),
                210, 230, 255
            )
        );

        g.FillEllipse(&star, x, y, size, size);
    }
}

// ------------------------------------------------------------
// Top bar / navegação
// ------------------------------------------------------------

void DrawTopBar(Graphics& g, int w) {
    SolidBrush top(Color(238, 8, 9, 13));
    g.FillRectangle(&top, 0, 0, w, 44);

    Pen bottom(Color(30, 255, 255, 255), 1.0f);
    g.DrawLine(&bottom, 0, 43, w, 43);

    Font tiny(L"Segoe UI", 9, FontStyleBold, UnitPixel);
    SolidBrush muted(Color(255, 105, 112, 128));
    SolidBrush online(GREEN_ONLINE);

    DrawTextStr(
        g,
        L"PROJECT FLEX  •  PRIVATE LAUNCHER",
        &tiny,
        &muted,
        RectF(24, 14, 280, 18)
    );

    g.FillEllipse(&online, w - 188, 17, 8, 8);

    DrawTextStr(
        g,
        L"SERVICES ONLINE",
        &tiny,
        &online,
        RectF(
            static_cast<REAL>(w - 170),
            13,
            100,
            18
        )
    );

    Font btnFont(
        L"Segoe UI Symbol",
        14,
        FontStyleRegular,
        UnitPixel
    );

    SolidBrush btn(Color(255, 135, 140, 155));

    DrawCenteredText(
        g, L"−", &btnFont, &btn,
        RectF(static_cast<REAL>(w - 96), 2, 32, 40)
    );

    DrawCenteredText(
        g, L"□", &btnFont, &btn,
        RectF(static_cast<REAL>(w - 64), 2, 32, 40)
    );

    DrawCenteredText(
        g, L"×", &btnFont, &btn,
        RectF(static_cast<REAL>(w - 32), 2, 32, 40)
    );
}

void DrawTabs(Graphics& g, int w) {
    (void)w;

    const wchar_t* labels[] = {
        L"Home",
        L"Library",
        L"Status",
        L"Ranks",
        L"Cups",
        L"Settings"
    };

    const wchar_t* glyphs[] = {
        L"H",
        L"L",
        L"S",
        L"R",
        L"C",
        L"⚙"
    };

    SolidBrush rail(Color(232, 10, 11, 16));
    FillRoundedRect(
        g,
        &rail,
        Rect(12, 58, 214, 684),
        22
    );

    Pen railBorder(
        Color(35, 255, 255, 255),
        1.0f
    );

    DrawRoundedRect(
        g,
        &railBorder,
        Rect(12, 58, 214, 684),
        22
    );

    // Marca, apenas tipográfica. O logo em imagem fica reservado para intro/login.
    Font brand(
        L"Segoe UI",
        24,
        FontStyleBold,
        UnitPixel
    );

    Font brandSmall(
        L"Segoe UI",
        9,
        FontStyleBold,
        UnitPixel
    );

    SolidBrush white(TEXT_WHITE);
    SolidBrush cyan(ACCENT_BLUE);
    SolidBrush muted(Color(255, 100, 107, 124));

    DrawTextStr(
        g,
        L"FLEX",
        &brand,
        &white,
        RectF(30, 82, 100, 34)
    );

    DrawTextStr(
        g,
        L"LAUNCHER",
        &brandSmall,
        &cyan,
        RectF(31, 116, 90, 18)
    );

    Pen separator(Color(28, 255, 255, 255), 1.0f);
    g.DrawLine(&separator, 28, 146, 208, 146);

    Font navFont(
        L"Segoe UI",
        11,
        FontStyleBold,
        UnitPixel
    );

    Font glyphFont(
        L"Segoe UI",
        10,
        FontStyleBold,
        UnitPixel
    );

    SolidBrush inactive(Color(255, 132, 138, 153));
    SolidBrush activeText(TEXT_WHITE);
    SolidBrush activeBg(Color(255, 24, 28, 38));
    SolidBrush hoverBg(Color(170, 20, 23, 31));

    for (int i = 0; i < 6; ++i) {
        Rect r = GetTabRect(i, w);

        if (g_state.activeTab == i) {
            FillRoundedRect(g, &activeBg, r, 12);

            LinearGradientBrush accent(
                Point(r.X, r.Y),
                Point(r.X, r.GetBottom()),
                ACCENT_BLUE,
                ACCENT_PURPLE
            );

            FillRoundedRect(
                g,
                &accent,
                Rect(r.X, r.Y + 7, 4, r.Height - 14),
                2
            );
        }
        else if (g_state.hoverTab == i) {
            FillRoundedRect(g, &hoverBg, r, 12);
        }

        Rect iconBox(
            r.X + 12,
            r.Y + 9,
            26,
            26
        );

        SolidBrush iconBg(
            g_state.activeTab == i
            ? Color(255, 30, 48, 66)
            : Color(255, 20, 22, 29)
        );

        FillRoundedRect(
            g,
            &iconBg,
            iconBox,
            8
        );

        DrawCenteredText(
            g,
            glyphs[i],
            &glyphFont,
            g_state.activeTab == i
                ? static_cast<Brush*>(&cyan)
                : static_cast<Brush*>(&inactive),
            RectF(
                static_cast<REAL>(iconBox.X),
                static_cast<REAL>(iconBox.Y),
                static_cast<REAL>(iconBox.Width),
                static_cast<REAL>(iconBox.Height)
            )
        );

        DrawTextStr(
            g,
            labels[i],
            &navFont,
            g_state.activeTab == i
                ? static_cast<Brush*>(&activeText)
                : static_cast<Brush*>(&inactive),
            RectF(
                static_cast<REAL>(r.X + 50),
                static_cast<REAL>(r.Y + 13),
                120,
                20
            )
        );
    }

    // Perfil no fundo da sidebar.
    Rect profile(24, 662, 188, 60);
    SolidBrush profileBg(Color(255, 16, 18, 24));

    FillRoundedRect(
        g,
        &profileBg,
        profile,
        14
    );

    Pen profileBorder(Color(30, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &profileBorder, profile, 14);

    SolidBrush avatarBg(Color(255, 25, 38, 52));
    g.FillEllipse(&avatarBg, profile.X + 12, profile.Y + 10, 40, 40);

    Font avatarFont(
        L"Segoe UI",
        14,
        FontStyleBold,
        UnitPixel
    );

    DrawCenteredText(
        g,
        L"F",
        &avatarFont,
        &cyan,
        RectF(
            static_cast<REAL>(profile.X + 12),
            static_cast<REAL>(profile.Y + 10),
            40,
            40
        )
    );

    Font nameFont(
        L"Segoe UI",
        10,
        FontStyleBold,
        UnitPixel
    );

    Font subFont(
        L"Segoe UI",
        8,
        FontStyleRegular,
        UnitPixel
    );

    DrawTextStr(
        g,
        g_loggedUser.empty()
            ? L"Project Flex"
            : Ellipsize(g_loggedUser, 16),
        &nameFont,
        &white,
        RectF(
            static_cast<REAL>(profile.X + 62),
            static_cast<REAL>(profile.Y + 13),
            110,
            18
        )
    );

    DrawTextStr(
        g,
        L"Online",
        &subFont,
        &muted,
        RectF(
            static_cast<REAL>(profile.X + 62),
            static_cast<REAL>(profile.Y + 34),
            90,
            16
        )
    );
}

// ------------------------------------------------------------
// Splash + Login
// ------------------------------------------------------------

static Rect GetLoginPanelRect(int w, int h) {
    return Rect(
        (w - 1080) / 2,
        (h - 580) / 2,
        1080,
        580
    );
}

static Rect GetLoginUserRect(int w, int h) {
    Rect p = GetLoginPanelRect(w, h);
    return Rect(
        p.X + 610,
        p.Y + 220,
        390,
        52
    );
}

static Rect GetLoginPasswordRect(int w, int h) {
    Rect p = GetLoginPanelRect(w, h);
    return Rect(
        p.X + 610,
        p.Y + 288,
        390,
        52
    );
}

static Rect GetRememberLoginRect(int w, int h) {
    Rect p = GetLoginPanelRect(w, h);

    return Rect(
        p.X + 610,
        p.Y + 348,
        220,
        24
    );
}

static Rect GetLoginButtonRect(int w, int h) {
    Rect p = GetLoginPanelRect(w, h);

    return Rect(
        p.X + 610,
        p.Y + 382,
        390,
        52
    );
}

static Rect GetCreateAccountRect(int w, int h) {
    Rect p = GetLoginPanelRect(w, h);

    return Rect(
        p.X + 610,
        p.Y + 446,
        390,
        44
    );
}

static wstring PasswordBullets(size_t count) {
    return wstring(count, L'•');
}

void DrawSplashScreen(Graphics& g, int w, int h) {
    const double elapsed =
        (GetTickCount64() - g_startTick) /
        1000.0;

    DrawCoverImage(
        g,
        g_introBackground
            ? g_introBackground.get()
            : g_flexLogo.get(),
        Rect(0, 0, w, h),
        0
    );

    SolidBrush darkOverlay(
        Color(92, 0, 0, 0)
    );

    g.FillRectangle(
        &darkOverlay,
        0,
        0,
        w,
        h
    );

    LinearGradientBrush bottomShade(
        Point(w / 2, h / 2),
        Point(w / 2, h),
        Color(0, 0, 0, 0),
        Color(210, 0, 0, 0)
    );

    g.FillRectangle(
        &bottomShade,
        0,
        h / 2,
        w,
        h / 2
    );

    const double pulse =
        0.5 +
        0.5 * std::sin(elapsed * 3.0);

    Pen frame(
        Color(
            static_cast<BYTE>(
                70 + pulse * 80
            ),
            0,
            212,
            255
        ),
        2.0f
    );

    g.DrawRectangle(
        &frame,
        18,
        18,
        w - 36,
        h - 36
    );

    Font brand(
        L"Segoe UI",
        10,
        FontStyleBold,
        UnitPixel
    );

    Font loading(
        L"Segoe UI",
        9,
        FontStyleRegular,
        UnitPixel
    );

    SolidBrush white(
        Color(238, 255, 255, 255)
    );

    SolidBrush muted(
        Color(205, 180, 187, 202)
    );

    DrawCenteredText(
        g,
        L"PROJECT FLEX",
        &brand,
        &white,
        RectF(
            static_cast<REAL>(w / 2 - 160),
            static_cast<REAL>(h - 116),
            320,
            22
        )
    );

    DrawCenteredText(
        g,
        L"A preparar a tua sessão...",
        &loading,
        &muted,
        RectF(
            static_cast<REAL>(w / 2 - 180),
            static_cast<REAL>(h - 88),
            360,
            20
        )
    );

    Rect track(
        w / 2 - 170,
        h - 55,
        340,
        5
    );

    SolidBrush trackBg(
        Color(210, 28, 28, 34)
    );

    FillRoundedRect(
        g,
        &trackBg,
        track,
        3
    );

    const int progress =
        (std::min)(
            track.Width,
            static_cast<int>(
                (elapsed / 2.8) *
                static_cast<double>(
                    track.Width
                )
            )
        );

    if (progress > 0) {
        LinearGradientBrush progressBrush(
            Point(track.X, track.Y),
            Point(track.GetRight(), track.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(
            g,
            &progressBrush,
            Rect(
                track.X,
                track.Y,
                (std::max)(
                    3,
                    progress
                ),
                track.Height
            ),
            3
        );
    }
}

void DrawLoginScreen(Graphics& g, int w, int h) {
    Rect panel = GetLoginPanelRect(w, h);

    // Sombra/glow exterior.
    const double pulse =
        0.5 + 0.5 * std::sin(g_animSeconds * 2.0);

    Pen glow(
        Color(
            static_cast<BYTE>(24 + pulse * 34),
            0, 212, 255
        ),
        3.0f
    );

    DrawRoundedRect(
        g,
        &glow,
        Rect(
            panel.X - 3,
            panel.Y - 3,
            panel.Width + 6,
            panel.Height + 6
        ),
        26
    );

    SolidBrush panelBg(Color(248, 12, 13, 18));
    FillRoundedRect(g, &panelBg, panel, 24);

    Pen border(Color(45, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &border, panel, 24);

    // Lado visual.
    Rect art(
        panel.X,
        panel.Y,
        550,
        panel.Height
    );

    GraphicsPath artClip;
    BuildRoundedPath(artClip, art, 24);

    GraphicsState state = g.Save();
    g.SetClip(&artClip, CombineModeReplace);

    LinearGradientBrush artBg(
        Point(art.X, art.Y),
        Point(art.GetRight(), art.GetBottom()),
        Color(255, 8, 24, 42),
        Color(255, 45, 16, 66)
    );

    g.FillRectangle(
        &artBg,
        art.X,
        art.Y,
        art.Width,
        art.Height
    );

    SolidBrush haloBlue(Color(42, 0, 212, 255));
    SolidBrush haloPurple(Color(48, 168, 85, 247));

    g.FillEllipse(
        &haloBlue,
        art.X - 110,
        art.Y + 250,
        360,
        360
    );

    g.FillEllipse(
        &haloPurple,
        art.X + 250,
        art.Y - 90,
        360,
        360
    );

    // Linhas decorativas.
    Pen grid(Color(20, 255, 255, 255), 1.0f);

    for (int yy = art.Y + 40; yy < art.GetBottom(); yy += 38) {
        g.DrawLine(
            &grid,
            art.X + 20,
            yy,
            art.GetRight() - 20,
            yy
        );
    }

    for (int xx = art.X + 20; xx < art.GetRight(); xx += 38) {
        g.DrawLine(
            &grid,
            xx,
            art.Y + 20,
            xx,
            art.GetBottom() - 20
        );
    }

    g.Restore(state);

    DrawContainImage(
        g,
        g_flexLogo.get(),
        Rect(
            art.X + 55,
            art.Y + 80,
            440,
            165
        )
    );

    Font heroTitle(
        L"Segoe UI",
        24,
        FontStyleBold,
        UnitPixel
    );

    Font heroSub(
        L"Segoe UI",
        11,
        FontStyleRegular,
        UnitPixel
    );

    Font badgeFont(
        L"Segoe UI",
        9,
        FontStyleBold,
        UnitPixel
    );

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(Color(255, 162, 171, 190));
    SolidBrush cyan(ACCENT_BLUE);

    DrawTextStr(
        g,
        L"RELIVE THE OG EXPERIENCE",
        &heroTitle,
        &white,
        RectF(
            static_cast<REAL>(art.X + 54),
            static_cast<REAL>(art.Y + 292),
            430,
            42
        )
    );

    DrawTextStr(
        g,
        L"Fortnite 14.40 • Nexus War • Project Flex",
        &heroSub,
        &muted,
        RectF(
            static_cast<REAL>(art.X + 56),
            static_cast<REAL>(art.Y + 342),
            420,
            24
        )
    );

    Rect badge(
        art.X + 56,
        art.Y + 390,
        122,
        30
    );

    SolidBrush badgeBg(Color(170, 14, 38, 54));
    FillRoundedRect(g, &badgeBg, badge, 15);

    g.FillEllipse(&cyan, badge.X + 12, badge.Y + 11, 7, 7);

    DrawTextStr(
        g,
        L"SERVICES ONLINE",
        &badgeFont,
        &white,
        RectF(
            static_cast<REAL>(badge.X + 27),
            static_cast<REAL>(badge.Y + 8),
            90,
            17
        )
    );

    DrawTextStr(
        g,
        L"Fast. Clean. Private.",
        &heroSub,
        &muted,
        RectF(
            static_cast<REAL>(art.X + 56),
            static_cast<REAL>(art.Y + 450),
            300,
            22
        )
    );

    // Divisor.
    Pen divider(Color(40, 255, 255, 255), 1.0f);
    g.DrawLine(
        &divider,
        panel.X + 550,
        panel.Y + 24,
        panel.X + 550,
        panel.GetBottom() - 24
    );

    // Formulário.
    const int formX = panel.X + 610;

    Font kicker(
        L"Segoe UI",
        9,
        FontStyleBold,
        UnitPixel
    );

    Font title(
        L"Segoe UI",
        28,
        FontStyleBold,
        UnitPixel
    );

    Font body(
        L"Segoe UI",
        10,
        FontStyleRegular,
        UnitPixel
    );

    Font inputFont(
        L"Segoe UI",
        11,
        FontStyleRegular,
        UnitPixel
    );

    Font buttonFont(
        L"Segoe UI",
        10,
        FontStyleBold,
        UnitPixel
    );

    DrawTextStr(
        g,
        L"WELCOME BACK",
        &kicker,
        &cyan,
        RectF(
            static_cast<REAL>(formX),
            static_cast<REAL>(panel.Y + 84),
            220,
            20
        )
    );

    DrawTextStr(
        g,
        L"Iniciar sessão",
        &title,
        &white,
        RectF(
            static_cast<REAL>(formX),
            static_cast<REAL>(panel.Y + 112),
            330,
            42
        )
    );

    DrawTextStr(
        g,
        L"Usa a conta criada pelo bot no servidor Discord.",
        &body,
        &muted,
        RectF(
            static_cast<REAL>(formX),
            static_cast<REAL>(panel.Y + 160),
            380,
            24
        )
    );

    Rect emailRect = GetLoginUserRect(w, h);
    Rect passRect = GetLoginPasswordRect(w, h);

    SolidBrush inputBg(Color(255, 8, 9, 13));
    FillRoundedRect(g, &inputBg, emailRect, 12);
    FillRoundedRect(g, &inputBg, passRect, 12);

    Pen inputBorder(Color(52, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &inputBorder, emailRect, 12);
    DrawRoundedRect(g, &inputBorder, passRect, 12);

    if (g_activeTextInput == 10) {
        Pen active(ACCENT_BLUE, 1.8f);
        DrawRoundedRect(g, &active, emailRect, 12);
    }

    if (g_activeTextInput == 11) {
        Pen active(ACCENT_PURPLE, 1.8f);
        DrawRoundedRect(g, &active, passRect, 12);
    }

    const wstring emailText =
        g_loginEmail.empty()
        ? L"Email"
        : g_loginEmail;

    const wstring passText =
        g_loginPassword.empty()
        ? L"Palavra-passe"
        : PasswordBullets(g_loginPassword.size());

    DrawTextStr(
        g,
        emailText,
        &inputFont,
        g_loginEmail.empty()
            ? static_cast<Brush*>(&muted)
            : static_cast<Brush*>(&white),
        RectF(
            static_cast<REAL>(emailRect.X + 18),
            static_cast<REAL>(emailRect.Y + 16),
            static_cast<REAL>(emailRect.Width - 36),
            22
        )
    );

    DrawTextStr(
        g,
        passText,
        &inputFont,
        g_loginPassword.empty()
            ? static_cast<Brush*>(&muted)
            : static_cast<Brush*>(&white),
        RectF(
            static_cast<REAL>(passRect.X + 18),
            static_cast<REAL>(passRect.Y + 16),
            static_cast<REAL>(passRect.Width - 36),
            22
        )
    );

    Rect remember =
        GetRememberLoginRect(w, h);

    Rect checkBox(
        remember.X,
        remember.Y + 2,
        18,
        18
    );

    SolidBrush checkBg(
        g_rememberLogin
            ? Color(255, 0, 174, 214)
            : Color(255, 20, 22, 29)
    );

    FillRoundedRect(
        g,
        &checkBg,
        checkBox,
        5
    );

    Pen checkBorder(
        g_rememberLogin
            ? Color(180, 0, 212, 255)
            : Color(68, 255, 255, 255),
        1.0f
    );

    DrawRoundedRect(
        g,
        &checkBorder,
        checkBox,
        5
    );

    if (g_rememberLogin) {
        Pen check(
            Color(255, 255, 255, 255),
            2.0f
        );

        g.DrawLine(
            &check,
            checkBox.X + 4,
            checkBox.Y + 9,
            checkBox.X + 8,
            checkBox.Y + 13
        );

        g.DrawLine(
            &check,
            checkBox.X + 8,
            checkBox.Y + 13,
            checkBox.X + 14,
            checkBox.Y + 5
        );
    }

    DrawTextStr(
        g,
        L"Manter sessão iniciada",
        &body,
        &muted,
        RectF(
            static_cast<REAL>(
                remember.X + 28
            ),
            static_cast<REAL>(
                remember.Y + 3
            ),
            190,
            20
        )
    );

    Rect login = GetLoginButtonRect(w, h);

    if (g_authenticating) {
        SolidBrush disabled(Color(255, 64, 68, 78));
        FillRoundedRect(g, &disabled, login, 12);
    }
    else {
        LinearGradientBrush loginBg(
            Point(login.X, login.Y),
            Point(login.GetRight(), login.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(g, &loginBg, login, 12);
    }

    DrawCenteredText(
        g,
        g_authenticating
            ? L"A VALIDAR..."
            : L"ENTRAR NO PROJECT FLEX",
        &buttonFont,
        &white,
        RectF(
            static_cast<REAL>(login.X),
            static_cast<REAL>(login.Y),
            static_cast<REAL>(login.Width),
            static_cast<REAL>(login.Height)
        )
    );

    Rect create = GetCreateAccountRect(w, h);
    SolidBrush createBg(Color(255, 20, 22, 29));

    FillRoundedRect(g, &createBg, create, 12);

    Pen createBorder(
        Color(78, 168, 85, 247),
        1.0f
    );

    DrawRoundedRect(g, &createBorder, create, 12);

    DrawCenteredText(
        g,
        L"CRIAR CONTA NO DISCORD",
        &buttonFont,
        &white,
        RectF(
            static_cast<REAL>(create.X),
            static_cast<REAL>(create.Y),
            static_cast<REAL>(create.Width),
            static_cast<REAL>(create.Height)
        )
    );

    if (!g_loginStatus.empty()) {
        SolidBrush status(
            g_loginError
                ? Color(255, 244, 91, 105)
                : Color(255, 92, 220, 160)
        );

        DrawCenteredText(
            g,
            g_loginStatus,
            &body,
            &status,
            RectF(
                static_cast<REAL>(formX),
                static_cast<REAL>(panel.Y + 500),
                390,
                24
            )
        );
    }
}

static void StartLoginThread() {
    if (g_authenticating) return;

    if (g_loginEmail.empty() || g_loginPassword.empty()) {
        g_loginError = true;
        g_loginStatus = L"Preenche o email e a palavra-passe.";
        InvalidateRect(g_hwnd, nullptr, FALSE);
        return;
    }

    const wstring email = g_loginEmail;
    const wstring password = g_loginPassword;

    g_authenticating = true;
    g_loginError = false;
    g_loginStatus = L"A validar a conta...";
    InvalidateRect(g_hwnd, nullptr, FALSE);

    std::thread([email, password] {
        AuthResult result = AuthenticateLauncherAccount(email, password);

        const wstring text = result.success
            ? (result.displayName.empty() ? email : result.displayName)
            : (result.message.empty() ? L"Não foi possível iniciar sessão." : result.message);

        const size_t chars = text.size() + 1;
        auto* heapCopy = static_cast<wchar_t*>(
            HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, chars * sizeof(wchar_t))
        );

        if (heapCopy) {
            wcscpy_s(heapCopy, chars, text.c_str());
        }

        PostMessageW(
            g_hwnd,
            result.success ? WM_APP_LOGIN_DONE : WM_APP_LOGIN_FAIL,
            0,
            reinterpret_cast<LPARAM>(heapCopy)
        );
    }).detach();
}

// ------------------------------------------------------------
// Ecrã Home
// ------------------------------------------------------------

void DrawHomeScreen(Graphics& g, int w, int h) {
    const int left = 258;
    const int right = w - 34;
    const int contentW = right - left;

    Font kicker(L"Segoe UI", 9, FontStyleBold, UnitPixel);
    Font title(L"Segoe UI", 28, FontStyleBold, UnitPixel);
    Font heroTitle(L"Segoe UI", 30, FontStyleBold, UnitPixel);
    Font body(L"Segoe UI", 11, FontStyleRegular, UnitPixel);
    Font smallFont(L"Segoe UI", 9, FontStyleRegular, UnitPixel);
    Font strong(L"Segoe UI", 11, FontStyleBold, UnitPixel);
    Font badge(L"Segoe UI", 8, FontStyleBold, UnitPixel);

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(Color(255, 132, 140, 157));
    SolidBrush cyan(ACCENT_BLUE);
    SolidBrush purple(ACCENT_PURPLE);
    SolidBrush green(GREEN_ONLINE);

    DrawTextStr(
        g,
        L"DASHBOARD",
        &kicker,
        &cyan,
        RectF(
            static_cast<REAL>(left),
            78,
            160,
            18
        )
    );

    wstring welcome =
        g_loggedUser.empty()
        ? L"Bem-vindo ao Project Flex"
        : L"Bem-vindo, " + g_loggedUser;

    DrawTextStr(
        g,
        welcome,
        &title,
        &white,
        RectF(
            static_cast<REAL>(left),
            100,
            static_cast<REAL>(contentW - 250),
            42
        )
    );

    DrawTextStr(
        g,
        L"Tudo o que precisas para entrar no Nexus War.",
        &body,
        &muted,
        RectF(
            static_cast<REAL>(left),
            145,
            460,
            24
        )
    );

    // Status pill.
    Rect servicePill(right - 168, 92, 150, 36);
    SolidBrush pillBg(Color(255, 14, 24, 25));
    FillRoundedRect(g, &pillBg, servicePill, 18);

    Pen pillBorder(Color(70, 34, 197, 94), 1.0f);
    DrawRoundedRect(g, &pillBorder, servicePill, 18);

    g.FillEllipse(
        &green,
        servicePill.X + 14,
        servicePill.Y + 14,
        8,
        8
    );

    DrawTextStr(
        g,
        L"ALL SYSTEMS ONLINE",
        &badge,
        &green,
        RectF(
            static_cast<REAL>(servicePill.X + 31),
            static_cast<REAL>(servicePill.Y + 10),
            110,
            18
        )
    );

    // Hero.
    Rect hero(left, 190, contentW, 300);

    SolidBrush heroBase(Color(255, 15, 18, 25));
    FillRoundedRect(g, &heroBase, hero, 22);

    Pen heroBorder(Color(44, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &heroBorder, hero, 22);

    // Imagem na metade direita.
    Rect imageRect(
        hero.X + hero.Width / 2,
        hero.Y,
        hero.Width - hero.Width / 2,
        hero.Height
    );

    DrawCoverImage(
        g,
        g_nexusWar.get(),
        imageRect,
        22
    );

    // Overlay escuro da imagem para integrar com o painel.
    LinearGradientBrush overlay(
        Point(imageRect.X, imageRect.Y),
        Point(imageRect.GetRight(), imageRect.Y),
        Color(255, 15, 18, 25),
        Color(28, 15, 18, 25)
    );

    g.FillRectangle(
        &overlay,
        imageRect.X,
        imageRect.Y,
        imageRect.Width,
        imageRect.Height
    );

    // Accent glow.
    SolidBrush glow(Color(20, 0, 212, 255));
    g.FillEllipse(
        &glow,
        hero.X - 70,
        hero.Y + 30,
        300,
        300
    );

    Rect seasonBadge(
        hero.X + 28,
        hero.Y + 28,
        116,
        28
    );

    LinearGradientBrush seasonBg(
        Point(seasonBadge.X, seasonBadge.Y),
        Point(seasonBadge.GetRight(), seasonBadge.Y),
        ACCENT_BLUE,
        ACCENT_PURPLE
    );

    FillRoundedRect(
        g,
        &seasonBg,
        seasonBadge,
        14
    );

    DrawCenteredText(
        g,
        L"FEATURED BUILD",
        &badge,
        &white,
        RectF(
            static_cast<REAL>(seasonBadge.X),
            static_cast<REAL>(seasonBadge.Y),
            static_cast<REAL>(seasonBadge.Width),
            static_cast<REAL>(seasonBadge.Height)
        )
    );

    const bool hasBuild =
        !g_builds.empty() &&
        g_selectedBuild >= 0 &&
        g_selectedBuild <
            static_cast<int>(
                g_builds.size()
            );

    const wstring heroName =
        hasBuild
            ? g_builds[g_selectedBuild].name
            : L"Nenhuma build instalada";

    const wstring heroSubtitle =
        hasBuild
            ? g_builds[g_selectedBuild].subtitle
            : L"Importa uma build local ou descarrega-a do servidor.";

    DrawTextStr(
        g,
        heroName,
        &heroTitle,
        &white,
        RectF(
            static_cast<REAL>(hero.X + 28),
            static_cast<REAL>(hero.Y + 78),
            410,
            42
        )
    );

    DrawTextStr(
        g,
        heroSubtitle,
        &body,
        &muted,
        RectF(
            static_cast<REAL>(hero.X + 30),
            static_cast<REAL>(hero.Y + 124),
            410,
            42
        )
    );

    DrawTextStr(
        g,
        hasBuild
            ? L"Build pronta para ser lançada."
            : L"O launcher não inclui nenhuma build falsa ou pré-instalada.",
        &body,
        &muted,
        RectF(
            static_cast<REAL>(hero.X + 30),
            static_cast<REAL>(hero.Y + 175),
            410,
            40
        )
    );

    Rect launch = GetHomeLaunchRect(w, h);

    if (hasBuild) {
        LinearGradientBrush launchBg(
            Point(launch.X, launch.Y),
            Point(launch.GetRight(), launch.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(
            g,
            &launchBg,
            launch,
            12
        );

        DrawCenteredText(
            g,
            g_launching
                ? L"A LANÇAR..."
                : L"PLAY NOW",
            &strong,
            &white,
            RectF(
                static_cast<REAL>(launch.X),
                static_cast<REAL>(launch.Y),
                static_cast<REAL>(launch.Width),
                static_cast<REAL>(launch.Height)
            )
        );
    }
    else {
        SolidBrush importBg(
            Color(255, 30, 34, 44)
        );

        FillRoundedRect(
            g,
            &importBg,
            launch,
            12
        );

        DrawCenteredText(
            g,
            L"IMPORTAR BUILD",
            &strong,
            &white,
            RectF(
                static_cast<REAL>(launch.X),
                static_cast<REAL>(launch.Y),
                static_cast<REAL>(launch.Width),
                static_cast<REAL>(launch.Height)
            )
        );

        Rect download =
            GetHomeDownloadRect(w, h);

        LinearGradientBrush downloadBg(
            Point(download.X, download.Y),
            Point(download.GetRight(), download.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(
            g,
            &downloadBg,
            download,
            12
        );

        DrawCenteredText(
            g,
            g_downloadingBuild
                ? L"CANCELAR DOWNLOAD"
                : L"BAIXAR DO SERVIDOR",
            &strong,
            &white,
            RectF(
                static_cast<REAL>(download.X),
                static_cast<REAL>(download.Y),
                static_cast<REAL>(download.Width),
                static_cast<REAL>(download.Height)
            )
        );
    }

    if (g_downloadingBuild) {
        DrawDownloadProgress(
            g,
            Rect(
                282,
                484,
                650,
                46
            )
        );
    }
    else if (!g_launchStatus.empty() &&
             g_launchStatus != L"Pronto") {
        SolidBrush statusBrush(
            g_launchOk
                ? GREEN_ONLINE
                : Color(255, 235, 100, 110)
        );

        DrawTextStr(
            g,
            g_launchStatus,
            &smallFont,
            &statusBrush,
            RectF(
                282,
                494,
                650,
                18
            )
        );
    }

    // Cards inferiores.
    const int gap = 16;
    const int cardY = 544;
    const int cardH = 150;
    const int cardW = (contentW - gap * 2) / 3;

    for (int i = 0; i < 3; ++i) {
        Rect c(
            left + i * (cardW + gap),
            cardY,
            cardW,
            cardH
        );

        SolidBrush cBg(Color(238, 14, 16, 22));
        FillRoundedRect(g, &cBg, c, 18);

        Pen cBorder(Color(34, 255, 255, 255), 1.0f);
        DrawRoundedRect(g, &cBorder, c, 18);
    }

    // Card builds.
    DrawTextStr(
        g,
        L"LIBRARY",
        &kicker,
        &cyan,
        RectF(
            static_cast<REAL>(left + 20),
            static_cast<REAL>(cardY + 18),
            120,
            18
        )
    );

    DrawTextStr(
        g,
        std::to_wstring(g_builds.size()),
        &heroTitle,
        &white,
        RectF(
            static_cast<REAL>(left + 20),
            static_cast<REAL>(cardY + 47),
            80,
            44
        )
    );

    DrawTextStr(
        g,
        g_builds.size() == 1
            ? L"build instalada"
            : L"builds instaladas",
        &smallFont,
        &muted,
        RectF(
            static_cast<REAL>(left + 20),
            static_cast<REAL>(cardY + 104),
            160,
            18
        )
    );

    // Card account.
    const int card2X = left + cardW + gap;

    DrawTextStr(
        g,
        L"ACCOUNT",
        &kicker,
        &purple,
        RectF(
            static_cast<REAL>(card2X + 20),
            static_cast<REAL>(cardY + 18),
            120,
            18
        )
    );

    DrawTextStr(
        g,
        g_loggedUser.empty()
            ? L"Connected"
            : Ellipsize(g_loggedUser, 18),
        &strong,
        &white,
        RectF(
            static_cast<REAL>(card2X + 20),
            static_cast<REAL>(cardY + 53),
            static_cast<REAL>(cardW - 40),
            24
        )
    );

    DrawTextStr(
        g,
        L"Project Flex account",
        &smallFont,
        &muted,
        RectF(
            static_cast<REAL>(card2X + 20),
            static_cast<REAL>(cardY + 104),
            180,
            18
        )
    );

    // Card version/status.
    const int card3X = left + (cardW + gap) * 2;

    DrawTextStr(
        g,
        L"LAUNCHER",
        &kicker,
        &cyan,
        RectF(
            static_cast<REAL>(card3X + 20),
            static_cast<REAL>(cardY + 18),
            120,
            18
        )
    );

    DrawTextStr(
        g,
        L"v1.2",
        &heroTitle,
        &white,
        RectF(
            static_cast<REAL>(card3X + 20),
            static_cast<REAL>(cardY + 47),
            120,
            44
        )
    );

    DrawTextStr(
        g,
        L"Flex Nova UI",
        &smallFont,
        &muted,
        RectF(
            static_cast<REAL>(card3X + 20),
            static_cast<REAL>(cardY + 104),
            160,
            18
        )
    );
}

// ------------------------------------------------------------
// Ecrã Library
// ------------------------------------------------------------

static Rect GetLibraryLaunchRect() {
    return Rect(258, 676, 170, 38);
}

static Rect GetLibraryTrashRect(int w, int h) {
    return Rect(w - 114, h - 78, 46, 46);
}

static Rect GetLibraryImportRect(int w, int h) {
    return Rect(
        w - 58,
        h - 78,
        46,
        46
    );
}

static Rect GetLibraryDownloadRect(int w, int h) {
    return Rect(
        w - 306,
        h - 78,
        176,
        46
    );
}

static Rect GetBuildCardRect(int index) {
    const int col = index % 3;
    const int row = index / 3;
    return Rect(
        258 + col * 310,
        238 + row * 210,
        286,
        188
    );
}

void DrawLibraryScreen(Graphics& g, int w, int h) {
    Font kicker(L"Segoe UI", 9, FontStyleBold, UnitPixel);
    Font title(L"Segoe UI", 28, FontStyleBold, UnitPixel);
    Font cardTitle(L"Segoe UI", 13, FontStyleBold, UnitPixel);
    Font body(L"Segoe UI", 10, FontStyleRegular, UnitPixel);
    Font tiny(L"Segoe UI", 8, FontStyleRegular, UnitPixel);
    Font button(L"Segoe UI", 9, FontStyleBold, UnitPixel);

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(Color(255, 132, 140, 157));
    SolidBrush cyan(ACCENT_BLUE);

    DrawTextStr(
        g,
        L"LIBRARY",
        &kicker,
        &cyan,
        RectF(258, 78, 120, 18)
    );

    DrawTextStr(
        g,
        L"As tuas builds",
        &title,
        &white,
        RectF(258, 100, 360, 42)
    );

    DrawTextStr(
        g,
        L"Importa e gere versões locais do Fortnite.",
        &body,
        &muted,
        RectF(258, 148, 420, 22)
    );

    Rect countPill(w - 170, 98, 118, 34);
    SolidBrush pill(Color(255, 16, 19, 26));
    FillRoundedRect(g, &pill, countPill, 17);

    Pen pillBorder(Color(35, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &pillBorder, countPill, 17);

    DrawCenteredText(
        g,
        std::to_wstring(g_builds.size()) + L" BUILDS",
        &button,
        &muted,
        RectF(
            static_cast<REAL>(countPill.X),
            static_cast<REAL>(countPill.Y),
            static_cast<REAL>(countPill.Width),
            static_cast<REAL>(countPill.Height)
        )
    );

    if (g_builds.empty()) {
        Rect empty(258, 230, w - 310, 330);
        SolidBrush emptyBg(Color(220, 13, 15, 21));
        FillRoundedRect(g, &emptyBg, empty, 22);

        Pen emptyBorder(Color(36, 255, 255, 255), 1.0f);
        DrawRoundedRect(g, &emptyBorder, empty, 22);

        Font emptyTitle(L"Segoe UI", 17, FontStyleBold, UnitPixel);

        DrawCenteredText(
            g,
            L"A tua biblioteca está vazia",
            &emptyTitle,
            &white,
            RectF(
                static_cast<REAL>(empty.X),
                static_cast<REAL>(empty.Y + 112),
                static_cast<REAL>(empty.Width),
                30
            )
        );

        DrawCenteredText(
            g,
            L"Carrega no + para importar a primeira build.",
            &body,
            &muted,
            RectF(
                static_cast<REAL>(empty.X),
                static_cast<REAL>(empty.Y + 154),
                static_cast<REAL>(empty.Width),
                24
            )
        );
    }

    const int visibleBuilds =
        (std::min)(static_cast<int>(g_builds.size()), 6);

    for (int i = 0; i < visibleBuilds; ++i) {
        const BuildEntry& build = g_builds[i];
        Rect c = GetBuildCardRect(i);

        SolidBrush card(
            i == g_selectedBuild
                ? Color(255, 22, 27, 36)
                : Color(242, 13, 15, 21)
        );

        FillRoundedRect(g, &card, c, 18);

        Pen border(
            i == g_selectedBuild
                ? Color(160, 0, 212, 255)
                : Color(35, 255, 255, 255),
            i == g_selectedBuild
                ? 1.6f
                : 1.0f
        );

        DrawRoundedRect(g, &border, c, 18);

        Rect img(
            c.X,
            c.Y,
            112,
            c.Height
        );

        DrawCoverImage(
            g,
            g_nexusWar.get(),
            img,
            18
        );

        LinearGradientBrush imageShade(
            Point(img.X, img.Y),
            Point(img.GetRight(), img.Y),
            Color(20, 10, 12, 18),
            Color(220, 10, 12, 18)
        );

        g.FillRectangle(
            &imageShade,
            img.X,
            img.Y,
            img.Width,
            img.Height
        );

        Rect ready(
            c.X + 132,
            c.Y + 18,
            62,
            22
        );

        SolidBrush readyBg(Color(255, 16, 43, 32));
        FillRoundedRect(g, &readyBg, ready, 11);

        SolidBrush green(GREEN_ONLINE);
        DrawCenteredText(
            g,
            L"READY",
            &tiny,
            &green,
            RectF(
                static_cast<REAL>(ready.X),
                static_cast<REAL>(ready.Y),
                static_cast<REAL>(ready.Width),
                static_cast<REAL>(ready.Height)
            )
        );

        DrawTextStr(
            g,
            Ellipsize(build.name, 17),
            &cardTitle,
            &white,
            RectF(
                static_cast<REAL>(c.X + 132),
                static_cast<REAL>(c.Y + 56),
                135,
                24
            )
        );

        DrawTextStr(
            g,
            build.subtitle,
            &body,
            &muted,
            RectF(
                static_cast<REAL>(c.X + 132),
                static_cast<REAL>(c.Y + 86),
                135,
                20
            )
        );

        DrawTextStr(
            g,
            Ellipsize(build.path, 22),
            &tiny,
            &muted,
            RectF(
                static_cast<REAL>(c.X + 132),
                static_cast<REAL>(c.Y + 132),
                136,
                34
            )
        );
    }

    if (!g_builds.empty() &&
        g_selectedBuild >= 0 &&
        g_selectedBuild < static_cast<int>(g_builds.size())) {

        Rect launch = GetLibraryLaunchRect();

        LinearGradientBrush launchBg(
            Point(launch.X, launch.Y),
            Point(launch.GetRight(), launch.Y),
            ACCENT_BLUE,
            ACCENT_PURPLE
        );

        FillRoundedRect(g, &launchBg, launch, 11);

        DrawCenteredText(
            g,
            g_launching ? L"A LANÇAR..." : L"LANÇAR BUILD",
            &button,
            &white,
            RectF(
                static_cast<REAL>(launch.X),
                static_cast<REAL>(launch.Y),
                static_cast<REAL>(launch.Width),
                static_cast<REAL>(launch.Height)
            )
        );
    }

    if (g_downloadingBuild) {
        DrawDownloadProgress(
            g,
            Rect(
                450,
                654,
                520,
                46
            )
        );
    }
    else if (g_launching ||
             g_launchOk ||
             g_launchStatus != L"Pronto") {
        SolidBrush status(
            g_launchOk
                ? GREEN_ONLINE
                : (
                    g_launching
                    ? ACCENT_BLUE
                    : Color(255, 239, 91, 91)
                )
        );

        DrawTextStr(
            g,
            g_launchStatus,
            &tiny,
            &status,
            RectF(
                450,
                685,
                500,
                20
            )
        );
    }

    Rect download =
        GetLibraryDownloadRect(w, h);

    LinearGradientBrush downloadBg(
        Point(download.X, download.Y),
        Point(download.GetRight(), download.Y),
        ACCENT_BLUE,
        ACCENT_PURPLE
    );

    FillRoundedRect(
        g,
        &downloadBg,
        download,
        13
    );

    DrawCenteredText(
        g,
        g_downloadingBuild
            ? L"CANCELAR"
            : L"BAIXAR DO SERVIDOR",
        &button,
        &white,
        RectF(
            static_cast<REAL>(download.X),
            static_cast<REAL>(download.Y),
            static_cast<REAL>(download.Width),
            static_cast<REAL>(download.Height)
        )
    );

    Rect trash = GetLibraryTrashRect(w, h);
    Rect plus = GetLibraryImportRect(w, h);

    SolidBrush darkBtn(Color(255, 24, 27, 35));
    FillRoundedRect(g, &darkBtn, trash, 13);

    LinearGradientBrush plusBg(
        Point(plus.X, plus.Y),
        Point(plus.GetRight(), plus.Y),
        ACCENT_BLUE,
        ACCENT_PURPLE
    );

    FillRoundedRect(g, &plusBg, plus, 13);

    Pen trashPen(Color(255, 180, 186, 200), 1.8f);
    g.DrawRectangle(
        &trashPen,
        trash.X + 16,
        trash.Y + 18,
        14,
        16
    );
    g.DrawLine(
        &trashPen,
        trash.X + 14,
        trash.Y + 15,
        trash.X + 32,
        trash.Y + 15
    );

    Pen plusPen(Color(255, 255, 255, 255), 2.0f);
    g.DrawLine(
        &plusPen,
        plus.X + 13,
        plus.Y + 23,
        plus.X + 33,
        plus.Y + 23
    );
    g.DrawLine(
        &plusPen,
        plus.X + 23,
        plus.Y + 13,
        plus.X + 23,
        plus.Y + 33
    );
}

// ------------------------------------------------------------
// Ecrã Status
// ------------------------------------------------------------

static std::wstring FormatUptime(int seconds);

void DrawStatusScreen(Graphics& g, int w, int h) {
    (void)h;

    Font kicker(L"Segoe UI", 9, FontStyleBold, UnitPixel);
    Font title(L"Segoe UI", 28, FontStyleBold, UnitPixel);
    Font cardTitle(L"Segoe UI", 12, FontStyleBold, UnitPixel);
    Font body(L"Segoe UI", 10, FontStyleRegular, UnitPixel);
    Font big(L"Segoe UI", 22, FontStyleBold, UnitPixel);

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(Color(255, 132, 140, 157));
    SolidBrush cyan(ACCENT_BLUE);
    SolidBrush green(GREEN_ONLINE);
    SolidBrush red(Color(255, 239, 91, 91));

    ProjectFlexStatusResult status;
    bool loading = false;
    bool loaded = false;
    std::wstring errorText;

    {
        std::lock_guard<std::mutex> lock(
            g_apiDataMutex
        );

        status = g_serverStatus;
        loading = g_statusLoading;
        loaded = g_statusLoaded;
        errorText = g_statusError;
    }

    DrawTextStr(
        g,
        L"STATUS",
        &kicker,
        &cyan,
        RectF(258, 78, 120, 18)
    );

    DrawTextStr(
        g,
        L"Estado dos serviços",
        &title,
        &white,
        RectF(258, 100, 460, 42)
    );

    DrawTextStr(
        g,
        L"Dados em tempo real obtidos através da API Project Flex.",
        &body,
        &muted,
        RectF(258, 148, 580, 22)
    );

    for (int i = 0; i < 2; ++i) {
        Rect r = GetStatusFilterRect(i);

        SolidBrush bg(
            g_state.activeFilter == i
            ? Color(255, 27, 32, 42)
            : Color(255, 15, 17, 23)
        );

        FillRoundedRect(
            g,
            &bg,
            r,
            12
        );

        Pen border(
            g_state.activeFilter == i
            ? Color(130, 0, 212, 255)
            : Color(34, 255, 255, 255),
            1.0f
        );

        DrawRoundedRect(
            g,
            &border,
            r,
            12
        );

        DrawCenteredText(
            g,
            i == 0
                ? L"Todos"
                : L"Europa",
            &body,
            g_state.activeFilter == i
                ? static_cast<Brush*>(&white)
                : static_cast<Brush*>(&muted),
            RectF(
                static_cast<REAL>(r.X),
                static_cast<REAL>(r.Y),
                static_cast<REAL>(r.Width),
                static_cast<REAL>(r.Height)
            )
        );
    }

    const int left = 258;
    const int gap = 16;
    const int cardW =
        (w - left - 50 - gap * 2) / 3;
    const int y = 280;

    const wchar_t* names[] = {
        L"Backend",
        L"Authentication",
        L"Database"
    };

    const bool values[] = {
        status.backend,
        status.authentication,
        status.database
    };

    for (int i = 0; i < 3; ++i) {
        Rect c(
            left + i * (cardW + gap),
            y,
            cardW,
            160
        );

        SolidBrush card(
            Color(240, 14, 16, 22)
        );

        FillRoundedRect(
            g,
            &card,
            c,
            18
        );

        Pen border(
            Color(34, 255, 255, 255),
            1.0f
        );

        DrawRoundedRect(
            g,
            &border,
            c,
            18
        );

        const bool online =
            loaded &&
            status.success &&
            values[i];

        Brush* stateBrush =
            online
                ? static_cast<Brush*>(&green)
                : static_cast<Brush*>(&red);

        if (loading && !loaded)
            stateBrush =
                static_cast<Brush*>(&cyan);

        g.FillEllipse(
            stateBrush,
            c.X + 20,
            c.Y + 23,
            9,
            9
        );

        DrawTextStr(
            g,
            names[i],
            &cardTitle,
            &white,
            RectF(
                static_cast<REAL>(
                    c.X + 40
                ),
                static_cast<REAL>(
                    c.Y + 18
                ),
                static_cast<REAL>(
                    c.Width - 60
                ),
                24
            )
        );

        const std::wstring valueText =
            loading && !loaded
                ? L"CHECKING"
                : (
                    online
                        ? L"ONLINE"
                        : L"OFFLINE"
                );

        DrawTextStr(
            g,
            valueText,
            &big,
            stateBrush,
            RectF(
                static_cast<REAL>(
                    c.X + 20
                ),
                static_cast<REAL>(
                    c.Y + 70
                ),
                static_cast<REAL>(
                    c.Width - 40
                ),
                36
            )
        );

        DrawTextStr(
            g,
            loaded && status.success
                ? L"Resposta da API"
                : (
                    loading
                        ? L"A consultar..."
                        : L"Sem resposta"
                ),
            &body,
            &muted,
            RectF(
                static_cast<REAL>(
                    c.X + 20
                ),
                static_cast<REAL>(
                    c.Y + 122
                ),
                static_cast<REAL>(
                    c.Width - 40
                ),
                20
            )
        );
    }

    Rect info(
        left,
        468,
        w - left - 34,
        154
    );

    SolidBrush infoBg(
        Color(230, 12, 14, 20)
    );

    FillRoundedRect(
        g,
        &infoBg,
        info,
        18
    );

    Pen infoBorder(
        Color(34, 255, 255, 255),
        1.0f
    );

    DrawRoundedRect(
        g,
        &infoBorder,
        info,
        18
    );

    DrawTextStr(
        g,
        L"Project Flex network",
        &cardTitle,
        &white,
        RectF(
            static_cast<REAL>(
                info.X + 24
            ),
            static_cast<REAL>(
                info.Y + 24
            ),
            260,
            24
        )
    );

    std::wstring infoLine;

    if (loading && !loaded) {
        infoLine =
            L"A consultar o estado dos serviços...";
    }
    else if (!errorText.empty()) {
        infoLine =
            std::wstring(L"Falha na consulta: ") +
            errorText;
    }
    else if (loaded && status.success) {
        infoLine =
            std::wstring(L"Jogadores no ranking: ") +
            std::to_wstring(
                status.rankedPlayers
            ) +
            std::wstring(L"   •   Uptime: ") +
            FormatUptime(
                status.uptime
            );
    }
    else {
        infoLine =
            L"Abre novamente este separador para atualizar.";
    }

    DrawTextStr(
        g,
        infoLine,
        &body,
        errorText.empty()
            ? static_cast<Brush*>(&muted)
            : static_cast<Brush*>(&red),
        RectF(
            static_cast<REAL>(
                info.X + 24
            ),
            static_cast<REAL>(
                info.Y + 62
            ),
            static_cast<REAL>(
                info.Width - 48
            ),
            44
        )
    );

    DrawTextStr(
        g,
        loaded && status.success
            ? L"Última consulta: agora"
            : (
                loading
                    ? L"A atualizar..."
                    : L"Sem dados"
            ),
        &body,
        loaded && status.success
            ? static_cast<Brush*>(&green)
            : static_cast<Brush*>(&cyan),
        RectF(
            static_cast<REAL>(
                info.X + 24
            ),
            static_cast<REAL>(
                info.Y + 116
            ),
            200,
            20
        )
    );
}

// ------------------------------------------------------------
// Ecrã Ranks
// ------------------------------------------------------------

static void DrawBolt(Graphics& g, int cx, int cy) {
    Point pts[] = {
        Point(cx + 4, cy - 22),
        Point(cx - 10, cy + 1),
        Point(cx, cy + 1),
        Point(cx - 5, cy + 22),
        Point(cx + 14, cy - 5),
        Point(cx + 3, cy - 5)
    };

    GraphicsPath path;
    path.AddPolygon(pts, 6);

    Pen p(Color(255, 155, 155, 165), 2.0f);
    g.DrawPath(&p, &path);
}

void DrawRanksScreen(Graphics& g, int w, int h) {
    (void)h;

    Font kicker(
        L"Segoe UI",
        9,
        FontStyleBold,
        UnitPixel
    );

    Font title(
        L"Segoe UI",
        28,
        FontStyleBold,
        UnitPixel
    );

    Font body(
        L"Segoe UI",
        10,
        FontStyleRegular,
        UnitPixel
    );

    Font rankFont(
        L"Segoe UI",
        12,
        FontStyleBold,
        UnitPixel
    );

    Font rowFont(
        L"Segoe UI",
        11,
        FontStyleRegular,
        UnitPixel
    );

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(
        Color(255, 132, 140, 157)
    );
    SolidBrush cyan(ACCENT_BLUE);
    SolidBrush green(GREEN_ONLINE);
    SolidBrush red(
        Color(255, 239, 91, 91)
    );

    std::vector<ProjectFlexRankPlayer> players;
    bool loading = false;
    bool loaded = false;
    std::wstring errorText;

    {
        std::lock_guard<std::mutex> lock(
            g_apiDataMutex
        );

        players = g_rankPlayers;
        loading = g_ranksLoading;
        loaded = g_ranksLoaded;
        errorText = g_ranksError;
    }

    DrawTextStr(
        g,
        L"RANKS",
        &kicker,
        &cyan,
        RectF(258, 78, 120, 18)
    );

    DrawTextStr(
        g,
        L"Leaderboard",
        &title,
        &white,
        RectF(258, 100, 400, 42)
    );

    DrawTextStr(
        g,
        L"Ranking real do servidor, ordenado por Hype.",
        &body,
        &muted,
        RectF(258, 148, 500, 22)
    );

    Rect table(
        258,
        210,
        w - 292,
        430
    );

    SolidBrush tableBg(
        Color(238, 13, 15, 21)
    );

    FillRoundedRect(
        g,
        &tableBg,
        table,
        20
    );

    Pen border(
        Color(34, 255, 255, 255),
        1.0f
    );

    DrawRoundedRect(
        g,
        &border,
        table,
        20
    );

    Rect header(
        table.X + 14,
        table.Y + 14,
        table.Width - 28,
        48
    );

    SolidBrush headerBg(
        Color(255, 19, 22, 30)
    );

    FillRoundedRect(
        g,
        &headerBg,
        header,
        12
    );

    DrawTextStr(
        g,
        L"#",
        &rankFont,
        &muted,
        RectF(
            static_cast<REAL>(
                header.X + 18
            ),
            static_cast<REAL>(
                header.Y + 15
            ),
            40,
            20
        )
    );

    DrawTextStr(
        g,
        L"PLAYER",
        &rankFont,
        &muted,
        RectF(
            static_cast<REAL>(
                header.X + 72
            ),
            static_cast<REAL>(
                header.Y + 15
            ),
            260,
            20
        )
    );

    DrawTextStr(
        g,
        L"WINS",
        &rankFont,
        &muted,
        RectF(
            static_cast<REAL>(
                header.GetRight() - 310
            ),
            static_cast<REAL>(
                header.Y + 15
            ),
            70,
            20
        )
    );

    DrawTextStr(
        g,
        L"KILLS",
        &rankFont,
        &muted,
        RectF(
            static_cast<REAL>(
                header.GetRight() - 220
            ),
            static_cast<REAL>(
                header.Y + 15
            ),
            70,
            20
        )
    );

    DrawTextStr(
        g,
        L"HYPE",
        &rankFont,
        &muted,
        RectF(
            static_cast<REAL>(
                header.GetRight() - 115
            ),
            static_cast<REAL>(
                header.Y + 15
            ),
            90,
            20
        )
    );

    if (loading && !loaded) {
        DrawCenteredText(
            g,
            L"A carregar ranking...",
            &rankFont,
            &cyan,
            RectF(
                static_cast<REAL>(
                    table.X
                ),
                static_cast<REAL>(
                    table.Y + 190
                ),
                static_cast<REAL>(
                    table.Width
                ),
                30
            )
        );

        return;
    }

    if (!errorText.empty()) {
        DrawCenteredText(
            g,
            L"Não foi possível obter o ranking.",
            &rankFont,
            &red,
            RectF(
                static_cast<REAL>(
                    table.X
                ),
                static_cast<REAL>(
                    table.Y + 180
                ),
                static_cast<REAL>(
                    table.Width
                ),
                30
            )
        );

        DrawCenteredText(
            g,
            Ellipsize(
                errorText,
                72
            ),
            &body,
            &muted,
            RectF(
                static_cast<REAL>(
                    table.X + 30
                ),
                static_cast<REAL>(
                    table.Y + 222
                ),
                static_cast<REAL>(
                    table.Width - 60
                ),
                24
            )
        );

        return;
    }

    if (loaded &&
        players.empty())
    {
        DrawCenteredText(
            g,
            L"Ainda não existem jogadores no ranking.",
            &rankFont,
            &muted,
            RectF(
                static_cast<REAL>(
                    table.X
                ),
                static_cast<REAL>(
                    table.Y + 190
                ),
                static_cast<REAL>(
                    table.Width
                ),
                30
            )
        );

        DrawCenteredText(
            g,
            L"Assim que o servidor gravar Hype, wins e kills, aparecem aqui automaticamente.",
            &body,
            &muted,
            RectF(
                static_cast<REAL>(
                    table.X + 20
                ),
                static_cast<REAL>(
                    table.Y + 232
                ),
                static_cast<REAL>(
                    table.Width - 40
                ),
                24
            )
        );

        return;
    }

    const int rowHeight = 42;
    const int maxRows =
        (std::min)(
            static_cast<int>(
                players.size()
            ),
            8
        );

    for (int i = 0;
         i < maxRows;
         ++i)
    {
        const auto& player =
            players[
                static_cast<std::size_t>(i)
            ];

        const int rowY =
            header.GetBottom() +
            8 +
            i * rowHeight;

        if (i % 2 == 0) {
            SolidBrush rowBg(
                Color(
                    95,
                    255,
                    255,
                    255
                )
            );

            FillRoundedRect(
                g,
                &rowBg,
                Rect(
                    header.X,
                    rowY,
                    header.Width,
                    rowHeight - 3
                ),
                8
            );
        }

        Brush* rankBrush =
            player.rank <= 3
                ? static_cast<Brush*>(&cyan)
                : static_cast<Brush*>(&muted);

        DrawTextStr(
            g,
            std::to_wstring(
                player.rank
            ),
            &rankFont,
            rankBrush,
            RectF(
                static_cast<REAL>(
                    header.X + 18
                ),
                static_cast<REAL>(
                    rowY + 11
                ),
                40,
                20
            )
        );

        DrawTextStr(
            g,
            Ellipsize(
                player.username,
                26
            ),
            &rowFont,
            &white,
            RectF(
                static_cast<REAL>(
                    header.X + 72
                ),
                static_cast<REAL>(
                    rowY + 11
                ),
                260,
                20
            )
        );

        DrawTextStr(
            g,
            std::to_wstring(
                player.wins
            ),
            &rowFont,
            &muted,
            RectF(
                static_cast<REAL>(
                    header.GetRight() - 310
                ),
                static_cast<REAL>(
                    rowY + 11
                ),
                70,
                20
            )
        );

        DrawTextStr(
            g,
            std::to_wstring(
                player.kills
            ),
            &rowFont,
            &muted,
            RectF(
                static_cast<REAL>(
                    header.GetRight() - 220
                ),
                static_cast<REAL>(
                    rowY + 11
                ),
                70,
                20
            )
        );

        DrawTextStr(
            g,
            std::to_wstring(
                player.hype
            ),
            &rankFont,
            &green,
            RectF(
                static_cast<REAL>(
                    header.GetRight() - 115
                ),
                static_cast<REAL>(
                    rowY + 11
                ),
                90,
                20
            )
        );
    }
}

// ------------------------------------------------------------
// Ecrã Cups
// ------------------------------------------------------------

void DrawCupsScreen(Graphics& g, int w, int h) {
    (void)h;

    Font kicker(L"Segoe UI", 9, FontStyleBold, UnitPixel);
    Font title(L"Segoe UI", 28, FontStyleBold, UnitPixel);
    Font body(L"Segoe UI", 10, FontStyleRegular, UnitPixel);
    Font cardTitle(L"Segoe UI", 14, FontStyleBold, UnitPixel);
    Font smallFont(L"Segoe UI", 9, FontStyleRegular, UnitPixel);
    Font button(L"Segoe UI", 9, FontStyleBold, UnitPixel);

    SolidBrush white(TEXT_WHITE);
    SolidBrush muted(Color(255, 132, 140, 157));
    SolidBrush cyan(ACCENT_BLUE);

    DrawTextStr(g, L"CUPS", &kicker, &cyan, RectF(258, 78, 120, 18));
    DrawTextStr(g, L"Torneios", &title, &white, RectF(258, 100, 380, 42));
    DrawTextStr(g, L"Eventos competitivos do Project Flex.", &body, &muted, RectF(258, 148, 420, 22));

    for (int i = 0; i < 2; ++i) {
        Rect r = GetCupToggleRect(i, w);
        SolidBrush bg(
            g_state.activeCupView == i
                ? Color(255, 26, 31, 41)
                : Color(255, 14, 16, 22)
        );
        FillRoundedRect(g, &bg, r, 12);

        Pen border(
            g_state.activeCupView == i
                ? Color(130, 0, 212, 255)
                : Color(34, 255, 255, 255),
            1.0f
        );
        DrawRoundedRect(g, &border, r, 12);

        DrawCenteredText(
            g,
            i == 0 ? L"TORNEIOS" : L"LEADERBOARD",
            &button,
            g_state.activeCupView == i
                ? static_cast<Brush*>(&white)
                : static_cast<Brush*>(&muted),
            RectF(
                static_cast<REAL>(r.X),
                static_cast<REAL>(r.Y),
                static_cast<REAL>(r.Width),
                static_cast<REAL>(r.Height)
            )
        );
    }

    if (g_state.activeCupView == 1) {
        Rect empty(258, 220, w - 292, 380);
        SolidBrush bg(Color(238, 13, 15, 21));
        FillRoundedRect(g, &bg, empty, 20);

        Pen border(Color(34, 255, 255, 255), 1.0f);
        DrawRoundedRect(g, &border, empty, 20);

        DrawCenteredText(
            g,
            L"Ainda não existem resultados registados.",
            &cardTitle,
            &muted,
            RectF(
                static_cast<REAL>(empty.X),
                static_cast<REAL>(empty.Y + 160),
                static_cast<REAL>(empty.Width),
                30
            )
        );
        return;
    }

    const int gap = 18;
    const int left = 258;
    const int cardW = (w - left - 48 - gap) / 2;

    for (int i = 0; i < 2; ++i) {
        Rect c(
            left + i * (cardW + gap),
            220,
            cardW,
            340
        );

        SolidBrush bg(Color(240, 13, 15, 21));
        FillRoundedRect(g, &bg, c, 20);

        Pen border(Color(34, 255, 255, 255), 1.0f);
        DrawRoundedRect(g, &border, c, 20);

        Rect image(c.X, c.Y, c.Width, 205);

        if (i == 0) {
            DrawCoverImage(g, g_nexusWar.get(), image, 20);
        }
        else {
            LinearGradientBrush eventBg(
                Point(image.X, image.Y),
                Point(image.GetRight(), image.GetBottom()),
                Color(255, 12, 78, 112),
                Color(255, 92, 28, 135)
            );
            FillRoundedRect(g, &eventBg, image, 20);
        }

        Rect soon(c.X + 18, c.Y + 18, 102, 25);
        SolidBrush soonBg(Color(230, 8, 10, 14));
        FillRoundedRect(g, &soonBg, soon, 12);

        DrawCenteredText(
            g,
            L"BREVEMENTE",
            &button,
            &white,
            RectF(
                static_cast<REAL>(soon.X),
                static_cast<REAL>(soon.Y),
                static_cast<REAL>(soon.Width),
                static_cast<REAL>(soon.Height)
            )
        );

        DrawTextStr(
            g,
            i == 0 ? L"Nexus Cup" : L"Flex Release Cup",
            &cardTitle,
            &white,
            RectF(
                static_cast<REAL>(c.X + 20),
                static_cast<REAL>(c.Y + 226),
                static_cast<REAL>(c.Width - 40),
                26
            )
        );

        DrawTextStr(
            g,
            i == 0 ? L"30.09.26 • 18:00" : L"04.10.26 • 15:00",
            &smallFont,
            &muted,
            RectF(
                static_cast<REAL>(c.X + 20),
                static_cast<REAL>(c.Y + 260),
                static_cast<REAL>(c.Width - 40),
                20
            )
        );

        DrawTextStr(
            g,
            L"Project Flex competitive event",
            &smallFont,
            &muted,
            RectF(
                static_cast<REAL>(c.X + 20),
                static_cast<REAL>(c.Y + 298),
                static_cast<REAL>(c.Width - 40),
                20
            )
        );
    }
}

// ------------------------------------------------------------
// Settings
// ------------------------------------------------------------

static void DrawToggle(
    Graphics& g,
    Rect control,
    const wstring& title,
    const wstring& subtitle,
    bool enabled
) {
    SolidBrush card(CARD_COLOR);
    Pen border(Color(55, 255, 255, 255), 1.0f);
    SolidBrush white(TEXT_WHITE);
    SolidBrush gray(TEXT_GRAY);

    Font titleFont(L"Segoe UI", 13, FontStyleBold, UnitPixel);
    Font subFont(L"Segoe UI", 10, FontStyleRegular, UnitPixel);

    FillRoundedRect(g, &card, control, 14);
    DrawRoundedRect(g, &border, control, 14);

    DrawTextStr(g, title, &titleFont, &white, RectF(static_cast<REAL>(control.X + 20), static_cast<REAL>(control.Y + 18), static_cast<REAL>(control.Width - 110), 23));
    DrawTextStr(g, subtitle, &subFont, &gray, RectF(static_cast<REAL>(control.X + 20), static_cast<REAL>(control.Y + 43), static_cast<REAL>(control.Width - 120), 35));

    Rect sw(control.GetRight() - 68, control.Y + 22, 48, 26);
    SolidBrush track(enabled ? ACCENT_PURPLE : Color(255, 49, 49, 49));
    FillRoundedRect(g, &track, sw, 13);

    SolidBrush knob(Color(255, 245, 245, 245));
    const int knobX = enabled ? sw.X + 25 : sw.X + 3;
    g.FillEllipse(&knob, knobX, sw.Y + 3, 20, 20);
}

static Rect GetSettingsSectionRect(int index, int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 20, card.Y + 88 + index * 44, 150, 36);
}

static Rect GetLogoutRect(int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 205 + 328, card.Y + 101, 112, 42);
}

static Rect GetModalCloseRect(int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.GetRight() - 48, card.Y + 18, 30, 30);
}

static Rect GetAppearanceToggleRect(int index, int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 205, card.Y + 75 + index * 96, 460, 80);
}

static Rect GetGamePathRect(int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 205, card.Y + 112, 330, 42);
}

static Rect GetGameBrowseRect(int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 545, card.Y + 112, 120, 42);
}

static Rect GetGameSaveRect(int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 205, card.Y + 330, 170, 42);
}

static Rect GetGameExtraToggleRect(int index, int w, int h) {
    Rect card = GetSettingsCardRect(w, h);
    return Rect(card.X + 205, card.Y + 278 + index * 0, 0, 0);
}

static wstring Ellipsize(const wstring& s, size_t maxChars) {
    if (s.size() <= maxChars) return s;
    if (maxChars < 4) return s.substr(0, maxChars);
    return s.substr(0, maxChars - 3) + L"...";
}

void DrawSettingsModal(Graphics& g, int w, int h) {
    SolidBrush overlay(Color(217, 0, 0, 0));
    g.FillRectangle(&overlay, 0, 0, w, h);

    Rect card = GetSettingsCardRect(w, h);
    SolidBrush modal(Color(255, 18, 18, 18));
    FillRoundedRect(g, &modal, card, 16);

    Pen border(Color(70, 255, 255, 255), 1.0f);
    DrawRoundedRect(g, &border, card, 16);
    g.DrawLine(&border, card.X + 180, card.Y, card.X + 180, card.GetBottom());

    Font heading(L"Segoe UI", 22, FontStyleBold, UnitPixel);
    Font sectionFont(L"Segoe UI", 13, FontStyleBold, UnitPixel);
    Font normal(L"Segoe UI", 12, FontStyleRegular, UnitPixel);
    Font smallFont(L"Segoe UI", 10, FontStyleRegular, UnitPixel);
    Font tiny(L"Segoe UI", 9, FontStyleRegular, UnitPixel);

    SolidBrush white(TEXT_WHITE);
    SolidBrush gray(TEXT_GRAY);
    SolidBrush activeBg(CARD_HOVER);
    SolidBrush cardBrush(CARD_COLOR);
    SolidBrush button(Color(255, 245, 245, 245));
    SolidBrush dark(Color(255, 15, 15, 15));
    SolidBrush blue(ACCENT_BLUE);

    DrawTextStr(g, L"Settings", &heading, &white, RectF(static_cast<REAL>(card.X + 20), static_cast<REAL>(card.Y + 20), 150, 32));

    const wchar_t* sections[] = { L"Information", L"Appearance", L"Game" };
    for (int i = 0; i < 3; ++i) {
        Rect s = GetSettingsSectionRect(i, w, h);
        if (g_state.activeSettingSection == i) {
            FillRoundedRect(g, &activeBg, s, 10);
        }
        DrawTextStr(
            g,
            sections[i],
            &sectionFont,
            g_state.activeSettingSection == i ? static_cast<Brush*>(&white) : static_cast<Brush*>(&gray),
            RectF(static_cast<REAL>(s.X + 12), static_cast<REAL>(s.Y + 9), static_cast<REAL>(s.Width - 20), 22)
        );
    }

    Rect close = GetModalCloseRect(w, h);
    DrawCenteredText(g, L"×", &heading, &gray, RectF(static_cast<REAL>(close.X), static_cast<REAL>(close.Y), static_cast<REAL>(close.Width), static_cast<REAL>(close.Height)));

    const int contentX = card.X + 205;

    if (g_state.activeSettingSection == 0) {
        DrawTextStr(g, L"Information", &heading, &white, RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 22), 300, 34));

        Rect account(contentX, card.Y + 78, 460, 90);
        FillRoundedRect(g, &cardBrush, account, 14);
        DrawRoundedRect(g, &border, account, 14);

        SolidBrush avatarBg(Color(255, 40, 50, 56));
        g.FillEllipse(&avatarBg, account.X + 20, account.Y + 18, 54, 54);
        DrawCenteredText(g, L"F", &heading, &blue, RectF(static_cast<REAL>(account.X + 20), static_cast<REAL>(account.Y + 18), 54, 54));

        DrawTextStr(g, g_loggedUser.empty() ? L"Utilizador" : g_loggedUser, &sectionFont, &white, RectF(static_cast<REAL>(account.X + 90), static_cast<REAL>(account.Y + 23), 220, 22));
        DrawTextStr(g, L"Project Flex", &smallFont, &gray, RectF(static_cast<REAL>(account.X + 90), static_cast<REAL>(account.Y + 48), 180, 20));
        Rect logout = GetLogoutRect(w, h);
        SolidBrush logoutBg(Color(255, 29, 29, 29));
        FillRoundedRect(g, &logoutBg, logout, 10);
        DrawCenteredText(g, L"Terminar sessão", &smallFont, &gray,
            RectF(static_cast<REAL>(logout.X), static_cast<REAL>(logout.Y),
                  static_cast<REAL>(logout.Width), static_cast<REAL>(logout.Height)));

        Rect app(contentX, card.Y + 185, 460, 90);
        FillRoundedRect(g, &cardBrush, app, 14);
        DrawRoundedRect(g, &border, app, 14);

        SolidBrush iconBg(Color(255, 22, 26, 34));
        FillRoundedRect(g, &iconBg, Rect(app.X + 20, app.Y + 20, 50, 50), 12);

        Font flexFont(L"Segoe UI", 15, FontStyleBold, UnitPixel);
        DrawCenteredText(g, L"F", &flexFont, &blue, RectF(static_cast<REAL>(app.X + 20), static_cast<REAL>(app.Y + 20), 50, 50));
        DrawTextStr(g, L"Project Flex", &sectionFont, &white, RectF(static_cast<REAL>(app.X + 88), static_cast<REAL>(app.Y + 24), 220, 24));
        DrawTextStr(g, L"v1.0.0", &smallFont, &gray, RectF(static_cast<REAL>(app.X + 88), static_cast<REAL>(app.Y + 50), 120, 20));
    }
    else if (g_state.activeSettingSection == 1) {
        DrawTextStr(g, L"Appearance", &heading, &white, RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 22), 300, 34));

        DrawToggle(g, GetAppearanceToggleRect(0, w, h), L"Minimizar ao lançar", L"Minimiza o launcher quando o Fortnite arranca.", g_state.toggle1);
        DrawToggle(g, GetAppearanceToggleRect(1, w, h), L"Manter sempre visível", L"Mantém o launcher por cima das outras janelas.", g_state.toggle2);
        DrawToggle(g, GetAppearanceToggleRect(2, w, h), L"Reduzir movimento", L"Desativa transições e animações do launcher.", g_state.toggle3);
    }
    else {
        DrawTextStr(g, L"Game", &heading, &white, RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 22), 300, 34));

        DrawTextStr(g, L"Caminho do Fortnite", &sectionFont, &white, RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 78), 240, 24));

        Rect pathRect = GetGamePathRect(w, h);
        FillRoundedRect(g, &cardBrush, pathRect, 10);
        DrawRoundedRect(g, &border, pathRect, 10);
        if (g_activeTextInput == 1) {
            Pen activeBorder(ACCENT_BLUE, 1.5f);
            DrawRoundedRect(g, &activeBorder, pathRect, 10);
        }
        DrawTextStr(g, Ellipsize(g_fortnitePath, 39), &smallFont, &white, RectF(static_cast<REAL>(pathRect.X + 12), static_cast<REAL>(pathRect.Y + 12), static_cast<REAL>(pathRect.Width - 20), 20));

        Rect browse = GetGameBrowseRect(w, h);
        FillRoundedRect(g, &button, browse, 10);
        DrawCenteredText(g, L"Procurar", &sectionFont, &dark, RectF(static_cast<REAL>(browse.X), static_cast<REAL>(browse.Y), static_cast<REAL>(browse.Width), static_cast<REAL>(browse.Height)));

        DrawTextStr(g, L"Configuração", &sectionFont, &white,
            RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 180), 240, 24));

        DrawTextStr(g, L"As ligações do Project Flex são geridas automaticamente.",
            &smallFont, &gray,
            RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 215), 430, 22));

        DrawTextStr(g, L"O launcher não apresenta endereços nem detalhes internos.",
            &tiny, &gray,
            RectF(static_cast<REAL>(contentX), static_cast<REAL>(card.Y + 245), 430, 22));

        Rect save = GetGameSaveRect(w, h);
        FillRoundedRect(g, &button, save, 10);
        DrawCenteredText(g, L"Guardar", &sectionFont, &dark,
            RectF(static_cast<REAL>(save.X), static_cast<REAL>(save.Y),
                  static_cast<REAL>(save.Width), static_cast<REAL>(save.Height)));
    }
}

// ------------------------------------------------------------
// Escolha da pasta
// ------------------------------------------------------------

static bool ChooseFolder(HWND owner, wstring& outPath) {
    IFileDialog* dialog = nullptr;
    HRESULT hr = CoCreateInstance(
        CLSID_FileOpenDialog,
        nullptr,
        CLSCTX_INPROC_SERVER,
        IID_PPV_ARGS(&dialog)
    );

    if (FAILED(hr) || !dialog) {
        return false;
    }

    DWORD options = 0;
    dialog->GetOptions(&options);
    dialog->SetOptions(options | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
    dialog->SetTitle(L"Seleciona a pasta do Fortnite");

    hr = dialog->Show(owner);
    if (FAILED(hr)) {
        dialog->Release();
        return false;
    }

    IShellItem* item = nullptr;
    hr = dialog->GetResult(&item);
    if (FAILED(hr) || !item) {
        dialog->Release();
        return false;
    }

    PWSTR path = nullptr;
    hr = item->GetDisplayName(SIGDN_FILESYSPATH, &path);

    if (SUCCEEDED(hr) && path) {
        outPath = path;
        CoTaskMemFree(path);
    }

    item->Release();
    dialog->Release();
    return SUCCEEDED(hr);
}

// ------------------------------------------------------------
// Lançamento
// ------------------------------------------------------------

static void StartLaunchThread() {
    if (g_launching || g_builds.empty()) return;
    if (g_selectedBuild < 0 || g_selectedBuild >= static_cast<int>(g_builds.size())) return;

    g_launching = true;
    g_launchOk = false;
    g_launchStatus = L"A preparar a build...";
    InvalidateRect(g_hwnd, nullptr, FALSE);

    const std::filesystem::path fortnitePath = g_builds[g_selectedBuild].path;

    std::thread([fortnitePath] {
        LaunchResult result = LaunchFortnite(fortnitePath);

        if (result.success) {
            PostMessageW(g_hwnd, WM_APP_LAUNCH_DONE, 0, 0);
        } else {
            const std::wstring error = result.message.empty()
                ? L"Falha ao iniciar a build."
                : result.message;

            const size_t chars = error.size() + 1;
            auto* heapCopy = static_cast<wchar_t*>(
                HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, chars * sizeof(wchar_t))
            );

            if (heapCopy) {
                wcscpy_s(heapCopy, chars, error.c_str());
            }

            PostMessageW(
                g_hwnd,
                WM_APP_LAUNCH_FAIL,
                0,
                reinterpret_cast<LPARAM>(heapCopy)
            );
        }
    }).detach();
}

// ------------------------------------------------------------
// Hit-testing e edição simples dos campos
// ------------------------------------------------------------

static void HandleTextInput(wchar_t ch) {
    wstring* target = nullptr;

    if (g_activeTextInput == 1)  target = &g_fortnitePath;
    if (g_activeTextInput == 10) target = &g_loginEmail;
    if (g_activeTextInput == 11) target = &g_loginPassword;

    if (!target) return;

    if (ch == L'\b') {
        if (!target->empty()) {
            target->pop_back();
        }
    } else if (ch == L'\r' || ch == L'\n') {
        if (!g_authenticated) {
            StartLoginThread();
        } else {
            g_activeTextInput = 0;
        }
    } else if (ch == L'\t') {
        if (!g_authenticated) {
            g_activeTextInput = (g_activeTextInput == 10) ? 11 : 10;
        } else {
            g_activeTextInput = 0;
        }
    } else if (ch >= 32) {
        const size_t maxLen = (g_activeTextInput == 11) ? 128 : 1024;
        if (target->size() < maxLen) {
            target->push_back(ch);
        }
    }
}

static bool ImportBuildFromDialog(HWND hwnd) {
    wstring selected;

    if (!ChooseFolder(hwnd, selected))
        return false;

    BuildEntry build;
    wstring error;

    if (!CreateBuildEntryFromFolder(
            selected,
            build,
            error))
    {
        g_launchStatus = error;
        g_launchOk = false;
        return false;
    }

    const bool duplicate =
        std::any_of(
            g_builds.begin(),
            g_builds.end(),
            [&](const BuildEntry& existingBuild) {
                return _wcsicmp(
                    existingBuild.path.c_str(),
                    build.path.c_str()
                ) == 0;
            }
        );

    if (duplicate) {
        g_launchStatus =
            L"Essa build já está na biblioteca.";
        g_launchOk = false;
        return false;
    }

    g_builds.push_back(build);

    g_selectedBuild =
        static_cast<int>(
            g_builds.size()
        ) - 1;

    g_fortnitePath =
        build.path;

    SaveBuildLibrary(
        GetUserDataDirectory(),
        g_builds
    );

    SaveSettings();

    g_launchStatus =
        L"Build importada com sucesso.";

    g_launchOk = true;
    return true;
}

static void RequestBuildDownloadCancel() {
    if (!g_downloadingBuild)
        return;

    g_cancelBuildDownload.store(true);

    g_launchStatus =
        L"A cancelar... O progresso fica guardado para retomar.";

    InvalidateRect(
        g_hwnd,
        nullptr,
        FALSE
    );
}

static void StartServerBuildDownload() {
    if (g_downloadingBuild) {
        RequestBuildDownloadCancel();
        return;
    }

    ServerBuildInfo info;
    wstring error;

    if (!ReadServerBuildInfo(
            info,
            error))
    {
        g_launchStatus = error;
        g_launchOk = false;

        MessageBoxW(
            g_hwnd,
            error.c_str(),
            L"Project Flex",
            MB_OK | MB_ICONINFORMATION
        );

        InvalidateRect(
            g_hwnd,
            nullptr,
            FALSE
        );

        return;
    }

    g_cancelBuildDownload.store(false);
    g_downloadingBuild = true;
    g_launchOk = false;

    {
        std::lock_guard<std::mutex> lock(
            g_downloadProgressMutex
        );

        g_downloadProgress =
            BuildDownloadProgress{};
    }

    g_launchStatus =
        L"A preparar a pasta da build...";

    InvalidateRect(
        g_hwnd,
        nullptr,
        FALSE
    );

    const auto userData =
        GetUserDataDirectory();

    std::thread(
        [info, userData] {
            std::filesystem::path folder;
            wstring error;

            const auto onProgress =
                [](const BuildDownloadProgress& progress) {
                    {
                        std::lock_guard<std::mutex> lock(
                            g_downloadProgressMutex
                        );

                        g_downloadProgress =
                            progress;
                    }

                    InvalidateRect(
                        g_hwnd,
                        nullptr,
                        FALSE
                    );
                };

            const bool ok =
                DownloadServerBuildFolder(
                    info,
                    userData,
                    g_cancelBuildDownload,
                    onProgress,
                    folder,
                    error
                );

            const wstring text =
                ok
                    ? folder.wstring()
                    : error;

            const size_t chars =
                text.size() + 1;

            auto* heapCopy =
                static_cast<wchar_t*>(
                    HeapAlloc(
                        GetProcessHeap(),
                        HEAP_ZERO_MEMORY,
                        chars *
                        sizeof(wchar_t)
                    )
                );

            if (heapCopy) {
                wcscpy_s(
                    heapCopy,
                    chars,
                    text.c_str()
                );
            }

            PostMessageW(
                g_hwnd,
                ok
                    ? WM_APP_BUILD_DOWNLOAD_DONE
                    : WM_APP_BUILD_DOWNLOAD_FAIL,
                0,
                reinterpret_cast<LPARAM>(
                    heapCopy
                )
            );
        }
    ).detach();
}

// ------------------------------------------------------------
// Project Flex API
// ------------------------------------------------------------

static void RefreshRanksAsync() {
    {
        std::lock_guard<std::mutex> lock(
            g_apiDataMutex
        );

        if (g_ranksLoading)
            return;

        g_ranksLoading = true;
        g_ranksError.clear();
    }

    InvalidateRect(
        g_hwnd,
        nullptr,
        FALSE
    );

    std::thread([] {
        auto* result =
            new ProjectFlexRanksResult(
                FetchProjectFlexRanks()
            );

        PostMessageW(
            g_hwnd,
            WM_APP_RANKS_DONE,
            0,
            reinterpret_cast<LPARAM>(
                result
            )
        );
    }).detach();
}

static void RefreshStatusAsync() {
    {
        std::lock_guard<std::mutex> lock(
            g_apiDataMutex
        );

        if (g_statusLoading)
            return;

        g_statusLoading = true;
        g_statusError.clear();
    }

    InvalidateRect(
        g_hwnd,
        nullptr,
        FALSE
    );

    std::thread([] {
        auto* result =
            new ProjectFlexStatusResult(
                FetchProjectFlexStatus()
            );

        PostMessageW(
            g_hwnd,
            WM_APP_STATUS_DONE,
            0,
            reinterpret_cast<LPARAM>(
                result
            )
        );
    }).detach();
}

static std::wstring FormatUptime(
    int seconds
) {
    if (seconds < 0)
        seconds = 0;

    const int days =
        seconds / 86400;

    seconds %= 86400;

    const int hours =
        seconds / 3600;

    seconds %= 3600;

    const int minutes =
        seconds / 60;

    if (days > 0) {
        return
            std::to_wstring(days) +
            L"d " +
            std::to_wstring(hours) +
            L"h";
    }

    if (hours > 0) {
        return
            std::to_wstring(hours) +
            L"h " +
            std::to_wstring(minutes) +
            L"m";
    }

    return
        std::to_wstring(minutes) +
        L"m";
}

// ------------------------------------------------------------
// WndProc
// ------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE:
    {
        GdiplusStartupInput input;
        if (GdiplusStartup(&g_gdiplusToken, &input, nullptr) != Ok) {
            MessageBoxW(hwnd, L"Não foi possível iniciar o GDI+.", L"Project Flex", MB_ICONERROR);
            return -1;
        }

        g_flexLogo = LoadImageWithFallback(
            L"",
            L"assets\\flex_logo.png"
        );

        g_nexusWar = LoadImageWithFallback(
            L"",
            L"assets\\nexus_war_bg.png"
        );

        g_introBackground = LoadImageWithFallback(
            L"",
            L"assets\\flex_intro_bg.png"
        );

        LoadSettings();

        g_builds = LoadBuildLibrary(
            GetUserDataDirectory()
        );

        g_selectedBuild =
            g_builds.empty()
                ? -1
                : 0;

        g_autoLoginPending =
            LoadLauncherCredentials(
                g_loginEmail,
                g_loginPassword
            );

        g_rememberLogin = true;
        g_startTick = GetTickCount64();
        SetTimer(hwnd, TIMER_ANIMATION, 16, nullptr);
        ApplyAlwaysOnTop();
        return 0;
    }

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT:
    {
        PAINTSTRUCT ps{};
        HDC hdc = BeginPaint(hwnd, &ps);

        RECT rc{};
        GetClientRect(hwnd, &rc);
        const int w = rc.right - rc.left;
        const int h = rc.bottom - rc.top;

        HDC memDC = CreateCompatibleDC(hdc);
        HBITMAP memBmp = CreateCompatibleBitmap(
            hdc,
            (std::max)(1, w),
            (std::max)(1, h)
        );
        HGDIOBJ oldBmp = SelectObject(memDC, memBmp);

        {
            Graphics g(memDC);
            g.SetSmoothingMode(SmoothingModeAntiAlias);
            g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
            g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
            g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);

            DrawStarField(g, w, h);

            if (g_showSplash) {
                DrawSplashScreen(g, w, h);
            }
            else {
                if (!g_authenticated) {
                    DrawLoginScreen(g, w, h);
                }
                else {
                    DrawTopBar(g, w);
                    DrawTabs(g, w);

                    const int screen =
                        g_state.settingsOpen
                        ? g_settingsUnderlayTab
                        : g_state.activeTab;

                    switch (screen) {
                    case 0:
                        DrawHomeScreen(g, w, h);
                        break;

                    case 1:
                        DrawLibraryScreen(g, w, h);
                        break;

                    case 2:
                        DrawStatusScreen(g, w, h);
                        break;

                    case 3:
                        DrawRanksScreen(g, w, h);
                        break;

                    case 4:
                        DrawCupsScreen(g, w, h);
                        break;

                    default:
                        DrawHomeScreen(g, w, h);
                        break;
                    }

                    if (g_state.settingsOpen) {
                        DrawSettingsModal(g, w, h);
                    }

                    if (!g_state.toggle3 && g_pageFade < 1.0f) {
                        const BYTE fadeAlpha =
                            static_cast<BYTE>((1.0f - g_pageFade) * 110.0f);

                        SolidBrush fade(Color(fadeAlpha, 0, 0, 0));
                        g.FillRectangle(&fade, 238, 44, w - 238, h - 44);
                    }
                }
            }
        }

        BitBlt(
            hdc,
            0,
            0,
            w,
            h,
            memDC,
            0,
            0,
            SRCCOPY
        );

        SelectObject(memDC, oldBmp);
        DeleteObject(memBmp);
        DeleteDC(memDC);

        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_MOUSEMOVE:
    {
        RECT rc{};
        GetClientRect(hwnd, &rc);
        const int w = rc.right - rc.left;

        const int x = GET_X_LPARAM(lParam);
        const int y = GET_Y_LPARAM(lParam);

        int newHover = -1;
        if (g_authenticated && !g_showSplash && !g_state.settingsOpen) {
            for (int i = 0; i < 6; ++i) {
                if (PtInRectI(GetTabRect(i, w), x, y)) {
                    newHover = i;
                    break;
                }
            }
        }

        if (newHover != g_state.hoverTab) {
            g_state.hoverTab = newHover;
            InvalidateRect(hwnd, nullptr, FALSE);
        }

        TRACKMOUSEEVENT tme{};
        tme.cbSize = sizeof(tme);
        tme.dwFlags = TME_LEAVE;
        tme.hwndTrack = hwnd;
        TrackMouseEvent(&tme);
        return 0;
    }

    case WM_MOUSELEAVE:
        if (g_state.hoverTab != -1) {
            g_state.hoverTab = -1;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;

    case WM_LBUTTONDOWN:
    {
        RECT rc{};
        GetClientRect(hwnd, &rc);

        const int w = rc.right - rc.left;
        const int h = rc.bottom - rc.top;

        const int x = GET_X_LPARAM(lParam);
        const int y = GET_Y_LPARAM(lParam);

        // ----------------------------------------------------
        // Botões da barra superior
        // ----------------------------------------------------
        if (y >= 0 && y < 40) {
            if (x >= w - 32) {
                PostMessageW(hwnd, WM_CLOSE, 0, 0);
                return 0;
            }

            if (x >= w - 64) {
                if (IsZoomed(hwnd)) {
                    ShowWindow(hwnd, SW_RESTORE);
                }
                else {
                    ShowWindow(hwnd, SW_MAXIMIZE);
                }
                return 0;
            }

            if (x >= w - 96) {
                ShowWindow(hwnd, SW_MINIMIZE);
                return 0;
            }
        }

        // Durante o splash não há interações.
        if (g_showSplash) {
            return 0;
        }

        // ----------------------------------------------------
        // LOGIN
        // ----------------------------------------------------
        if (!g_authenticated) {
            if (PtInRectI(GetLoginUserRect(w, h), x, y)) {
                g_activeTextInput = 10;
                SetFocus(hwnd);
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            if (PtInRectI(GetLoginPasswordRect(w, h), x, y)) {
                g_activeTextInput = 11;
                SetFocus(hwnd);
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            if (PtInRectI(GetRememberLoginRect(w, h), x, y)) {
                g_rememberLogin =
                    !g_rememberLogin;

                if (!g_rememberLogin) {
                    ClearLauncherCredentials();
                }

                InvalidateRect(
                    hwnd,
                    nullptr,
                    FALSE
                );

                return 0;
            }

            if (PtInRectI(GetLoginButtonRect(w, h), x, y)) {
                StartLoginThread();
                return 0;
            }

            if (PtInRectI(GetCreateAccountRect(w, h), x, y)) {
                if (!OpenAccountCreationPage(hwnd)) {
                    MessageBoxW(
                        hwnd,
                        L"Não foi possível abrir o Discord no navegador. "
                        L"Verifica a associação HTTPS do Windows.",
                        L"Project Flex",
                        MB_OK | MB_ICONINFORMATION
                    );
                }

                return 0;
            }

            return 0;
        }

        // ----------------------------------------------------
        // MODAL SETTINGS
        // ----------------------------------------------------
        if (g_state.settingsOpen) {
            if (PtInRectI(GetModalCloseRect(w, h), x, y)) {
                g_state.settingsOpen = false;
                g_state.activeTab = g_settingsUnderlayTab;
                g_activeTextInput = 0;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            for (int i = 0; i < 3; ++i) {
                if (PtInRectI(GetSettingsSectionRect(i, w, h), x, y)) {
                    g_state.activeSettingSection = i;
                    g_activeTextInput = 0;

                    InvalidateRect(hwnd, nullptr, FALSE);
                    return 0;
                }
            }

            // Logout.
            if (
                g_state.activeSettingSection == 0 &&
                PtInRectI(GetLogoutRect(w, h), x, y)
            ) {
                g_authenticated = false;
                g_authenticating = false;

                ClearLauncherCredentials();

                g_loggedUser.clear();
                g_loginEmail.clear();
                g_loginPassword.clear();
                g_loginStatus.clear();
                g_loginError = false;

                g_state.settingsOpen = false;
                g_state.activeTab = 0;

                g_activeTextInput = 10;
                g_pageFade = 1.0f;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            // Appearance.
            if (g_state.activeSettingSection == 1) {
                for (int i = 0; i < 3; ++i) {
                    if (PtInRectI(GetAppearanceToggleRect(i, w, h), x, y)) {
                        if (i == 0) {
                            g_state.toggle1 = !g_state.toggle1;
                        }

                        if (i == 1) {
                            g_state.toggle2 = !g_state.toggle2;
                            ApplyAlwaysOnTop();
                        }

                        if (i == 2) {
                            g_state.toggle3 = !g_state.toggle3;
                        }

                        SaveSettings();

                        InvalidateRect(hwnd, nullptr, FALSE);
                        return 0;
                    }
                }
            }

            // Game.
            if (g_state.activeSettingSection == 2) {
                if (PtInRectI(GetGamePathRect(w, h), x, y)) {
                    g_activeTextInput = 1;
                    SetFocus(hwnd);

                    InvalidateRect(hwnd, nullptr, FALSE);
                    return 0;
                }

                if (PtInRectI(GetGameBrowseRect(w, h), x, y)) {
                    wstring selected;

                    if (ChooseFolder(hwnd, selected)) {
                        g_fortnitePath = selected;
                        SaveSettings();
                    }

                    g_activeTextInput = 0;

                    InvalidateRect(hwnd, nullptr, FALSE);
                    return 0;
                }

                if (PtInRectI(GetGameSaveRect(w, h), x, y)) {
                    SaveSettings();
                    g_activeTextInput = 0;

                    MessageBoxW(
                        hwnd,
                        L"Definições guardadas.",
                        L"Project Flex",
                        MB_OK | MB_ICONINFORMATION
                    );

                    InvalidateRect(hwnd, nullptr, FALSE);
                    return 0;
                }
            }

            return 0;
        }

        // ----------------------------------------------------
        // TABS
        // ----------------------------------------------------
        for (int i = 0; i < 6; ++i) {
            if (PtInRectI(GetTabRect(i, w), x, y)) {
                if (i == 5) {
                    g_settingsUnderlayTab =
                        (g_state.activeTab >= 0 && g_state.activeTab <= 4)
                        ? g_state.activeTab
                        : 0;

                    g_state.activeTab = 5;
                    g_state.settingsOpen = true;
                    g_state.activeSettingSection = 0;
                }
                else {
                    g_state.activeTab = i;
                    g_state.settingsOpen = false;
                    g_pageFade = g_state.toggle3 ? 1.0f : 0.0f;

                    if (i == 2) {
                        RefreshStatusAsync();
                    }

                    if (i == 3) {
                        RefreshRanksAsync();
                    }
                }

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
        }

        // ----------------------------------------------------
        // HOME QUICK PLAY
        // ----------------------------------------------------
        if (g_state.activeTab == 0) {
            if (PtInRectI(GetHomeLaunchRect(w, h), x, y)) {
                if (!g_builds.empty()) {
                    StartLaunchThread();
                }
                else {
                    ImportBuildFromDialog(hwnd);

                    InvalidateRect(
                        hwnd,
                        nullptr,
                        FALSE
                    );
                }

                return 0;
            }

            if (
                g_builds.empty() &&
                PtInRectI(
                    GetHomeDownloadRect(w, h),
                    x,
                    y
                )
            ) {
                if (g_downloadingBuild) {
                    RequestBuildDownloadCancel();
                }
                else {
                    StartServerBuildDownload();
                }

                return 0;
            }
        }

        // ----------------------------------------------------
        // CUPS
        // ----------------------------------------------------
        if (g_state.activeTab == 4) {
            if (PtInRectI(GetCupToggleRect(0, w), x, y)) {
                g_state.activeCupView = 0;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            if (PtInRectI(GetCupToggleRect(1, w), x, y)) {
                g_state.activeCupView = 1;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
        }

        // ----------------------------------------------------
        // STATUS
        // ----------------------------------------------------
        if (g_state.activeTab == 2) {
            if (PtInRectI(GetStatusFilterRect(0), x, y)) {
                g_state.activeFilter = 0;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            if (PtInRectI(GetStatusFilterRect(1), x, y)) {
                g_state.activeFilter = 1;

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
        }

        // ----------------------------------------------------
        // LIBRARY
        // ----------------------------------------------------
        if (g_state.activeTab == 1) {
            // Selecionar card.
            const int visibleBuilds =
                (std::min)(static_cast<int>(g_builds.size()), 8);

            for (int i = 0; i < visibleBuilds; ++i) {
                if (PtInRectI(GetBuildCardRect(i), x, y)) {
                    g_selectedBuild = i;
                    g_fortnitePath = g_builds[i].path;

                    SaveSettings();

                    InvalidateRect(hwnd, nullptr, FALSE);
                    return 0;
                }
            }

            // Baixar build do servidor configurado.
            if (PtInRectI(GetLibraryDownloadRect(w, h), x, y)) {
                if (g_downloadingBuild) {
                    RequestBuildDownloadCancel();
                }
                else {
                    StartServerBuildDownload();
                }

                return 0;
            }

            // Importar build local.
            if (PtInRectI(GetLibraryImportRect(w, h), x, y)) {
                ImportBuildFromDialog(hwnd);

                InvalidateRect(
                    hwnd,
                    nullptr,
                    FALSE
                );

                return 0;
            }

            // Remover build da biblioteca.
            if (
                PtInRectI(GetLibraryTrashRect(w, h), x, y) &&
                !g_builds.empty() &&
                g_selectedBuild >= 0 &&
                g_selectedBuild < static_cast<int>(g_builds.size())
            ) {
                const int answer = MessageBoxW(
                    hwnd,
                    L"Remover a build selecionada da biblioteca? "
                    L"Os ficheiros do jogo não serão apagados.",
                    L"Project Flex",
                    MB_YESNO | MB_ICONQUESTION
                );

                if (answer == IDYES) {
                    g_builds.erase(
                        g_builds.begin() + g_selectedBuild
                    );

                    if (g_builds.empty()) {
                        g_selectedBuild = -1;
                        g_fortnitePath.clear();
                    }
                    else {
                        g_selectedBuild = (std::min)(
                            g_selectedBuild,
                            static_cast<int>(g_builds.size()) - 1
                        );

                        g_fortnitePath =
                            g_builds[g_selectedBuild].path;
                    }

                    SaveBuildLibrary(
                        GetUserDataDirectory(),
                        g_builds
                    );

                    SaveSettings();

                    g_launchStatus =
                        L"Build removida da biblioteca.";

                    g_launchOk = true;
                }

                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }

            // Lançar build.
            if (PtInRectI(GetLibraryLaunchRect(), x, y)) {
                if (g_state.toggle1) {
                    ShowWindow(hwnd, SW_MINIMIZE);
                }

                StartLaunchThread();
                return 0;
            }
        }

        return 0;
    }

    // WM_SYSCHAR cobre AltGr em layouts como PT-PT (ex.: AltGr+2 = @).
    case WM_CHAR:
    case WM_SYSCHAR:
        if ((!g_authenticated && !g_showSplash && (g_activeTextInput == 10 || g_activeTextInput == 11)) ||
            (g_authenticated && g_state.settingsOpen && g_state.activeSettingSection == 2 && g_activeTextInput == 1)) {
            HandleTextInput(static_cast<wchar_t>(wParam));
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        break;

    case WM_KEYDOWN:
        if ((GetKeyState(VK_CONTROL) & 0x8000) &&
            (wParam == 'V') &&
            !g_authenticated &&
            !g_showSplash &&
            (g_activeTextInput == 10 || g_activeTextInput == 11)) {

            if (OpenClipboard(hwnd)) {
                HANDLE data = GetClipboardData(CF_UNICODETEXT);

                if (data) {
                    const wchar_t* clip =
                        static_cast<const wchar_t*>(
                            GlobalLock(data)
                        );

                    if (clip) {
                        wstring* target =
                            (g_activeTextInput == 10)
                            ? &g_loginEmail
                            : &g_loginPassword;

                        const size_t maxLen =
                            (g_activeTextInput == 11)
                            ? 128
                            : 1024;

                        while (*clip &&
                               target->size() < maxLen) {
                            if (*clip >= 32 &&
                                *clip != L'\r' &&
                                *clip != L'\n') {
                                target->push_back(*clip);
                            }
                            ++clip;
                        }

                        GlobalUnlock(data);
                    }
                }

                CloseClipboard();
            }

            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }

        if (wParam == VK_ESCAPE && g_state.settingsOpen) {
            g_state.settingsOpen = false;
            g_state.activeTab = g_settingsUnderlayTab;
            g_activeTextInput = 0;
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        break;

    case WM_TIMER:
        if (wParam == TIMER_ANIMATION) {
            const ULONGLONG now = GetTickCount64();
            g_animSeconds = static_cast<double>(now - g_startTick) / 1000.0;

            if (g_showSplash && now - g_startTick >= 2800) {
                g_showSplash = false;

                if (g_autoLoginPending) {
                    g_autoLoginPending = false;
                    StartLoginThread();
                }
                else {
                    g_activeTextInput = 10;
                }
            }

            if (!g_state.toggle3 && g_pageFade < 1.0f) {
                g_pageFade = (std::min)(1.0f, g_pageFade + 0.08f);
            }

            if (!g_state.toggle3 || g_showSplash) {
                InvalidateRect(hwnd, nullptr, FALSE);
            }
        }
        return 0;

    case WM_APP_LOGIN_DONE:
    {
        g_authenticating = false;
        g_authenticated = true;
        g_loginError = false;

        auto* userText = reinterpret_cast<wchar_t*>(lParam);
        if (userText) {
            g_loggedUser = userText;
            HeapFree(GetProcessHeap(), 0, userText);
        } else {
            g_loggedUser = g_loginEmail;
        }

        if (g_rememberLogin) {
            SaveLauncherCredentials(
                g_loginEmail,
                g_loginPassword
            );
        }
        else {
            ClearLauncherCredentials();
        }

        g_loginPassword.clear();
        g_loginStatus.clear();
        g_activeTextInput = 0;
        g_pageFade = g_state.toggle3 ? 1.0f : 0.0f;

        RefreshStatusAsync();
        RefreshRanksAsync();

        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_APP_LOGIN_FAIL:
    {
        g_authenticating = false;
        g_authenticated = false;
        g_loginError = true;

        auto* msgText = reinterpret_cast<wchar_t*>(lParam);
        if (msgText) {
            g_loginStatus = msgText;
            HeapFree(GetProcessHeap(), 0, msgText);
        } else {
            g_loginStatus = L"Não foi possível iniciar sessão.";
        }

        ClearLauncherCredentials();
        g_rememberLogin = false;

        g_loginPassword.clear();
        g_activeTextInput = 11;
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_APP_RANKS_DONE:
    {
        auto* result =
            reinterpret_cast<ProjectFlexRanksResult*>(
                lParam
            );

        {
            std::lock_guard<std::mutex> lock(
                g_apiDataMutex
            );

            g_ranksLoading = false;

            if (result &&
                result->success)
            {
                g_rankPlayers =
                    result->players;

                g_ranksLoaded = true;
                g_ranksError.clear();
            }
            else
            {
                g_ranksLoaded = false;

                g_ranksError =
                    result
                        ? result->message
                        : L"Resposta inválida.";
            }
        }

        delete result;

        InvalidateRect(
            hwnd,
            nullptr,
            FALSE
        );

        return 0;
    }

    case WM_APP_STATUS_DONE:
    {
        auto* result =
            reinterpret_cast<ProjectFlexStatusResult*>(
                lParam
            );

        {
            std::lock_guard<std::mutex> lock(
                g_apiDataMutex
            );

            g_statusLoading = false;

            if (result &&
                result->success)
            {
                g_serverStatus =
                    *result;

                g_statusLoaded = true;
                g_statusError.clear();
            }
            else
            {
                g_statusLoaded = false;

                g_statusError =
                    result
                        ? result->message
                        : L"Resposta inválida.";
            }
        }

        delete result;

        InvalidateRect(
            hwnd,
            nullptr,
            FALSE
        );

        return 0;
    }

    case WM_APP_BUILD_DOWNLOAD_DONE:
    {
        g_downloadingBuild = false;

        auto* pathText =
            reinterpret_cast<wchar_t*>(
                lParam
            );

        if (!pathText) {
            g_launchStatus =
                L"O download terminou sem uma pasta válida.";

            g_launchOk = false;

            InvalidateRect(
                hwnd,
                nullptr,
                FALSE
            );

            return 0;
        }

        const wstring folder =
            pathText;

        HeapFree(
            GetProcessHeap(),
            0,
            pathText
        );

        BuildEntry build;
        wstring error;

        if (!CreateBuildEntryFromFolder(
                folder,
                build,
                error))
        {
            g_launchStatus =
                error.empty()
                    ? L"A build descarregada não é válida."
                    : error;

            g_launchOk = false;

            InvalidateRect(
                hwnd,
                nullptr,
                FALSE
            );

            return 0;
        }

        const auto existing =
            std::find_if(
                g_builds.begin(),
                g_builds.end(),
                [&](const BuildEntry& existingBuild) {
                    return _wcsicmp(
                        existingBuild.path.c_str(),
                        build.path.c_str()
                    ) == 0;
                }
            );

        if (existing ==
            g_builds.end())
        {
            g_builds.push_back(build);

            g_selectedBuild =
                static_cast<int>(
                    g_builds.size()
                ) - 1;
        }
        else {
            g_selectedBuild =
                static_cast<int>(
                    std::distance(
                        g_builds.begin(),
                        existing
                    )
                );
        }

        if (g_selectedBuild >= 0 &&
            g_selectedBuild <
                static_cast<int>(
                    g_builds.size()
                ))
        {
            g_fortnitePath =
                g_builds[
                    g_selectedBuild
                ].path;
        }

        SaveBuildLibrary(
            GetUserDataDirectory(),
            g_builds
        );

        SaveSettings();

        g_launchStatus =
            L"Pasta da build descarregada e adicionada à biblioteca.";

        g_launchOk = true;

        InvalidateRect(
            hwnd,
            nullptr,
            FALSE
        );

        return 0;
    }

    case WM_APP_BUILD_DOWNLOAD_FAIL:
    {
        g_downloadingBuild = false;
        g_launchOk = false;

        auto* msgText =
            reinterpret_cast<wchar_t*>(
                lParam
            );

        if (msgText) {
            g_launchStatus =
                msgText;

            HeapFree(
                GetProcessHeap(),
                0,
                msgText
            );
        }
        else {
            g_launchStatus =
                L"Não foi possível descarregar a build.";
        }

        InvalidateRect(
            hwnd,
            nullptr,
            FALSE
        );

        return 0;
    }

    case WM_APP_LAUNCH_DONE:
        g_launching = false;
        g_launchOk = true;
        g_launchStatus = L"Fortnite iniciado.";
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;

    case WM_APP_LAUNCH_FAIL:
    {
        g_launching = false;
        g_launchOk = false;

        auto* msgText = reinterpret_cast<wchar_t*>(lParam);
        if (msgText) {
            g_launchStatus = msgText;
            HeapFree(GetProcessHeap(), 0, msgText);
        } else {
            g_launchStatus = L"Falha ao iniciar o Fortnite.";
        }

        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_SIZE:
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;

    case WM_DESTROY:
        KillTimer(hwnd, TIMER_ANIMATION);
        SaveSettings();
        g_flexLogo.reset();
        g_nexusWar.reset();

        if (g_gdiplusToken) {
            GdiplusShutdown(g_gdiplusToken);
            g_gdiplusToken = 0;
        }

        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ------------------------------------------------------------
// WinMain
// ------------------------------------------------------------

int APIENTRY wWinMain(
    HINSTANCE hInstance,
    HINSTANCE,
    LPWSTR,
    int nCmdShow
) {
    g_hInstance = hInstance;

    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    const wchar_t CLASS_NAME[] = L"ProjectFlexLauncherWindow";

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APP_ICON));
    if (!wc.hIcon) wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hIconSm = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APP_ICON));
    if (!wc.hIconSm) wc.hIconSm = wc.hIcon;
    wc.lpszClassName = CLASS_NAME;

    if (!RegisterClassExW(&wc)) {
        MessageBoxW(nullptr, L"Não foi possível registar a classe da janela.", L"Project Flex", MB_ICONERROR);
        CoUninitialize();
        return 1;
    }

    RECT desired{ 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT };
    AdjustWindowRectEx(&desired, WS_OVERLAPPEDWINDOW, FALSE, 0);

    const int windowW = desired.right - desired.left;
    const int windowH = desired.bottom - desired.top;

    const int screenW = GetSystemMetrics(SM_CXSCREEN);
    const int screenH = GetSystemMetrics(SM_CYSCREEN);

    const int x = std::max(0, (screenW - windowW) / 2);
    const int y = std::max(0, (screenH - windowH) / 2);

    g_hwnd = CreateWindowExW(
        0,
        CLASS_NAME,
        L"Project Flex",
        WS_OVERLAPPEDWINDOW,
        x,
        y,
        windowW,
        windowH,
        nullptr,
        nullptr,
        hInstance,
        nullptr
    );

    if (!g_hwnd) {
        MessageBoxW(nullptr, L"Não foi possível criar a janela principal.", L"Project Flex", MB_ICONERROR);
        CoUninitialize();
        return 1;
    }

    ShowWindow(g_hwnd, nCmdShow);
    UpdateWindow(g_hwnd);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return static_cast<int>(msg.wParam);
}
