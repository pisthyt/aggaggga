﻿#pragma once

#include <windows.h>
#include <string>

struct AuthResult
{
    bool success = false;
    std::wstring displayName;
    std::wstring message;
    std::wstring token;
};

AuthResult AuthenticateLauncherAccount(
    const std::wstring& email,
    const std::wstring& password
);

// Abre o servidor Discord configurado para criação da conta.
bool OpenAccountCreationPage(HWND owner);


bool SaveLauncherCredentials(
    const std::wstring& email,
    const std::wstring& password
);

bool LoadLauncherCredentials(
    std::wstring& email,
    std::wstring& password
);

void ClearLauncherCredentials();
