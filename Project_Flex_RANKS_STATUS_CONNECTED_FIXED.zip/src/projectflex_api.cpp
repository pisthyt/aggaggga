﻿#include "projectflex_api.h"

#include <windows.h>
#include <winhttp.h>

#include <filesystem>
#include <string>
#include <vector>
#include <cctype>

#pragma comment(lib, "winhttp.lib")

namespace
{

std::filesystem::path GetExeDirectory()
{
    wchar_t buffer[MAX_PATH]{};

    const DWORD length =
        GetModuleFileNameW(
            nullptr,
            buffer,
            MAX_PATH
        );

    if (length == 0)
        return std::filesystem::current_path();

    return std::filesystem::path(
        buffer
    ).parent_path();
}

std::filesystem::path GetConfigPath()
{
    return GetExeDirectory() /
           L"server_config.ini";
}

std::wstring ReadConfig(
    const wchar_t* key,
    const wchar_t* fallback
)
{
    wchar_t value[4096]{};

    GetPrivateProfileStringW(
        L"Services",
        key,
        fallback,
        value,
        static_cast<DWORD>(
            std::size(value)
        ),
        GetConfigPath().c_str()
    );

    return value;
}

std::wstring GetRanksUrl()
{
    return ReadConfig(
        L"RanksUrl",
        L"https://54-36-99-5.sslip.io/projectflex/api/ranks"
    );
}

std::wstring GetStatusUrl()
{
    return ReadConfig(
        L"StatusUrl",
        L"https://54-36-99-5.sslip.io/projectflex/api/status"
    );
}

std::wstring Utf8ToWide(
    const std::string& value
)
{
    if (value.empty())
        return {};

    const int size =
        MultiByteToWideChar(
            CP_UTF8,
            0,
            value.c_str(),
            static_cast<int>(value.size()),
            nullptr,
            0
        );

    if (size <= 0)
        return {};

    std::wstring result(
        static_cast<std::size_t>(size),
        L'\0'
    );

    MultiByteToWideChar(
        CP_UTF8,
        0,
        value.c_str(),
        static_cast<int>(value.size()),
        result.data(),
        size
    );

    return result;
}

bool HttpGet(
    const std::wstring& url,
    std::string& response,
    DWORD& statusCode,
    std::wstring& error
)
{
    response.clear();
    statusCode = 0;

    URL_COMPONENTS parts{};
    parts.dwStructSize =
        sizeof(parts);

    wchar_t host[512]{};
    wchar_t path[8192]{};

    parts.lpszHostName = host;
    parts.dwHostNameLength =
        static_cast<DWORD>(
            std::size(host)
        );

    parts.lpszUrlPath = path;
    parts.dwUrlPathLength =
        static_cast<DWORD>(
            std::size(path)
        );

    if (!WinHttpCrackUrl(
            url.c_str(),
            0,
            0,
            &parts))
    {
        error =
            L"URL da API inválido.";
        return false;
    }

    const std::wstring hostName(
        host,
        parts.dwHostNameLength
    );

    std::wstring requestPath(
        path,
        parts.dwUrlPathLength
    );

    if (requestPath.empty())
        requestPath = L"/";

    HINTERNET session =
        WinHttpOpen(
            L"ProjectFlexLauncher/1.0",
            WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
            WINHTTP_NO_PROXY_NAME,
            WINHTTP_NO_PROXY_BYPASS,
            0
        );

    if (!session)
    {
        error =
            L"Não foi possível iniciar a ligação.";
        return false;
    }

    WinHttpSetTimeouts(
        session,
        10000,
        10000,
        15000,
        15000
    );

    HINTERNET connection =
        WinHttpConnect(
            session,
            hostName.c_str(),
            parts.nPort,
            0
        );

    if (!connection)
    {
        WinHttpCloseHandle(session);

        error =
            L"Não foi possível contactar o servidor.";
        return false;
    }

    const DWORD flags =
        parts.nScheme ==
        INTERNET_SCHEME_HTTPS
        ? WINHTTP_FLAG_SECURE
        : 0;

    HINTERNET request =
        WinHttpOpenRequest(
            connection,
            L"GET",
            requestPath.c_str(),
            nullptr,
            WINHTTP_NO_REFERER,
            WINHTTP_DEFAULT_ACCEPT_TYPES,
            flags
        );

    if (!request)
    {
        WinHttpCloseHandle(connection);
        WinHttpCloseHandle(session);

        error =
            L"Não foi possível preparar o pedido.";
        return false;
    }

    BOOL ok =
        WinHttpSendRequest(
            request,
            WINHTTP_NO_ADDITIONAL_HEADERS,
            0,
            WINHTTP_NO_REQUEST_DATA,
            0,
            0,
            0
        );

    if (ok)
    {
        ok =
            WinHttpReceiveResponse(
                request,
                nullptr
            );
    }

    if (!ok)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);
        WinHttpCloseHandle(session);

        error =
            L"Falha ao comunicar com a API.";
        return false;
    }

    DWORD statusSize =
        sizeof(statusCode);

    WinHttpQueryHeaders(
        request,
        WINHTTP_QUERY_STATUS_CODE |
        WINHTTP_QUERY_FLAG_NUMBER,
        WINHTTP_HEADER_NAME_BY_INDEX,
        &statusCode,
        &statusSize,
        WINHTTP_NO_HEADER_INDEX
    );

    for (;;)
    {
        DWORD available = 0;

        if (!WinHttpQueryDataAvailable(
                request,
                &available))
        {
            WinHttpCloseHandle(request);
            WinHttpCloseHandle(connection);
            WinHttpCloseHandle(session);

            error =
                L"Falha ao ler a resposta da API.";
            return false;
        }

        if (available == 0)
            break;

        std::vector<char> buffer(
            static_cast<std::size_t>(available)
        );

        DWORD read = 0;

        if (!WinHttpReadData(
                request,
                buffer.data(),
                available,
                &read))
        {
            WinHttpCloseHandle(request);
            WinHttpCloseHandle(connection);
            WinHttpCloseHandle(session);

            error =
                L"Falha ao ler a resposta da API.";
            return false;
        }

        if (read == 0)
            break;

        response.append(
            buffer.data(),
            static_cast<std::size_t>(read)
        );
    }

    WinHttpCloseHandle(request);
    WinHttpCloseHandle(connection);
    WinHttpCloseHandle(session);

    if (statusCode < 200 ||
        statusCode >= 300)
    {
        error =
            L"A API respondeu com HTTP " +
            std::to_wstring(statusCode) +
            L".";

        return false;
    }

    return true;
}

std::string FindJsonString(
    const std::string& json,
    const std::string& key
)
{
    const std::string needle =
        "\"" + key + "\"";

    std::size_t p =
        json.find(needle);

    if (p == std::string::npos)
        return {};

    p =
        json.find(
            ':',
            p + needle.size()
        );

    if (p == std::string::npos)
        return {};

    p =
        json.find(
            '"',
            p + 1
        );

    if (p == std::string::npos)
        return {};

    ++p;

    std::string result;
    bool escaped = false;

    for (;
         p < json.size();
         ++p)
    {
        const char ch = json[p];

        if (escaped)
        {
            switch (ch)
            {
            case '"':
                result += '"';
                break;

            case '\\':
                result += '\\';
                break;

            case '/':
                result += '/';
                break;

            case 'n':
                result += '\n';
                break;

            case 'r':
                result += '\r';
                break;

            case 't':
                result += '\t';
                break;

            default:
                result += ch;
                break;
            }

            escaped = false;
            continue;
        }

        if (ch == '\\')
        {
            escaped = true;
            continue;
        }

        if (ch == '"')
            break;

        result += ch;
    }

    return result;
}

long long FindJsonInteger(
    const std::string& json,
    const std::string& key,
    long long fallback = 0
)
{
    const std::string needle =
        "\"" + key + "\"";

    std::size_t p =
        json.find(needle);

    if (p == std::string::npos)
        return fallback;

    p =
        json.find(
            ':',
            p + needle.size()
        );

    if (p == std::string::npos)
        return fallback;

    ++p;

    while (
        p < json.size() &&
        std::isspace(
            static_cast<unsigned char>(
                json[p]
            )
        )
    )
    {
        ++p;
    }

    bool negative = false;

    if (p < json.size() &&
        json[p] == '-')
    {
        negative = true;
        ++p;
    }

    long long value = 0;
    bool found = false;

    while (
        p < json.size() &&
        std::isdigit(
            static_cast<unsigned char>(
                json[p]
            )
        )
    )
    {
        found = true;

        value =
            value * 10 +
            static_cast<long long>(
                json[p] - '0'
            );

        ++p;
    }

    if (!found)
        return fallback;

    return negative
        ? -value
        : value;
}

bool FindJsonBool(
    const std::string& json,
    const std::string& key,
    bool fallback = false
)
{
    const std::string needle =
        "\"" + key + "\"";

    std::size_t p =
        json.find(needle);

    if (p == std::string::npos)
        return fallback;

    p =
        json.find(
            ':',
            p + needle.size()
        );

    if (p == std::string::npos)
        return fallback;

    ++p;

    while (
        p < json.size() &&
        std::isspace(
            static_cast<unsigned char>(
                json[p]
            )
        )
    )
    {
        ++p;
    }

    if (json.compare(
            p,
            4,
            "true") == 0)
    {
        return true;
    }

    if (json.compare(
            p,
            5,
            "false") == 0)
    {
        return false;
    }

    return fallback;
}

std::vector<std::string>
ExtractArrayObjects(
    const std::string& json,
    const std::string& key
)
{
    std::vector<std::string> objects;

    const std::string needle =
        "\"" + key + "\"";

    std::size_t p =
        json.find(needle);

    if (p == std::string::npos)
        return objects;

    p =
        json.find(
            '[',
            p + needle.size()
        );

    if (p == std::string::npos)
        return objects;

    ++p;

    bool inString = false;
    bool escaped = false;
    int depth = 0;
    std::size_t objectStart =
        std::string::npos;

    for (;
         p < json.size();
         ++p)
    {
        const char ch = json[p];

        if (inString)
        {
            if (escaped)
            {
                escaped = false;
                continue;
            }

            if (ch == '\\')
            {
                escaped = true;
                continue;
            }

            if (ch == '"')
                inString = false;

            continue;
        }

        if (ch == '"')
        {
            inString = true;
            continue;
        }

        if (ch == ']'
            && depth == 0)
        {
            break;
        }

        if (ch == '{')
        {
            if (depth == 0)
                objectStart = p;

            ++depth;
            continue;
        }

        if (ch == '}')
        {
            if (depth <= 0)
                continue;

            --depth;

            if (depth == 0 &&
                objectStart !=
                    std::string::npos)
            {
                objects.push_back(
                    json.substr(
                        objectStart,
                        p - objectStart + 1
                    )
                );

                objectStart =
                    std::string::npos;
            }
        }
    }

    return objects;
}

} // namespace

ProjectFlexRanksResult
FetchProjectFlexRanks()
{
    ProjectFlexRanksResult result;

    std::string json;
    DWORD status = 0;
    std::wstring error;

    if (!HttpGet(
            GetRanksUrl(),
            json,
            status,
            error))
    {
        result.message = error;
        return result;
    }

    if (!FindJsonBool(
            json,
            "success",
            false))
    {
        result.message =
            L"O servidor não devolveu um ranking válido.";

        return result;
    }

    const auto objects =
        ExtractArrayObjects(
            json,
            "players"
        );

    result.players.reserve(
        objects.size()
    );

    for (const auto& object : objects)
    {
        ProjectFlexRankPlayer player;

        player.rank =
            static_cast<int>(
                FindJsonInteger(
                    object,
                    "rank",
                    0
                )
            );

        player.username =
            Utf8ToWide(
                FindJsonString(
                    object,
                    "username"
                )
            );

        player.hype =
            static_cast<int>(
                FindJsonInteger(
                    object,
                    "hype",
                    0
                )
            );

        player.wins =
            static_cast<int>(
                FindJsonInteger(
                    object,
                    "wins",
                    0
                )
            );

        player.kills =
            static_cast<int>(
                FindJsonInteger(
                    object,
                    "kills",
                    0
                )
            );

        player.matches =
            static_cast<int>(
                FindJsonInteger(
                    object,
                    "matches",
                    0
                )
            );

        if (player.rank <= 0)
        {
            player.rank =
                static_cast<int>(
                    result.players.size()
                ) + 1;
        }

        if (player.username.empty())
            player.username = L"Unknown";

        result.players.push_back(
            std::move(player)
        );
    }

    result.success = true;
    return result;
}

ProjectFlexStatusResult
FetchProjectFlexStatus()
{
    ProjectFlexStatusResult result;

    std::string json;
    DWORD status = 0;
    std::wstring error;

    if (!HttpGet(
            GetStatusUrl(),
            json,
            status,
            error))
    {
        result.message = error;
        return result;
    }

    if (!FindJsonBool(
            json,
            "success",
            false))
    {
        result.message =
            L"O servidor não devolveu um estado válido.";

        return result;
    }

    result.backend =
        FindJsonBool(
            json,
            "backend",
            false
        );

    result.authentication =
        FindJsonBool(
            json,
            "authentication",
            false
        );

    result.database =
        FindJsonBool(
            json,
            "database",
            false
        );

    result.rankedPlayers =
        static_cast<int>(
            FindJsonInteger(
                json,
                "rankedPlayers",
                0
            )
        );

    result.uptime =
        static_cast<int>(
            FindJsonInteger(
                json,
                "uptime",
                0
            )
        );

    result.success = true;
    return result;
}
