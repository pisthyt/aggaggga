﻿#include "download_manager.h"

#include <windows.h>
#include <winhttp.h>

#include <algorithm>
#include <chrono>
#include <filesystem>
#include <iterator>
#include <sstream>
#include <string>
#include <vector>

#pragma comment(lib, "winhttp.lib")

namespace
{

struct ManifestEntry
{
    std::uint64_t size = 0;
    std::wstring relativePath;
};

std::filesystem::path GetExeDirectory()
{
    wchar_t buffer[MAX_PATH]{};

    GetModuleFileNameW(
        nullptr,
        buffer,
        MAX_PATH
    );

    return std::filesystem::path(
        buffer
    ).parent_path();
}

std::filesystem::path GetServerConfigPath()
{
    return GetExeDirectory() /
           L"server_config.ini";
}

std::wstring ReadConfig(
    const wchar_t* key,
    const wchar_t* fallback = L""
)
{
    wchar_t value[4096]{};

    GetPrivateProfileStringW(
        L"Services",
        key,
        fallback,
        value,
        static_cast<DWORD>(
            std::size(value)
        ),
        GetServerConfigPath().c_str()
    );

    return value;
}

std::wstring Utf8ToWide(
    const std::string& value
)
{
    if (value.empty())
        return {};

    const int size =
        MultiByteToWideChar(
            CP_UTF8,
            0,
            value.c_str(),
            static_cast<int>(value.size()),
            nullptr,
            0
        );

    if (size <= 0)
        return {};

    std::wstring result(
        static_cast<std::size_t>(size),
        L'\0'
    );

    MultiByteToWideChar(
        CP_UTF8,
        0,
        value.c_str(),
        static_cast<int>(value.size()),
        result.data(),
        size
    );

    return result;
}

std::string WideToUtf8(
    const std::wstring& value
)
{
    if (value.empty())
        return {};

    const int size =
        WideCharToMultiByte(
            CP_UTF8,
            0,
            value.c_str(),
            static_cast<int>(value.size()),
            nullptr,
            0,
            nullptr,
            nullptr
        );

    if (size <= 0)
        return {};

    std::string result(
        static_cast<std::size_t>(size),
        '\0'
    );

    WideCharToMultiByte(
        CP_UTF8,
        0,
        value.c_str(),
        static_cast<int>(value.size()),
        result.data(),
        size,
        nullptr,
        nullptr
    );

    return result;
}

bool IsUrlSafeByte(
    unsigned char ch
)
{
    return
        (ch >= 'A' && ch <= 'Z') ||
        (ch >= 'a' && ch <= 'z') ||
        (ch >= '0' && ch <= '9') ||
        ch == '-' ||
        ch == '_' ||
        ch == '.' ||
        ch == '~' ||
        ch == '/';
}

std::wstring EncodeUrlPath(
    const std::wstring& path
)
{
    const std::string utf8 =
        WideToUtf8(path);

    static const char hex[] =
        "0123456789ABCDEF";

    std::string encoded;

    encoded.reserve(
        utf8.size() + 32
    );

    for (unsigned char ch : utf8)
    {
        if (IsUrlSafeByte(ch))
        {
            encoded.push_back(
                static_cast<char>(ch)
            );
        }
        else
        {
            encoded.push_back('%');
            encoded.push_back(
                hex[(ch >> 4) & 0x0F]
            );
            encoded.push_back(
                hex[ch & 0x0F]
            );
        }
    }

    return Utf8ToWide(encoded);
}

std::wstring JoinUrl(
    std::wstring base,
    const std::wstring& relative
)
{
    if (!base.empty() &&
        base.back() != L'/')
    {
        base.push_back(L'/');
    }

    std::wstring rel = relative;

    while (!rel.empty() &&
           (rel.front() == L'/' ||
            rel.front() == L'\\'))
    {
        rel.erase(rel.begin());
    }

    std::replace(
        rel.begin(),
        rel.end(),
        L'\\',
        L'/'
    );

    return base + EncodeUrlPath(rel);
}

bool IsSafeRelativePath(
    const std::wstring& text
)
{
    if (text.empty())
        return false;

    std::filesystem::path path(text);

    if (path.is_absolute())
        return false;

    for (const auto& component : path)
    {
        if (component == L"..")
            return false;
    }

    return true;
}

bool OpenRequestForUrl(
    HINTERNET session,
    const std::wstring& url,
    HINTERNET& connection,
    HINTERNET& request,
    std::wstring& error,
    const std::wstring& extraHeaders = L""
)
{
    connection = nullptr;
    request = nullptr;

    URL_COMPONENTS parts{};
    parts.dwStructSize =
        sizeof(parts);

    wchar_t host[512]{};
    wchar_t path[8192]{};

    parts.lpszHostName = host;
    parts.dwHostNameLength =
        static_cast<DWORD>(
            std::size(host)
        );

    parts.lpszUrlPath = path;
    parts.dwUrlPathLength =
        static_cast<DWORD>(
            std::size(path)
        );

    if (!WinHttpCrackUrl(
            url.c_str(),
            0,
            0,
            &parts))
    {
        error = L"URL inválido.";
        return false;
    }

    const std::wstring hostName(
        host,
        parts.dwHostNameLength
    );

    std::wstring requestPath(
        path,
        parts.dwUrlPathLength
    );

    if (requestPath.empty())
        requestPath = L"/";

    connection = WinHttpConnect(
        session,
        hostName.c_str(),
        parts.nPort,
        0
    );

    if (!connection)
    {
        error =
            L"Não foi possível contactar "
            L"o servidor.";
        return false;
    }

    const DWORD flags =
        parts.nScheme ==
        INTERNET_SCHEME_HTTPS
        ? WINHTTP_FLAG_SECURE
        : 0;

    request = WinHttpOpenRequest(
        connection,
        L"GET",
        requestPath.c_str(),
        nullptr,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        flags
    );

    if (!request)
    {
        WinHttpCloseHandle(connection);
        connection = nullptr;

        error =
            L"Não foi possível preparar "
            L"o pedido.";
        return false;
    }

    const wchar_t* headers =
        extraHeaders.empty()
            ? WINHTTP_NO_ADDITIONAL_HEADERS
            : extraHeaders.c_str();

    const DWORD headerLength =
        extraHeaders.empty()
            ? 0
            : static_cast<DWORD>(-1L);

    BOOL ok = WinHttpSendRequest(
        request,
        headers,
        headerLength,
        WINHTTP_NO_REQUEST_DATA,
        0,
        0,
        0
    );

    if (ok)
    {
        ok = WinHttpReceiveResponse(
            request,
            nullptr
        );
    }

    if (!ok)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);

        request = nullptr;
        connection = nullptr;

        error =
            L"Falha na comunicação "
            L"com o servidor.";
        return false;
    }

    return true;
}

DWORD QueryStatusCode(
    HINTERNET request
)
{
    DWORD status = 0;
    DWORD size = sizeof(status);

    WinHttpQueryHeaders(
        request,
        WINHTTP_QUERY_STATUS_CODE |
        WINHTTP_QUERY_FLAG_NUMBER,
        WINHTTP_HEADER_NAME_BY_INDEX,
        &status,
        &size,
        WINHTTP_NO_HEADER_INDEX
    );

    return status;
}

bool DownloadText(
    HINTERNET session,
    const std::wstring& url,
    std::string& text,
    std::wstring& error
)
{
    HINTERNET connection = nullptr;
    HINTERNET request = nullptr;

    if (!OpenRequestForUrl(
            session,
            url,
            connection,
            request,
            error))
    {
        return false;
    }

    const DWORD status =
        QueryStatusCode(request);

    if (status < 200 ||
        status >= 300)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);

        error =
            L"O manifesto respondeu com HTTP " +
            std::to_wstring(status) +
            L".";

        return false;
    }

    text.clear();

    for (;;)
    {
        DWORD available = 0;

        if (!WinHttpQueryDataAvailable(
                request,
                &available))
        {
            WinHttpCloseHandle(request);
            WinHttpCloseHandle(connection);

            error =
                L"Não foi possível ler "
                L"o manifesto.";

            return false;
        }

        if (available == 0)
            break;

        std::vector<char> buffer(
            static_cast<std::size_t>(available)
        );

        DWORD read = 0;

        if (!WinHttpReadData(
                request,
                buffer.data(),
                available,
                &read))
        {
            WinHttpCloseHandle(request);
            WinHttpCloseHandle(connection);

            error =
                L"Não foi possível ler "
                L"o manifesto.";

            return false;
        }

        if (read == 0)
            break;

        text.append(
            buffer.data(),
            static_cast<std::size_t>(read)
        );
    }

    WinHttpCloseHandle(request);
    WinHttpCloseHandle(connection);

    return true;
}

bool ParseManifest(
    const std::string& manifest,
    std::vector<ManifestEntry>& entries,
    std::uint64_t& totalBytes,
    std::wstring& error
)
{
    entries.clear();
    totalBytes = 0;

    std::istringstream stream(manifest);
    std::string line;

    std::size_t lineNumber = 0;

    while (std::getline(stream, line))
    {
        ++lineNumber;

        if (!line.empty() &&
            line.back() == '\r')
        {
            line.pop_back();
        }

        if (line.empty())
            continue;

        const auto separator =
            line.find('|');

        if (separator ==
            std::string::npos)
        {
            error =
                L"Manifesto inválido na linha " +
                std::to_wstring(lineNumber) +
                L".";

            return false;
        }

        const std::string sizeText =
            line.substr(
                0,
                separator
            );

        const std::string pathUtf8 =
            line.substr(
                separator + 1
            );

        std::uint64_t fileSize = 0;

        try
        {
            fileSize =
                static_cast<std::uint64_t>(
                    std::stoull(sizeText)
                );
        }
        catch (...)
        {
            error =
                L"Tamanho inválido no manifesto, linha " +
                std::to_wstring(lineNumber) +
                L".";

            return false;
        }

        std::wstring relativePath =
            Utf8ToWide(pathUtf8);

        if (!IsSafeRelativePath(
                relativePath))
        {
            error =
                L"Caminho inválido no manifesto, linha " +
                std::to_wstring(lineNumber) +
                L".";

            return false;
        }

        ManifestEntry entry;
        entry.size = fileSize;
        entry.relativePath =
            std::move(relativePath);

        entries.push_back(
            std::move(entry)
        );

        totalBytes += fileSize;
    }

    if (entries.empty())
    {
        error =
            L"O manifesto da build está vazio.";

        return false;
    }

    return true;
}

std::uint64_t ExistingUsableBytes(
    const std::filesystem::path& file,
    std::uint64_t expected
)
{
    std::error_code ec;

    if (!std::filesystem::exists(
            file,
            ec) ||
        ec)
    {
        return 0;
    }

    const auto size =
        std::filesystem::file_size(
            file,
            ec
        );

    if (ec)
        return 0;

    if (size > expected)
        return 0;

    return static_cast<std::uint64_t>(
        size
    );
}

bool CreateEmptyFile(
    const std::filesystem::path& destination,
    std::wstring& error
)
{
    std::error_code ec;

    std::filesystem::create_directories(
        destination.parent_path(),
        ec
    );

    if (ec)
    {
        error =
            L"Não foi possível criar "
            L"uma pasta local.";
        return false;
    }

    HANDLE file = CreateFileW(
        destination.c_str(),
        GENERIC_WRITE,
        FILE_SHARE_READ,
        nullptr,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr
    );

    if (file ==
        INVALID_HANDLE_VALUE)
    {
        error =
            L"Não foi possível criar "
            L"um ficheiro local.";
        return false;
    }

    CloseHandle(file);
    return true;
}

bool DownloadFileResumable(
    HINTERNET session,
    const std::wstring& url,
    const std::filesystem::path& destination,
    std::uint64_t expectedSize,
    std::uint64_t& overallDownloaded,
    std::uint64_t totalBytes,
    std::size_t fileIndex,
    std::size_t fileCount,
    const std::wstring& relativePath,
    std::atomic_bool& cancelRequested,
    const BuildDownloadProgressCallback& progressCallback,
    const std::chrono::steady_clock::time_point& runStart,
    std::uint64_t runStartBytes,
    std::chrono::steady_clock::time_point& lastProgress,
    std::wstring& error
)
{
    std::error_code ec;

    std::filesystem::create_directories(
        destination.parent_path(),
        ec
    );

    if (ec)
    {
        error =
            L"Não foi possível criar "
            L"a estrutura de pastas.";
        return false;
    }

    if (expectedSize == 0)
    {
        if (!std::filesystem::exists(
                destination,
                ec))
        {
            if (!CreateEmptyFile(
                    destination,
                    error))
            {
                return false;
            }
        }

        return true;
    }

    std::uint64_t existing =
        ExistingUsableBytes(
            destination,
            expectedSize
        );

    if (existing == expectedSize)
        return true;

    if (cancelRequested.load())
    {
        error =
            L"Download cancelado. "
            L"Podes retomá-lo mais tarde.";
        return false;
    }

    std::wstring headers;

    if (existing > 0)
    {
        headers =
            L"Range: bytes=" +
            std::to_wstring(existing) +
            L"-\r\n";
    }

    HINTERNET connection = nullptr;
    HINTERNET request = nullptr;

    if (!OpenRequestForUrl(
            session,
            url,
            connection,
            request,
            error,
            headers))
    {
        return false;
    }

    const DWORD status =
        QueryStatusCode(request);

    bool append =
        existing > 0 &&
        status == 206;

    if (existing > 0 &&
        status == 200)
    {
        // O servidor ignorou Range: recomeçar este ficheiro.
        if (overallDownloaded >= existing)
            overallDownloaded -= existing;

        existing = 0;
        append = false;
    }
    else if (status < 200 ||
             status >= 300)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);

        error =
            L"Falha a baixar \"" +
            relativePath +
            L"\" (HTTP " +
            std::to_wstring(status) +
            L").";

        return false;
    }

    HANDLE file = CreateFileW(
        destination.c_str(),
        GENERIC_WRITE,
        FILE_SHARE_READ,
        nullptr,
        append
            ? OPEN_ALWAYS
            : CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr
    );

    if (file ==
        INVALID_HANDLE_VALUE)
    {
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connection);

        error =
            L"Não foi possível escrever \"" +
            relativePath +
            L"\".";

        return false;
    }

    if (append)
    {
        LARGE_INTEGER offset{};
        offset.QuadPart =
            static_cast<LONGLONG>(existing);

        SetFilePointerEx(
            file,
            offset,
            nullptr,
            FILE_BEGIN
        );
    }

    bool success = true;

    for (;;)
    {
        if (cancelRequested.load())
        {
            error =
                L"Download cancelado. "
                L"Podes retomá-lo mais tarde.";

            success = false;
            break;
        }

        DWORD available = 0;

        if (!WinHttpQueryDataAvailable(
                request,
                &available))
        {
            error =
                L"Falha durante o download de \"" +
                relativePath +
                L"\".";

            success = false;
            break;
        }

        if (available == 0)
            break;

        const DWORD chunk =
            (std::min)(
                available,
                static_cast<DWORD>(
                    1024 * 1024
                )
            );

        std::vector<unsigned char>
            buffer(chunk);

        DWORD read = 0;

        if (!WinHttpReadData(
                request,
                buffer.data(),
                chunk,
                &read))
        {
            error =
                L"Falha durante o download de \"" +
                relativePath +
                L"\".";

            success = false;
            break;
        }

        if (read == 0)
            break;

        DWORD written = 0;

        if (!WriteFile(
                file,
                buffer.data(),
                read,
                &written,
                nullptr) ||
            written != read)
        {
            error =
                L"Falha a guardar \"" +
                relativePath +
                L"\".";

            success = false;
            break;
        }

        overallDownloaded +=
            static_cast<std::uint64_t>(
                written
            );

        const auto now =
            std::chrono::steady_clock::now();

        if (progressCallback &&
            (
                now - lastProgress >=
                    std::chrono::milliseconds(200)
            ))
        {
            const double elapsed =
                std::chrono::duration<double>(
                    now - runStart
                ).count();

            BuildDownloadProgress progress;
            progress.downloadedBytes =
                overallDownloaded;
            progress.totalBytes =
                totalBytes;
            progress.fileIndex =
                fileIndex;
            progress.fileCount =
                fileCount;
            progress.currentFile =
                relativePath;

            if (elapsed > 0.05)
            {
                progress.bytesPerSecond =
                    static_cast<double>(
                        overallDownloaded -
                        runStartBytes
                    ) /
                    elapsed;
            }

            progressCallback(progress);
            lastProgress = now;
        }
    }

    CloseHandle(file);
    WinHttpCloseHandle(request);
    WinHttpCloseHandle(connection);

    if (!success)
        return false;

    const auto finalSize =
        std::filesystem::file_size(
            destination,
            ec
        );

    if (ec ||
        static_cast<std::uint64_t>(finalSize) !=
            expectedSize)
    {
        error =
            L"O tamanho final de \"" +
            relativePath +
            L"\" não corresponde ao manifesto.";

        return false;
    }

    return true;
}

} // namespace

bool ReadServerBuildInfo(
    ServerBuildInfo& info,
    std::wstring& error
)
{
    // O server_config.ini continua a ter prioridade.
    // Se o ficheiro não estiver junto do EXE, usa os valores
    // oficiais desta build do Project Flex como fallback.
    info.baseUrl =
        ReadConfig(
            L"BuildBaseUrl",
            L"https://54-36-99-5.sslip.io/builds/14.40/"
        );

    info.manifestUrl =
        ReadConfig(
            L"BuildManifestUrl",
            L"https://54-36-99-5.sslip.io/manifests/14.40/manifest.txt"
        );

    info.name =
        ReadConfig(
            L"BuildName",
            L"Fortnite 14.40"
        );

    info.subtitle =
        ReadConfig(
            L"BuildSubtitle",
            L"Chapter 2 Season 4"
        );

    info.installFolder =
        ReadConfig(
            L"BuildInstallFolder",
            L"14.40"
        );

    if (info.baseUrl.empty() ||
        info.manifestUrl.empty())
    {
        error =
            L"O servidor da build ainda "
            L"não está configurado.";

        return false;
    }

    if (!IsSafeRelativePath(
            info.installFolder))
    {
        error =
            L"BuildInstallFolder inválido.";
        return false;
    }

    error.clear();
    return true;
}

bool DownloadServerBuildFolder(
    const ServerBuildInfo& info,
    const std::filesystem::path& userDataDirectory,
    std::atomic_bool& cancelRequested,
    const BuildDownloadProgressCallback& progressCallback,
    std::filesystem::path& buildDirectory,
    std::wstring& error
)
{
    HINTERNET session = WinHttpOpen(
        L"ProjectFlexFolderDownloader/1.0",
        WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0
    );

    if (!session)
    {
        error =
            L"Não foi possível iniciar "
            L"o serviço de download.";
        return false;
    }

    WinHttpSetTimeouts(
        session,
        10000,
        10000,
        30000,
        30000
    );

    std::string manifestText;

    if (!DownloadText(
            session,
            info.manifestUrl,
            manifestText,
            error))
    {
        WinHttpCloseHandle(session);
        return false;
    }

    std::vector<ManifestEntry> entries;
    std::uint64_t totalBytes = 0;

    if (!ParseManifest(
            manifestText,
            entries,
            totalBytes,
            error))
    {
        WinHttpCloseHandle(session);
        return false;
    }

    buildDirectory =
        userDataDirectory /
        L"Builds" /
        info.installFolder;

    std::error_code ec;

    std::filesystem::create_directories(
        buildDirectory,
        ec
    );

    if (ec)
    {
        WinHttpCloseHandle(session);

        error =
            L"Não foi possível criar "
            L"a pasta local da build.";
        return false;
    }

    // Conta o que já existe. Ficheiros completos são saltados;
    // ficheiros parciais contam para a percentagem e são retomados.
    std::uint64_t overallDownloaded = 0;

    for (const auto& entry : entries)
    {
        const auto destination =
            buildDirectory /
            std::filesystem::path(
                entry.relativePath
            );

        overallDownloaded +=
            ExistingUsableBytes(
                destination,
                entry.size
            );
    }

    const auto runStart =
        std::chrono::steady_clock::now();

    const std::uint64_t runStartBytes =
        overallDownloaded;

    auto lastProgress =
        runStart -
        std::chrono::seconds(1);

    if (progressCallback)
    {
        BuildDownloadProgress progress;
        progress.downloadedBytes =
            overallDownloaded;
        progress.totalBytes =
            totalBytes;
        progress.fileCount =
            entries.size();

        progressCallback(progress);
    }

    for (std::size_t i = 0;
         i < entries.size();
         ++i)
    {
        if (cancelRequested.load())
        {
            WinHttpCloseHandle(session);

            error =
                L"Download cancelado. "
                L"Podes retomá-lo mais tarde.";

            return false;
        }

        const auto& entry =
            entries[i];

        const auto destination =
            buildDirectory /
            std::filesystem::path(
                entry.relativePath
            );

        const std::uint64_t before =
            ExistingUsableBytes(
                destination,
                entry.size
            );

        if (before == entry.size)
        {
            if (progressCallback)
            {
                const auto now =
                    std::chrono::steady_clock::now();

                const double elapsed =
                    std::chrono::duration<double>(
                        now - runStart
                    ).count();

                BuildDownloadProgress progress;
                progress.downloadedBytes =
                    overallDownloaded;
                progress.totalBytes =
                    totalBytes;
                progress.fileIndex =
                    i + 1;
                progress.fileCount =
                    entries.size();
                progress.currentFile =
                    entry.relativePath;

                if (elapsed > 0.05)
                {
                    progress.bytesPerSecond =
                        static_cast<double>(
                            overallDownloaded -
                            runStartBytes
                        ) /
                        elapsed;
                }

                progressCallback(progress);
            }

            continue;
        }

        const std::wstring url =
            JoinUrl(
                info.baseUrl,
                entry.relativePath
            );

        if (!DownloadFileResumable(
                session,
                url,
                destination,
                entry.size,
                overallDownloaded,
                totalBytes,
                i + 1,
                entries.size(),
                entry.relativePath,
                cancelRequested,
                progressCallback,
                runStart,
                runStartBytes,
                lastProgress,
                error))
        {
            WinHttpCloseHandle(session);
            return false;
        }

        if (progressCallback)
        {
            const auto now =
                std::chrono::steady_clock::now();

            const double elapsed =
                std::chrono::duration<double>(
                    now - runStart
                ).count();

            BuildDownloadProgress progress;
            progress.downloadedBytes =
                overallDownloaded;
            progress.totalBytes =
                totalBytes;
            progress.fileIndex =
                i + 1;
            progress.fileCount =
                entries.size();
            progress.currentFile =
                entry.relativePath;

            if (elapsed > 0.05)
            {
                progress.bytesPerSecond =
                    static_cast<double>(
                        overallDownloaded -
                        runStartBytes
                    ) /
                    elapsed;
            }

            progressCallback(progress);
        }
    }

    WinHttpCloseHandle(session);

    // Verificação final por tamanho.
    for (const auto& entry : entries)
    {
        const auto destination =
            buildDirectory /
            std::filesystem::path(
                entry.relativePath
            );

        if (ExistingUsableBytes(
                destination,
                entry.size) !=
            entry.size)
        {
            error =
                L"A build ficou incompleta em \"" +
                entry.relativePath +
                L"\".";

            return false;
        }
    }

    error.clear();
    return true;
}
