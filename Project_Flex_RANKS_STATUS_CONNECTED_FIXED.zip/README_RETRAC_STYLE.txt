﻿PROJECT FLEX — NOVA UI (INSPIRAÇÃO: launchers OG modernos)

Esta versão é um redesign completo, mantendo a base C++17 Win32/GDI+ e as funções
de autenticação, Discord e biblioteca.

PRINCIPAIS MUDANÇAS
- sidebar vertical moderna;
- dashboard estilo launcher premium;
- login split-screen com área visual + formulário;
- intro FLEX mantida;
- home com hero Nexus War e PLAY NOW;
- cards de Library, Account e Launcher;
- biblioteca em cards compactos;
- páginas Status, Ranks e Cups redesenhadas;
- ícone FLEX mantido;
- @ / AltGr e Ctrl+V mantidos;
- Auth HTTPS e Discord mantidos.

O estilo é original do Project Flex, inspirado na organização e limpeza visual
de launchers OG como o Retrac; não é uma cópia direta.

COMO COMPILAR
1. Extrai para uma pasta nova.
2. Abre Project_Flex.sln.
3. Seleciona x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executa o EXE novo em x64\Debug ou x64\Release.
