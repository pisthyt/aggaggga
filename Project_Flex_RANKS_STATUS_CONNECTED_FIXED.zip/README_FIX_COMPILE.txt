﻿CORREÇÃO DE COMPILAÇÃO

O erro C2628/C2062 vinha do identificador `small`, que entra em conflito com
definições dos headers Win32.

Foi renomeado para `smallFont` em:
- Home
- Cups

Passos:
1. Extrai para uma pasta nova.
2. Abre Project_Flex.sln.
3. Build > Clean Solution.
4. Build > Rebuild Solution.
