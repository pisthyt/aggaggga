import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import jwt from "jsonwebtoken";
import {
  Client,
  GatewayIntentBits,
  Events,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder
} from "discord.js";

const required = [
  "DISCORD_TOKEN",
  "DISCORD_CLIENT_ID",
  "DISCORD_GUILD_ID",
  "JWT_SECRET"
];

for (const key of required) {
  if (!process.env[key]) {
    console.error(`Falta ${key} no .env`);
    process.exit(1);
  }
}

const db = new Database("flex_accounts.db");
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    owner_user_id TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    disabled INTEGER NOT NULL DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_accounts_owner
  ON accounts(owner_user_id);
`);

const findByUsername = db.prepare(`
  SELECT id, username, display_name, password_hash, owner_user_id, disabled
  FROM accounts
  WHERE username = ?
`);

const findByOwner = db.prepare(`
  SELECT id
  FROM accounts
  WHERE owner_user_id = ?
  LIMIT 1
`);

const insertAccount = db.prepare(`
  INSERT INTO accounts(username, display_name, password_hash, owner_user_id)
  VALUES(?, ?, ?, ?)
`);

function normalizeUsername(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, "_")
    .slice(0, 24);
}

function validUsername(value) {
  return /^[A-Za-z0-9_.-]{3,24}$/.test(value);
}

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "16kb" }));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "flex" });
});

app.use(
  "/api/auth/login",
  rateLimit({
    windowMs: 60_000,
    limit: 12,
    standardHeaders: "draft-8",
    legacyHeaders: false
  })
);

app.post("/api/auth/login", async (req, res) => {
  const username = normalizeUsername(req.body?.username);
  const password = String(req.body?.password || "");

  if (!validUsername(username) || password.length < 8 || password.length > 128) {
    return res.status(401).json({
      success: false,
      message: "Utilizador ou palavra-passe incorretos."
    });
  }

  const account = findByUsername.get(username);

  if (!account || account.disabled) {
    return res.status(401).json({
      success: false,
      message: "Utilizador ou palavra-passe incorretos."
    });
  }

  const valid = await bcrypt.compare(password, account.password_hash);

  if (!valid) {
    return res.status(401).json({
      success: false,
      message: "Utilizador ou palavra-passe incorretos."
    });
  }

  const token = jwt.sign(
    {
      sub: String(account.id),
      username: account.username
    },
    process.env.JWT_SECRET,
    {
      expiresIn: "12h",
      issuer: "project-flex"
    }
  );

  return res.json({
    success: true,
    displayName: account.display_name,
    token
  });
});

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.once(Events.ClientReady, readyClient => {
  console.log(`Bot pronto: ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "criarconta") {
      if (
        String(process.env.ONE_ACCOUNT_PER_USER).toLowerCase() !== "false" &&
        findByOwner.get(interaction.user.id)
      ) {
        return interaction.reply({
          content: "Já tens uma conta associada.",
          ephemeral: true
        });
      }

      const modal = new ModalBuilder()
        .setCustomId("flex_create_account")
        .setTitle("Criar conta Project Flex");

      const username = new TextInputBuilder()
        .setCustomId("username")
        .setLabel("Utilizador")
        .setPlaceholder("3 a 24 caracteres")
        .setMinLength(3)
        .setMaxLength(24)
        .setRequired(true)
        .setStyle(TextInputStyle.Short);

      const password = new TextInputBuilder()
        .setCustomId("password")
        .setLabel("Palavra-passe")
        .setPlaceholder("Mínimo 8 caracteres")
        .setMinLength(8)
        .setMaxLength(128)
        .setRequired(true)
        .setStyle(TextInputStyle.Short);

      const confirm = new TextInputBuilder()
        .setCustomId("confirm")
        .setLabel("Confirmar palavra-passe")
        .setMinLength(8)
        .setMaxLength(128)
        .setRequired(true)
        .setStyle(TextInputStyle.Short);

      modal.addComponents(
        new ActionRowBuilder().addComponents(username),
        new ActionRowBuilder().addComponents(password),
        new ActionRowBuilder().addComponents(confirm)
      );

      return interaction.showModal(modal);
    }
  }

  if (interaction.isModalSubmit() && interaction.customId === "flex_create_account") {
    const username = normalizeUsername(
      interaction.fields.getTextInputValue("username")
    );

    const password = interaction.fields.getTextInputValue("password");
    const confirm = interaction.fields.getTextInputValue("confirm");

    if (!validUsername(username)) {
      return interaction.reply({
        content: "O utilizador só pode usar letras, números, ponto, hífen e underscore.",
        ephemeral: true
      });
    }

    if (password !== confirm) {
      return interaction.reply({
        content: "As palavras-passe não coincidem.",
        ephemeral: true
      });
    }

    if (findByUsername.get(username)) {
      return interaction.reply({
        content: "Esse utilizador já existe.",
        ephemeral: true
      });
    }

    if (
      String(process.env.ONE_ACCOUNT_PER_USER).toLowerCase() !== "false" &&
      findByOwner.get(interaction.user.id)
    ) {
      return interaction.reply({
        content: "Já tens uma conta associada.",
        ephemeral: true
      });
    }

    const hash = await bcrypt.hash(password, 12);

    try {
      insertAccount.run(
        username,
        interaction.user.globalName || interaction.user.username,
        hash,
        interaction.user.id
      );
    } catch {
      return interaction.reply({
        content: "Não foi possível criar a conta.",
        ephemeral: true
      });
    }

    return interaction.reply({
      content: `Conta **${username}** criada. Já podes iniciar sessão no Project Flex.`,
      ephemeral: true
    });
  }
});

const port = Number(process.env.PORT || 3560);
const host = process.env.BIND_HOST || "127.0.0.1";

app.listen(port, host, () => {
  console.log(`API local pronta em ${host}:${port}`);
});

client.login(process.env.DISCORD_TOKEN);
