﻿PROJECT FLEX — BOT + API DE CONTAS
=================================

Objetivo
--------
As contas do launcher são criadas apenas pelo bot.
O launcher não possui registo local.

Instalação no VPS (Ubuntu)
--------------------------
1. Instalar Node.js 20+.
2. Entrar nesta pasta.
3. Copiar:
     cp .env.example .env
4. Preencher o .env.
5. Instalar:
     npm install
6. Registar o comando:
     npm run deploy
7. Iniciar:
     npm start

O comando disponível será:
  /criarconta

A palavra-passe é guardada apenas como hash bcrypt.
A API de login tem rate limit e devolve um token JWT de 12 horas.

Produção
--------
É recomendado manter BIND_HOST=127.0.0.1 e publicar a API por HTTPS
através de um reverse proxy. Existe nginx.example.conf como exemplo.

No PC do launcher
-----------------
Criar server_config.ini junto de Project_Flex.exe:

[Services]
AuthUrl=https://TEU_DOMINIO/api/auth/login
AccountUrl=https://LINK_ONDE_O_UTILIZADOR_ACEDE_AO_TEU_BOT

O launcher usa estes valores internamente mas não os apresenta na interface.
