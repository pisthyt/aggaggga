﻿PROJECT FLEX — BEAUTIFUL INTRO + CUSTOM ICON

Alterações desta versão:
- intro de 2,6 s com o teu logo FLEX grande e centrado;
- imagem removida do canto do launcher;
- login redesenhado com cartão escuro, glow cyan/roxo e botões modernos;
- logo centrado no login;
- botão "CRIAR CONTA NO DISCORD";
- ícone do Project_Flex.exe criado com a imagem FLEX enviada;
- ícone também aparece na janela/barra de tarefas;
- correção de @ em teclado PT-PT através de WM_SYSCHAR / AltGr;
- Ctrl+V funciona nos campos de email/password;
- mantém o Auth HTTPS e o Discord já configurados.

COMO USAR:
1. Extrai o ZIP para uma pasta nova.
2. Abre Project_Flex.sln.
3. Seleciona x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executa o EXE novo em x64\Debug ou x64\Release.

Discord:
https://discord.gg/vWpFQ4dhj6
