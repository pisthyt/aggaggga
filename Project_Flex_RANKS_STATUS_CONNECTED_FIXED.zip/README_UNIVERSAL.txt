﻿PROJECT FLEX — UNIVERSAL / LOGIN GUARDADO / BUILD DO SERVIDOR

Esta versão foi preparada para funcionar em diferentes PCs e utilizadores.

ALTERAÇÕES
- não cria nenhuma build automaticamente;
- a primeira execução começa com a biblioteca vazia;
- a pessoa tem de IMPORTAR uma build ou BAIXAR DO SERVIDOR;
- botão "BAIXAR DO SERVIDOR" no Home e na Library;
- downloads e dados pessoais ficam em %LOCALAPPDATA%\ProjectFlex;
- library.ini e ProjectFlex.ini ficam em %LOCALAPPDATA%\ProjectFlex;
- não depende de C:\Fortnite nem C:\ProjectFlex;
- opção "Manter sessão iniciada";
- credenciais guardadas no Windows Credential Manager;
- no próximo arranque o launcher tenta iniciar sessão automaticamente;
- "Terminar sessão" remove a credencial guardada;
- intro utiliza a imagem FLEX como fundo completo;
- mantém o ícone FLEX;
- mantém Discord e Auth HTTPS;
- mantém @ / AltGr e Ctrl+V.

DOWNLOAD DA BUILD PELO TEU SERVIDOR

O ficheiro server_config.ini contém:

    BuildUrl=
    BuildName=Fortnite Build
    BuildSubtitle=Build do servidor

BuildUrl fica VAZIO de propósito. O launcher não traz nenhuma build falsa.

Quando tiveres um ZIP real hospedado no teu servidor/CDN, coloca por exemplo:

    BuildUrl=https://teu-host/downloads/fortnite-build.zip

Ao carregar em "BAIXAR DO SERVIDOR":
1. o launcher descarrega o ZIP;
2. guarda temporariamente em %LOCALAPPDATA%\ProjectFlex\Downloads;
3. extrai para %LOCALAPPDATA%\ProjectFlex\Builds\ServerBuild;
4. valida se existe FortniteClient-Win64-Shipping.exe;
5. só depois adiciona a build à biblioteca.

Usa apenas builds que tenhas autorização para alojar e distribuir.

COMPILAR
1. Extrair para uma pasta nova.
2. Abrir Project_Flex.sln.
3. Selecionar x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executar o EXE novo em x64\Debug ou x64\Release.
