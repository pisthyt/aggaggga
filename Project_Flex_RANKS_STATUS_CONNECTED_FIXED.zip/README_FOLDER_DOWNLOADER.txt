﻿PROJECT FLEX — FOLDER DOWNLOADER

Esta versão deixa de usar ZIP.

SERVIDOR CONFIGURADO
BuildBaseUrl:
https://54-36-99-5.sslip.io/builds/14.40/

Manifest:
https://54-36-99-5.sslip.io/manifests/14.40/manifest.txt

COMPORTAMENTO
- lê o manifest.txt;
- preserva a estrutura completa da pasta;
- cria:
  %LOCALAPPDATA%\ProjectFlex\Builds\14.40\
- descarrega os ficheiros diretamente para as respetivas pastas;
- ficheiros completos já existentes são ignorados;
- ficheiros parciais são retomados através de HTTP Range;
- mostra percentagem, GB descarregados, GB totais, velocidade e ficheiro atual;
- o mesmo botão passa a CANCELAR durante o download;
- ao cancelar, os ficheiros parciais ficam guardados;
- ao carregar novamente em baixar, o download é retomado;
- no final valida os tamanhos dos ficheiros do manifesto;
- só depois adiciona a build à Library.

Não existe build falsa nem pré-instalada no launcher.

NOTA
A validação desta versão usa os tamanhos presentes no manifesto.
Para distribuição mais robusta, podes posteriormente acrescentar SHA-256
ao manifesto para validação criptográfica de cada ficheiro.

COMPILAR
1. Extrair para uma pasta nova.
2. Abrir Project_Flex.sln.
3. Selecionar x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executar o EXE novo.
