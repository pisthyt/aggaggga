﻿PROJECT FLEX — VISUAL STUDIO 2022
=================================

Abrir:
  Project_Flex.sln

Compilar:
  Release | x64
  Build > Rebuild Solution

Saída:
  x64\Release\Project_Flex.exe

Incluído nesta versão
---------------------
- Splash animado.
- Login obrigatório.
- Sem registo dentro do launcher.
- "Criar conta" abre o acesso configurado para o bot.
- Autenticação real por API.
- Biblioteca de builds persistente.
- Botão + importa uma pasta de build.
- Validação de FortniteClient-Win64-Shipping.exe.
- Seleção de builds.
- Remoção da biblioteca sem apagar os ficheiros do jogo.
- Botão LANÇAR usa a build selecionada.
- Definições persistentes.
- Animação de estrelas, glow e transição entre páginas.
- Opção "Reduzir movimento".
- Nenhum endereço de servidor é apresentado na UI.
- Projeto do bot/API incluído em vps-bot\.

Configurar a criação/login de conta
-----------------------------------
1. Configura e inicia o conteúdo de vps-bot no teu VPS.
2. Executa CONFIGURAR_SERVICO.bat.
3. Preenche o endereço HTTPS da API e o link de acesso ao bot.
4. Compila o launcher.

O ficheiro privado server_config.ini é copiado automaticamente para a pasta
do executável quando existe junto do .sln.

Segurança
---------
- Passwords: bcrypt no servidor.
- Login: rate limit.
- Sessão: JWT.
- Segredos do bot ficam apenas no .env do VPS.
- Em produção usa HTTPS.


REVISÃO V2
----------
- Corrigida a declaração de Ellipsize para compilação.
- Terminar sessão agora é funcional.
- Alternância Torneios/Leaderboard funciona.
- Removida a indicação visual de "Atualizar" sem ação em Ranks.
- launcher.h/.cpp já não contêm nem recebem endereço de backend.

REVISAO V3 - CORRECAO DE COMPILACAO
------------------------------------
Corrigido o bloco HandleTextInput em src/main.cpp.
As sequencias de teclado agora usam literais C++ validos: \\b, \\r, \\n e \\t.
Os erros C2137/C2001/C2143/C2015 e o erro em WndProc eram erros em cascata
provocados por uma quebra de linha dentro de um literal de caracter.
