﻿PROJECT FLEX — FULL FIX DISCORD + LOGIN

IMPORTANTE:
Não copies apenas um auth_client.cpp para a raiz do projeto.

O ficheiro que o Visual Studio compila está em:
    src\auth_client.cpp

Este ZIP já tem tudo no sítio certo.

PASSOS:
1. Extrai este ZIP para uma pasta NOVA.
2. Abre Project_Flex.sln.
3. Seleciona x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executa o Project_Flex.exe gerado em x64\Debug ou x64\Release.

CORREÇÕES:
- campo de login = Email;
- API envia email + password;
- AuthUrl HTTPS configurado;
- convite Discord configurado;
- botão "Criar conta no Discord";
- server_config.ini é copiado automaticamente para junto do EXE;
- se o INI não for encontrado, existem fallbacks compilados;
- abertura do Discord tenta 3 métodos do Windows.

Discord:
https://discord.gg/vWpFQ4dhj6
