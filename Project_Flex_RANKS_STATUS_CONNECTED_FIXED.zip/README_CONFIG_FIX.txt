﻿CORREÇÃO — SERVIDOR DA BUILD

Esta versão já não depende do server_config.ini para encontrar a build 14.40.

Se server_config.ini existir junto do Project_Flex.exe, os valores desse ficheiro
têm prioridade.

Se não existir, o launcher usa automaticamente:

BuildBaseUrl=https://54-36-99-5.sslip.io/builds/14.40/
BuildManifestUrl=https://54-36-99-5.sslip.io/manifests/14.40/manifest.txt

Assim, o botão BAIXAR DO SERVIDOR funciona mesmo que o ficheiro INI não seja
copiado para a pasta do EXE.

Compilar:
1. Extrair para pasta nova.
2. Abrir Project_Flex.sln.
3. x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executar apenas o EXE acabado de compilar.
