﻿PROJECT FLEX — RANKS + STATUS API

Esta versão liga o launcher diretamente aos endpoints:

GET https://54-36-99-5.sslip.io/projectflex/api/ranks
GET https://54-36-99-5.sslip.io/projectflex/api/status

RANKS
- consulta a API ao entrar no launcher;
- volta a atualizar ao abrir o separador Ranks;
- não contém jogadores fictícios;
- apresenta até 8 jogadores na primeira página;
- colunas: posição, jogador, wins, kills e hype;
- se players=[] mostra a mensagem de ranking ainda vazio.

STATUS
- consulta a API ao entrar no launcher;
- volta a atualizar ao abrir Status;
- Backend, Authentication e Database são mostrados conforme os booleanos reais da API;
- mostra número de jogadores no ranking;
- mostra uptime devolvido pelo servidor.

CUPS
Ainda não foi ligado a uma API porque o servidor ainda não tem endpoint de Cups.
Não foram adicionados dados fictícios.

COMPILAR
1. Extrair para uma pasta nova.
2. Abrir Project_Flex.sln.
3. Selecionar x64.
4. Build > Clean Solution.
5. Build > Rebuild Solution.
6. Executar o Project_Flex.exe novo.
