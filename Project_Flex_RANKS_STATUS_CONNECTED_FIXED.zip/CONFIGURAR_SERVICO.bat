@echo off
setlocal
title Project Flex - Configuracao privada

echo.
echo Configuracao do servico Project Flex
echo Estes dados nao sao mostrados na interface do launcher.
echo.

set /p AUTHURL=URL HTTPS da autenticacao:
set /p ACCOUNTURL=Link para criacao de conta:

(
echo [Services]
echo AuthUrl=%AUTHURL%
echo AccountUrl=%ACCOUNTURL%
) > "%~dp0server_config.ini"

echo.
echo Configuracao guardada em server_config.ini
pause
